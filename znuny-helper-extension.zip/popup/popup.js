(function () {
  "use strict";

  const SETTINGS_KEY = "znunyHelperSettings";
  const TICKET_SOUND_CONFIG_KEY = "znunyHelperTicketSoundConfig";
  const DEFAULT_SETTINGS = {
    popupTabs: true,
    attachmentPreview: true,
    ticketNumberSearch: true,
    searchResultsPopup: false,
    ticketArticleSearch: true,
    ticketNumberCopy: true,
    ebHelper: false,
    priorityTemplates: true,
    ticketCategories: true,
    ticketListInfiniteScroll: true,
    pendingDateButtons: true,
    pendingDatePresets: [3, 7, 14],
    pendingDateDefaultDays: 7,
    keyboardShortcuts: true,
    assignedTicketSound: false,
    quickReply: false,
    directArticleActions: true,
    christmasMode: true
  };

  const BUILTIN_TICKET_SOUNDS = [
    { id: "soft-ping", name: "Sanfter Ping", file: "sounds/soft-ping.wav" },
    { id: "two-tone-chime", name: "Zwei-Ton-Chime", file: "sounds/two-tone-chime.wav" },
    { id: "soft-click", name: "Weicher Klick", file: "sounds/soft-click.wav" },
    { id: "subtle-ping", name: "Dezenter Ping", file: "sounds/subtle-ping.mp3" },
    { id: "message-notification", name: "Neue Nachricht", file: "sounds/message-notification.mp3" },
    { id: "icq", name: "ICQ", file: "sounds/icq.mp3" },
    { id: "iphone", name: "iPhone", file: "sounds/iphone.mp3" },
    { id: "minecraft-chicken-1", name: "Minecraft Huhn 1", file: "sounds/minecraft-chicken-1.mp3" },
    { id: "minecraft-chicken-2", name: "Minecraft Huhn 2", file: "sounds/minecraft-chicken-2.mp3" },
    { id: "whatsapp", name: "WhatsApp", file: "sounds/whatsapp.mp3" }
  ];

  const api = typeof browser !== "undefined" ? browser : chrome;
  const usesPromiseStorage = typeof browser !== "undefined";
  const form = document.getElementById("settingsForm");
  const status = document.getElementById("status");
  const soundSelect = document.getElementById("soundSelect");
  const soundPreview = document.getElementById("soundPreview");
  const customSoundList = document.getElementById("customSoundList");
  const soundAdd = document.getElementById("soundAdd");
  const soundFileInput = document.getElementById("soundFileInput");
  const pendingPresetsInput = document.getElementById("pendingPresetsInput");
  const pendingDefaultInput = document.getElementById("pendingDefaultInput");
  const pendingDetails = document.getElementById("pendingDetails");
  const versionPill = document.getElementById("versionPill");
  const diagnoseCopy = document.getElementById("diagnoseCopy");
  const diagnoseOutput = document.getElementById("diagnoseOutput");

  // Alle Schluessel, die die Erweiterung im lokalen Speicher belegt. Nur zur
  // Groessenangabe in der Diagnose - die Namen duerfen sich nicht aendern,
  // sonst waeren die gespeicherten Daten der Nutzer weg.
  const STORAGE_KEYS = [
    "znunyHelperSettings",
    "znunyHelperTicketState",
    "znunyHelperSearchHistory",
    "znunyHelperCategoryConfig",
    "znunyHelperPriorityTemplateConfig",
    "znunyHelperTicketSoundConfig",
    "znunyHelperSeenLockedTicketIds",
    "znunyHelperQuickReplyLayout",
    "znunyHelperQuickReplyDrafts"
  ];

  let ticketSoundConfig = { customSounds: [], selectedId: BUILTIN_TICKET_SOUNDS[0].id };

  function storageGet(defaults) {
    if (usesPromiseStorage) {
      return api.storage.local.get(defaults).then((value) => value || defaults);
    }

    return new Promise((resolve) => api.storage.local.get(defaults, (value) => resolve(value || defaults)));
  }

  function storageSet(value) {
    if (usesPromiseStorage) {
      return api.storage.local.set(value);
    }

    return new Promise((resolve) => api.storage.local.set(value, resolve));
  }

  const BOOLEAN_SETTING_KEYS = Object.keys(DEFAULT_SETTINGS)
    .filter((key) => typeof DEFAULT_SETTINGS[key] === "boolean");

  function parsePendingPresets(value) {
    const seen = new Set();
    const presets = [];

    String(value || "").split(/[,;\s]+/).forEach((entry) => {
      const days = Math.trunc(Number(entry));
      if (!Number.isFinite(days) || days <= 0 || days > 3650 || seen.has(days)) return;
      seen.add(days);
      presets.push(days);
    });

    return presets.length ? presets.slice(0, 8) : DEFAULT_SETTINGS.pendingDatePresets.slice();
  }

  function parsePendingDefaultDays(value) {
    const days = Math.trunc(Number(String(value ?? "").replace(",", ".")));

    if (!Number.isFinite(days) || days <= 0 || days > 3650) {
      return DEFAULT_SETTINGS.pendingDateDefaultDays;
    }

    return days;
  }

  function readForm() {
    const settings = {};

    BOOLEAN_SETTING_KEYS.forEach((key) => {
      settings[key] = Boolean(form.elements[key]?.checked);
    });

    settings.pendingDatePresets = parsePendingPresets(pendingPresetsInput.value);
    settings.pendingDateDefaultDays = parsePendingDefaultDays(pendingDefaultInput.value);
    return settings;
  }

  function writeForm(settings) {
    Object.entries(settings).forEach(([key, value]) => {
      if (key === "pendingDatePresets" || key === "pendingDateDefaultDays") return;
      if (form.elements[key]) {
        form.elements[key].checked = Boolean(value);
      }
    });

    const presets = Array.isArray(settings.pendingDatePresets) && settings.pendingDatePresets.length
      ? settings.pendingDatePresets
      : DEFAULT_SETTINGS.pendingDatePresets;
    pendingPresetsInput.value = presets.join(", ");
    pendingDefaultInput.value = String(parsePendingDefaultDays(settings.pendingDateDefaultDays));
  }

  async function save() {
    const nextSettings = readForm();
    await storageSet({ [SETTINGS_KEY]: nextSettings });
    writeForm(nextSettings);
    status.textContent = "Gespeichert";
    window.setTimeout(() => {
      status.textContent = "Bereit";
    }, 1200);
  }

  function normalizeTicketSoundConfig(config) {
    const customSounds = Array.isArray(config?.customSounds)
      ? config.customSounds
          .filter((sound) => sound?.dataUrl)
          .map((sound, index) => ({
            id: String(sound.id || `custom-${index + 1}`),
            name: String(sound.name || `Eigener Sound ${index + 1}`).trim(),
            dataUrl: String(sound.dataUrl)
          }))
      : [];

    const availableIds = [...BUILTIN_TICKET_SOUNDS, ...customSounds].map((sound) => sound.id);
    const selectedId = availableIds.includes(config?.selectedId) ? config.selectedId : BUILTIN_TICKET_SOUNDS[0].id;

    return { customSounds, selectedId };
  }

  function getSoundSource(sound) {
    if (!sound) return "";
    if (sound.dataUrl) return sound.dataUrl;
    if (sound.file) return api.runtime.getURL(sound.file);
    return "";
  }

  function renderSoundSelect() {
    const allSounds = [...BUILTIN_TICKET_SOUNDS, ...ticketSoundConfig.customSounds];
    soundSelect.replaceChildren();

    allSounds.forEach((sound) => {
      const option = document.createElement("option");
      option.value = sound.id;
      option.textContent = sound.name;
      if (sound.id === ticketSoundConfig.selectedId) option.selected = true;
      soundSelect.appendChild(option);
    });
  }

  function renderCustomSoundList() {
    customSoundList.replaceChildren();

    ticketSoundConfig.customSounds.forEach((sound) => {
      const item = document.createElement("li");

      const label = document.createElement("span");
      label.textContent = sound.name;

      const removeButton = document.createElement("button");
      removeButton.type = "button";
      removeButton.title = "Entfernen";
      removeButton.textContent = "×";
      removeButton.addEventListener("click", () => removeCustomSound(sound.id));

      item.appendChild(label);
      item.appendChild(removeButton);
      customSoundList.appendChild(item);
    });
  }

  async function saveSoundConfig() {
    ticketSoundConfig = normalizeTicketSoundConfig(ticketSoundConfig);
    await storageSet({ [TICKET_SOUND_CONFIG_KEY]: ticketSoundConfig });
  }

  async function removeCustomSound(id) {
    ticketSoundConfig.customSounds = ticketSoundConfig.customSounds.filter((sound) => sound.id !== id);
    if (ticketSoundConfig.selectedId === id) {
      ticketSoundConfig.selectedId = BUILTIN_TICKET_SOUNDS[0].id;
    }
    await saveSoundConfig();
    renderSoundSelect();
    renderCustomSoundList();
  }

  function initSoundSettings() {
    soundSelect.addEventListener("change", () => {
      ticketSoundConfig.selectedId = soundSelect.value;
      saveSoundConfig();
    });

    soundPreview.addEventListener("click", () => {
      const allSounds = [...BUILTIN_TICKET_SOUNDS, ...ticketSoundConfig.customSounds];
      const src = getSoundSource(allSounds.find((sound) => sound.id === soundSelect.value));
      if (!src) return;
      new Audio(src).play().catch((error) => console.warn("Znuny Helper: Vorschau fehlgeschlagen:", error));
    });

    soundAdd.addEventListener("click", () => soundFileInput.click());

    soundFileInput.addEventListener("change", () => {
      const file = soundFileInput.files?.[0];
      soundFileInput.value = "";
      if (!file) return;

      const reader = new FileReader();
      reader.onload = async () => {
        const dataUrl = String(reader.result || "");
        if (!dataUrl) return;

        const defaultName = file.name.replace(/\.[^.]+$/, "");
        const name = (window.prompt("Name für den Sound:", defaultName) || defaultName || file.name).trim();

        ticketSoundConfig.customSounds.push({ id: `custom-${Date.now()}`, name: name || file.name, dataUrl });
        ticketSoundConfig.selectedId = ticketSoundConfig.customSounds[ticketSoundConfig.customSounds.length - 1].id;

        await saveSoundConfig();
        renderSoundSelect();
        renderCustomSoundList();
      };
      reader.readAsDataURL(file);
    });
  }

  function updatePendingPresetState() {
    const enabled = Boolean(form.elements.pendingDateButtons?.checked);
    pendingPresetsInput.disabled = !enabled;
    pendingDefaultInput.disabled = !enabled;
    pendingDetails?.classList.toggle("is-disabled", !enabled);
    pendingDetails?.setAttribute("aria-disabled", enabled ? "false" : "true");
  }

  function showVersion() {
    if (!versionPill) return;

    try {
      versionPill.textContent = `v${api.runtime.getManifest().version}`;
    } catch (error) {
      console.warn("Znuny Helper: Version konnte nicht gelesen werden:", error);
    }
  }

  // ---- Diagnose ---------------------------------------------------------
  // Bewusst rein lesend: kein Netz, keine Aenderung an Einstellungen. Der
  // Bericht ist Text, damit er sich unveraendert in eine Meldung kopieren
  // laesst (auch aus Firefox heraus, wo Objekte zwischen Welten verloren gehen).

  function storageBytes(keys) {
    try {
      const ergebnis = api.storage.local.getBytesInUse(keys);
      if (ergebnis && typeof ergebnis.then === "function") return ergebnis;
    } catch {
      /* Chrome ohne Callback -> unten nachholen */
    }
    return new Promise((resolve) => api.storage.local.getBytesInUse(keys, resolve));
  }

  function aktiverTab() {
    if (usesPromiseStorage) return api.tabs.query({ active: true, currentWindow: true });
    return new Promise((resolve) => api.tabs.query({ active: true, currentWindow: true }, resolve));
  }

  function frageContentSkript(tabId) {
    if (usesPromiseStorage) {
      return api.tabs.sendMessage(tabId, { typ: "zh-diagnose" }).catch(() => null);
    }
    return new Promise((resolve) => {
      try {
        api.tabs.sendMessage(tabId, { typ: "zh-diagnose" }, (antwort) => {
          void api.runtime.lastError;
          resolve(antwort || null);
        });
      } catch {
        resolve(null);
      }
    });
  }

  async function kopiereText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fallback fuer Umgebungen ohne Clipboard-Berechtigung im Popup.
      const hilfsfeld = document.createElement("textarea");
      hilfsfeld.value = text;
      hilfsfeld.style.position = "fixed";
      hilfsfeld.style.opacity = "0";
      document.body.appendChild(hilfsfeld);
      hilfsfeld.select();
      let ok = false;
      try {
        ok = document.execCommand("copy");
      } catch {
        ok = false;
      }
      hilfsfeld.remove();
      return ok;
    }
  }

  function formatiereDiagnose(bericht, tabs, groessen) {
    const zeilen = [];
    const version = (() => {
      try {
        return api.runtime.getManifest().version;
      } catch {
        return "?";
      }
    })();

    zeilen.push(`Znuny Helper ${version}`);
    zeilen.push(`Zeit: ${new Date().toISOString()}`);
    zeilen.push("");

    if (!bericht || !bericht.ok || !bericht.bericht) {
      zeilen.push("Seite: kein Znuny-Content-Script erreichbar");
      zeilen.push(`Aktiver Tab: ${tabs?.url || "(unbekannt)"}`);
    } else {
      const daten = bericht.bericht;
      zeilen.push(`Seite: ${daten.seite.art}`);
      zeilen.push(`URL: ${daten.seite.url}`);
      zeilen.push(`Titel: ${daten.seite.titel}`);
      zeilen.push(
        `Ticketliste: ${daten.ticketliste.erkannt ? "erkannt" : "nicht erkannt"}, ` +
        `${daten.ticketliste.zeilen} Zeile(n), Ticketspalte ${daten.ticketliste.ticketspalte}`
      );
      if (daten.ticketliste.spalten.length) {
        zeilen.push(`Spalten: ${daten.ticketliste.spalten.join(" | ")}`);
      }
      zeilen.push("");
      zeilen.push("Einstellungen:");
      Object.entries(daten.einstellungen).forEach(([schluessel, wert]) => {
        zeilen.push(`  ${schluessel}: ${Array.isArray(wert) ? wert.join(", ") : wert}`);
      });
      zeilen.push("");
      zeilen.push(`Letzte Meldungen (${daten.fehler.length}):`);
      if (!daten.fehler.length) zeilen.push("  keine");
      daten.fehler.forEach((eintrag) => zeilen.push(`  [${eintrag.zeit}] ${eintrag.art}: ${eintrag.text}`));
    }

    zeilen.push("");
    zeilen.push("Speicher:");
    if (groessen.gesamt === null) {
      zeilen.push("  Groesse nicht verfuegbar");
    } else {
      zeilen.push(`  gesamt: ${groessen.gesamt} Bytes`);
      Object.entries(groessen.einzeln).forEach(([schluessel, wert]) => {
        zeilen.push(`  ${schluessel}: ${wert === null ? "?" : `${wert} B`}`);
      });
    }

    return zeilen.join("\n");
  }

  async function zeigeDiagnose() {
    const tabs = await aktiverTab();
    const tab = Array.isArray(tabs) ? tabs[0] : null;
    const bericht = tab?.id ? await frageContentSkript(tab.id) : null;

    let gesamt = null;
    const einzeln = {};
    try {
      gesamt = await storageBytes(null);
      for (const schluessel of STORAGE_KEYS) {
        einzeln[schluessel] = await storageBytes([schluessel]);
      }
    } catch {
      gesamt = null;
    }

    const text = formatiereDiagnose(bericht, tab, { gesamt, einzeln });
    if (diagnoseOutput) {
      diagnoseOutput.hidden = false;
      diagnoseOutput.textContent = text;
    }

    const kopiert = await kopiereText(text);
    status.textContent = kopiert ? "Diagnose kopiert" : "Diagnose angezeigt (Kopieren fehlgeschlagen)";
    window.setTimeout(() => {
      status.textContent = "Bereit";
    }, 2600);
  }

  function initDiagnose() {
    diagnoseCopy?.addEventListener("click", () => {
      zeigeDiagnose().catch((error) => {
        status.textContent = "Diagnose fehlgeschlagen";
        console.warn("Znuny Helper: Diagnose fehlgeschlagen:", error);
      });
    });
  }

  async function init() {
    showVersion();

    const stored = await storageGet({ [SETTINGS_KEY]: DEFAULT_SETTINGS });
    writeForm({ ...DEFAULT_SETTINGS, ...(stored[SETTINGS_KEY] || {}) });
    updatePendingPresetState();
    form.addEventListener("change", () => {
      updatePendingPresetState();
      save();
    });

    const storedSound = await storageGet({ [TICKET_SOUND_CONFIG_KEY]: ticketSoundConfig });
    ticketSoundConfig = normalizeTicketSoundConfig(storedSound[TICKET_SOUND_CONFIG_KEY]);
    renderSoundSelect();
    renderCustomSoundList();
    initSoundSettings();
    initDiagnose();
  }

  init().catch((error) => {
    status.textContent = "Fehler beim Laden";
    console.warn("Znuny Helper popup failed:", error);
  });
})();
