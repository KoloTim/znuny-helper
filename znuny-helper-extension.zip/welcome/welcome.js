(function () {
  "use strict";

  const api = typeof browser !== "undefined" ? browser : chrome;
  const params = new URLSearchParams(window.location.search);
  const reason = params.get("reason") || "install";
  const previousVersion = params.get("previousVersion") || "";
  const manifest = api.runtime.getManifest();

  const releases = [
    {
      version: "1.6.26",
      items: [
        "EASM-Bewertung liest jetzt alle Artikel – der neueste ist oft nur eine Notiz, dadurch blieb die Marke leer.",
        "Neu: Knopf „Priorität: … setzen“ übernimmt die Einstufung ins Ticket – mit Rückfrage, geschrieben wird erst nach „Setzen“."
      ]
    },
    {
      version: "1.6.25",
      items: [
        "Pinball mit vier Leveln (Y-Kreuz, Stern, Zickzack, Tannenbaum) – jedes Level mit Punktziel, jeder Durchlauf neu gemischt und mit weniger Hindernissen.",
        "Neue Ballphysik mit fester Schrittweite: läuft flüssig unabhängig von der Bildrate, springt nicht durch Hindernisse."
      ]
    },
    {
      version: "1.6.24",
      items: [
        "EASM-Bewertung nur noch bei EASM-Tickets und standardmäßig aus – im Popup einschaltbar.",
        "Die große Suchverlaufs-Anzeige ist entfernt; die kleinen Vorschläge unter den Suchfeldern bleiben.",
        "HSRW-Logo in der Pinball-Kopfzeile exakt nachgebaut, Kugeln und Lämpchen weichen jetzt dem Mauszeiger aus."
      ]
    },
    {
      version: "1.6.23",
      items: [
        "Pinball überarbeitet: Die Pins sind jetzt Kapseln im Stil der HSRW-Y-Striche, Treffer sitzen genau. Abschussrampe mit Power-Leiste (Leertaste), kräftigere Flipper, Punkte-Popups und Kugelspur."
      ]
    },
    {
      version: "1.6.22",
      items: [
        "Tannenbaum neu: gezahnte Nadel-Silhouette mit Schneehauben statt Dreiecken – und ohne Kasten beim Klicken.",
        "Mistelzweig mit fünf Blättern und Beeren neu gezeichnet.",
        "Pinball trägt jetzt das HSRW-Logo und begrüßt mit einer Elfe: „Oh, du hast eine kleine Auszeit verdient.“"
      ]
    },
    {
      version: "1.6.21",
      items: [
        "Neu: HSRW-Pinball – dreimal auf den Tannenbaum klicken und losspielen (Pfeiltasten/A+D, Leertaste, Esc).",
        "Tannenbaum bleibt jetzt im Bild statt aus dem Fenster zu rutschen."
      ]
    },
    {
      version: "1.6.20",
      items: [
        "Das Seil der Girlande ist jetzt zweifarbig und damit auch auf der grauen Kopfleiste zu sehen."
      ]
    },
    {
      version: "1.6.19",
      items: [
        "Der Schnee weicht der Maus aus: Flocken werden im Umkreis von 150 Pixeln vom Zeiger weggestoßen und beruhigen sich, sobald er stehen bleibt."
      ]
    },
    {
      version: "1.6.18",
      items: [
        "Neu: EASM-Bewertung – Knopf neben dem Tickettitel liest die Criticality-Stufen aus dem neuesten Artikel und zeigt die schwerste als farbige Marke (z. B. CRIT · 1×CRIT 1×HIGH). Nur lesend, im Popup abschaltbar.",
        "Deko: Baum und Mistelzweig bleiben sichtbar und rutschen bei wenig Platz nur zur Seite."
      ]
    },
    {
      version: "1.6.17",
      items: [
        "Deko verdeckt keine Ticketzeilen mehr: Baum und Mistelzweig erscheinen nur, wenn die Seite nicht scrollt und das Fenster breit genug ist."
      ]
    },
    {
      version: "1.6.16",
      items: [
        "Mistelzweig jetzt im klassischen Motiv: gelappte Stechpalmenblätter mit roten Beeren, kompakter in der Ecke.",
        "Tannenbaum unten rechts, eine Etage weniger und mehr Glitzer."
      ]
    },
    {
      version: "1.6.15",
      items: [
        "Schnee ruhiger: weniger Flocken, langsamer und transparenter – Schneefall statt Schneesturm.",
        "Der Weihnachtsmann wirbelt beim Vorbeiflug die Flocken um sich herum auf."
      ]
    },
    {
      version: "1.6.14",
      items: [
        "Girlande nicht mehr verzerrt: Sie wird passend zur Fensterbreite gezeichnet – Kugeln bleiben rund, Abstände gleich. Bei Fensteränderung wird sie neu aufgebaut.",
        "Baumspitze nicht mehr doppelt, Mistelzweig oben rechts neu gezeichnet (runde Blätter, Beeren)."
      ]
    },
    {
      version: "1.6.13",
      items: [
        "Echter Schnee: sechszackige Schneeflocken in drei Tiefenstaffelungen mit Windböen – fern klein und blass, nah groß und drehend.",
        "Der Tannenbaum hat jetzt Geschenke mit Schleifen darunter."
      ]
    },
    {
      version: "1.6.12",
      items: [
        "Weihnachtsdeko sparsamer: Bei vielen offenen Tabs kostet sie fast keinen Grafikspeicher mehr – Hintergrund-Tabs geben die Schnee-Leinwand frei (gemessen: sechs Tabs 124 MB → 4 MB)."
      ]
    },
    {
      version: "1.6.11",
      items: [
        "Weihnachtsdeko plastischer: Farbverläufe, Glanzlichter und Glow bei Girlande, Baum, Mistelzweig und Weihnachtsmann; Kugeln mit Deckel und Spiegelpunkt."
      ]
    },
    {
      version: "1.6.10",
      items: [
        "Weihnachtsdeo feinjustiert: Kugeln hängen gerade an der Girlande und werden nicht mehr abgeschnitten, Mistelzweig oben rechts, kleiner Tannenbaum unten links.",
        "Der Weihnachtsmann ist freundlicher (Augen, Wangen, Lachen) und fliegt in etwa sieben Sekunden vorbei – mit größeren Geschenken."
      ]
    },
    {
      version: "1.6.9",
      items: [
        "Weihnachtsmodus überarbeitet: Girlande mit Kugeln an der oberen Kante statt Deko in den Ecken (dort sitzen Avatar und Menü).",
        "Der Weihnachtsmann fliegt jetzt alle 15 Minuten mit Schlitten und zwei Rentieren durchs Bild und verliert dabei Geschenke."
      ]
    },
    {
      version: "1.6.8",
      items: [
        "Neu: Weihnachtsmodus (Popup → Saison) – Schnee, Lichterkette, Tannenzweige mit Kugeln, Glitzer und ein Schlitten mit zwei Rentieren. Reine Deko, fängt keine Klicks ab und ist jederzeit abschaltbar."
      ]
    },
    {
      version: "1.6.7",
      items: [
        "Behoben: Beim Verknüpfen schloss sich das Fenster sofort nach „Suchen“ – die Treffer waren weg. Es bleibt jetzt offen, bis Znuny wieder das Ticket zeigt.",
        "Behoben: Die Ticketnummer-Suche setzte unsichtbar „letzte 12 Monate“ und fand deshalb ältere Tickets nicht. Mit Ticketnummer wird kein Zeitraum mehr gesetzt."
      ]
    },
    {
      version: "1.6.6",
      items: [
        "Neu: Diagnose im Popup (Hilfe und Diagnose) – Version, erkannte Seite und Tabelle, Einstellungen, Speicherbelegung und die letzten Meldungen per Klick in die Zwischenablage. Rein lokal.",
        "Behoben: Die Kategorien-Verwaltung schließt jetzt mit Escape – wie Vorschau und Notizfenster."
      ]
    },
    {
      version: "1.6.5",
      items: [
        "Behoben: Entwürfe in der Schnellantwort behalten jetzt die Formatierung – Absätze, Fettungen, Listen und Signatur werden als Editor-Inhalt gespeichert und unverändert wiederhergestellt."
      ]
    },
    {
      version: "1.6.4",
      items: [
        "Behoben: Strg+Enter im Schnellantwort-Fenster – die Content-Scripts laufen nur im obersten Frame, deshalb wird das Fenster jetzt von der Hauptseite aus gebunden. Gilt für alle Aktionen (Antworten, Weiterleiten, Priorität, Notiz, Schließen …)."
      ]
    },
    {
      version: "1.6.3",
      items: [
        "Behoben: Strg+Enter zum Senden funktionierte in der Schnellantwort nicht – das eingebettete Fenster bindet das Tastenkürzel jetzt selbst.",
        "Kundenportal: Die Kategoriespalte wird auch ohne Spaltenkopf „Ticket“ gefunden – Auswahl, Notiz und „Kategorien bearbeiten“ sind dort nutzbar."
      ]
    },
    {
      version: "1.6.2",
      items: [
        "Neu: Ticket-Kategorien jetzt auch im Kundenportal (customer.pl) – Meine Tickets, Firmentickets und die Kundensuche mit automatischer Erkennung, Farben und Notizen; Kategorien und Notizen gelten pro Ticket in beiden Oberflächen.",
        "Im Kundenportal läuft bewusst nur diese Funktion – die Seitenbrücke hält sich dort komplett heraus (kein Eingriff in window.open, Suchformulare oder Popups)."
      ]
    },
    {
      version: "1.6.1",
      items: [
        "Neu: Die Standard-Wartezeit ist im Popup unter \"Antworten und Warten\" einstellbar und steht jetzt auf 7 Tagen (vorher fest 3 Tage).",
        "Neu: Suchverlauf in der globalen Suche – die letzten Suchen mit Suchbegriff, Ticketnummer, Zeitraum und Uhrzeit. Angezeigt werden die letzten fünf, \"Alle anzeigen\" klappt auf bis zu 15 auf; ein Klick übernimmt alles zurück in die Felder, \"Verlauf leeren\" räumt auf.",
        "Behoben (Firefox): \"Antworten\"/\"Weiterleiten\" ohne Vorlagenklick tat gar nichts – die Adresse kam über die Weltgrenze nicht an. Jetzt öffnet sich die Aktion zuverlässig; scheitert Znunys Popup-Schicht, wird sie direkt geöffnet.",
        "Behoben (Firefox): Der gespeicherte Entwurfstext wurde zusammengepresst – Zeilenenden werden jetzt normalisiert und der Entwurf als echte Absätze zurückgegeben.",
        "Behoben: Der Suchverlauf speicherte nichts – die Suche wird jetzt schon beim Klick auf \"Suche starten\" gemerkt, auch wenn Znuny kein Formular-Absenden auslöst.",
        "Behoben: Der Suchverlauf blieb in anderen Znuny-Fenstern leer (der Suchdialog ist ein eigenes Fenster) – jedes Fenster folgt jetzt dem gespeicherten Verlauf, und eine Suche wird auch ganz ohne Klick erkannt.",
        "Die Überschrift \"Suchverlauf\" sitzt jetzt auf derselben Spalte wie die Suchfelder.",
        "Der Zeitraum-Knopf \"Letztes Jahr\" ist entfallen; die drei übrigen Knöpfe stehen jetzt in einer Reihe. Der automatische Standardzeitraum bleibt letztes Jahr bis heute.",
        "Neu: Der orange Hover-Balken der Artikelleiste erscheint jetzt auch unter \"Antworten\" und \"Weiterleiten\" (gleiches Orange, ohne Layoutverschiebung, auch bei Tastaturfokus).",
        "Behoben: Der Suchdialog wurde nach einem Neuaufbau durch Znuny nicht wieder ergänzt – Suchfelder und Verlauf fehlten danach dauerhaft. Die Oberfläche wird jetzt neu aufgebaut, wenn sie verschwunden ist.",
        "Vorlagen-Texte werden wie wiederhergestellte Entwürfe als echte Absätze eingesetzt (kein Zusammenschieben der Zeilen mehr).",
        "Transport von der Seite zum Addon zusätzlich per DOM-Attribut abgesichert (Ticketnummer-Suche, Schnellantwort)."
      ]
    },
    {
      version: "1.6.0",
      items: [
        "Neu: \"Weiterleiten\" läuft jetzt ebenfalls über die Schnellantwort – als Fenster direkt über dem Ticket.",
        "Aufgeräumtes Popup: Einstellungen in abgerundeten Karten je Bereich, zusammengehörige Optionen wie die Warten-Schnellauswahl als eine Einheit (bei ausgeschaltetem Schalter gedimmt), Versionsanzeige im Kopf.",
        "Behoben: Antwort-Entwürfe wurden nicht gespeichert (es wurde das versteckte Editor-Feld statt des sichtbaren Editors gelesen). Jetzt wird auch beim Schließen des Tabs gesichert.",
        "Behoben: In Entwürfen steckte Editor-Quelltext (<br />, &nbsp;) – daraus wird jetzt lesbarer Text, auch bei bereits gespeicherten Entwürfen.",
        "Einstellungen wie die Standard-Wartezeit wirken jetzt sofort auf geöffnete Znuny-Seiten, ohne die Seite neu zu laden.",
        "Behoben: Der Antwort-Tab schließt sich nach dem Übermitteln jetzt zuverlässig, und das Ticket wird anschließend neu geladen.",
        "Tab-Schließen nach dem Übermitteln betrifft nur noch Tabs, die das Addon für eine Aktion geöffnet hat – das Ticket selbst, von Hand geöffnete Tabs und die Schnellantwort bleiben offen.",
        "Neu: Das Schnellantwort-Fenster lässt sich verschieben und an allen Rändern und Ecken in der Größe ändern – per Doppelklick auf den Kopfbereich auf Vollbild. Größe und Position werden gemerkt, \"Ansicht zurücksetzen\" stellt die Standardansicht wieder her, Esc schließt das Fenster.",
        "Neu: Über \"–\" lässt sich das Fenster minimieren, ohne den Formularinhalt zu verlieren.",
        "Neu: Angefangene Antworten gehen beim Schließen nicht mehr verloren – der Text wird als Entwurf gespeichert und beim nächsten Öffnen derselben Aktion wiederhergestellt (mit \"Entwurf verwerfen\"). Nach dem Übermitteln wird der Entwurf gelöscht.",
        "Neu: \"Antworten\" und \"Weiterleiten\" brauchen keinen Vorlagenklick mehr, wenn nur eine Vorlage vorhanden ist – der leere Suchkasten verschwindet und ein Klick auf die Aktion genügt.",
        "Vorlagen und Kategorien werden jetzt sofort gespeichert: Das Schließen des Bearbeiten-Fensters verwirft keine Änderungen mehr.",
        "Die Warten-Schnellauswahl überschreibt kein bereits gewähltes Wartedatum mehr.",
        "Strg+Enter übermittelt bevorzugt das Formular, in dem gerade gearbeitet wird.",
        "Suchhistorie liegt jetzt im Addon-Speicher (bisher im Speicher der Znuny-Seite); vorhandene Einträge werden übernommen.",
        "Behoben: Die Anhang-Vorschau gibt ihren Speicher beim Schließen wieder frei.",
        "Behoben: Ein Suchbegriff, der nur im geöffneten Artikel vorkommt, wird dort jetzt markiert und angesprungen.",
        "Behoben: EB Helper öffnet die EB-Seite ohne Zugriff auf das Ticketfenster; der Knopf heißt korrekt \"Empfangsbestätigung erstellen\".",
        "Behoben: Die Sternchen-Markierung in Ticketlisten reagiert nicht mehr auf Spalten, die nur das Wort \"priority\" enthalten."
      ]
    },
    {
      version: "1.5.2",
      items: [
        "Neu: \"Priorisierung\" lässt sich jetzt über die Schnellantwort öffnen – als Fenster direkt über dem Ticket, inklusive Prioritäts-Vorlagen und Warten-Schnellauswahl.",
        "Behoben: Infinite Scroll lief auch auf geöffneten Ticketseiten und konnte dort Zeilen in fremde Tabellen einfügen (Artikelübersicht, Widget \"Verknüpft\") – sichtbar als einzelne fremde Nummer im Artikelbereich und als Eintrag, der auf das Ticket selbst verweist.",
        "Die Erkennung \"Ticketliste\" ist jetzt aktionsbasiert: Infinite Scroll greift nur noch in echten Listenansichten (Queue-, Sperr-, Besitzer- und Suchansicht).",
        "Widget-Tabellen (Artikelübersicht, \"Verknüpft\", Ticketinformationen, Ähnliche Tickets, Historie, Anhang, Sidebar) werden nicht mehr als Ticketliste behandelt. Beim Nachladen müssen Aktion, Spaltenaufbau und Zellenzahl übereinstimmen.",
        "Behoben: \"Ton bei neuem Ticket\" aktualisierte auch in geöffneten Tickets die Tabelle, obwohl ein offenes Ticket unangetastet bleiben soll.",
        "Behoben: Infinite Scroll blieb nach dem Aus- und wieder Einschalten ohne Seitenneuladen hängen."
      ]
    },
    {
      version: "1.5.1",
      items: [
        "Neu: Vorlagen können jetzt auch Priorität und Auswirkung vorgeben (und aus dem aktuellen Formular übernehmen).",
        "Neu: Typ, Service, Priorität und Auswirkung sind im Vorlagen-Editor jetzt Dropdowns.",
        "Die Prioritäts-Vorlagen sind jetzt standardmäßig aktiv.",
        "Behoben: DOCX- und XLSX-Vorschau in Firefox (Realm-Problem beim Einlesen der Datei).",
        "Behoben: Infinite Scroll lud nach der zweiten Seite nicht weiter bzw. übersprang Seiten. Es blättert jetzt zuverlässig Seite für Seite, bis keine neuen Tickets mehr kommen.",
        "Behoben: Infinite Scroll auf der Suchseite (Ergebnis-Tabelle mit anderen Spaltennamen); auch große Trefferlisten (2000+) werden vollständig geladen.",
        "Behoben: Infinite Scroll in der Queue-Ansicht, die über StartHit paginiert (Seite 2, 3, 4 …).",
        "Behoben: Infinite Scroll konnte in manchen Ansichten endlos Tickets anhängen. Es werden jetzt nur Zeilen mit eindeutiger Ticket-ID geladen und identische Seiten erkannt – eine Endlosschleife ist ausgeschlossen.",
        "Behoben: Nach dem Absenden wird ein eigens geöffneter Aktions-Tab automatisch geschlossen und der Fokus kehrt zum vorherigen Tab zurück (funktioniert auch bei Enter/Strg+Enter und unabhängig von „Popups als Tabs“).",
        "Infinite Scroll lässt die Seitenzahlen wieder sichtbar (als Fallback nutzbar)."
      ]
    },
    {
      version: "1.5.0",
      items: [
        "Neu: Die Tage der Warten-Schnellauswahl sind jetzt im Popup frei einstellbar (z. B. 1, 3, 7, 14). Der erste Wert wird automatisch vorbelegt.",
        "Das Popup ist übersichtlicher: klarere Beschreibungen und sinnvoll gruppierte Optionen.",
        "Infinite Scroll blendet die überflüssigen Seitenzahlen oben rechts in der Ticketliste aus.",
        "Neu: Zwei zusätzliche Benachrichtigungstöne zur Auswahl (Dezenter Ping, Neue Nachricht) – damit sind zehn Sounds eingebaut.",
        "Die Anhang-Erinnerung wurde entfernt."
      ]
    },
    {
      version: "1.4.0",
      items: [
        "Neu: Die Case-/Ticketnummer oben links im geöffneten Ticket lässt sich per Klick kopieren (mit kurzer Bestätigung). Abschaltbar im Popup unter \"Suchen\"."
      ]
    },
    {
      version: "1.3.2",
      items: [
        "Fix: Excel-/Tabellen-Vorschau in Firefox (\"e.replace is not a function\") – die Datei-Bytes werden jetzt realm-sicher als Uint8Array übergeben.",
        "Fix: \"Abbrechen und Schließen\" in per \"Popups als Tabs\" geöffneten Aktionen funktioniert wieder (schließt den Tab); in der Schnellantwort schließt er das eingebettete Fenster.",
        "Fix: Schnellantwort belegt spät nachgeladene Wartedatum-Felder jetzt zuverlässig mit +3 Tagen vor.",
        "Neu: Prioritäts-/Personen-Vorlagen lassen sich gruppieren. Toolbar und Bearbeiten-Dialog sind neu aufgebaut: Kacheln je Vorlage, nach Gruppen sortiert, mit Filter, ausklappbaren Feldern und Hoch/Runter.",
        "Die Kategorien-Bearbeitungsseite ist kompakter (eine Zeile je Kategorie, mitwachsende Keyword-Box).",
        "Der öffentliche Bug-Melde-Link wurde aus Popup und Willkommensseite entfernt."
      ]
    },
    {
      version: "1.3.1",
      items: [
        "Fix: Prioritäts-Vorlagen fehlten in der Schnellantwort für \"Besitzer\" und \"Notiz\" – funktioniert jetzt dort genauso wie auf der normalen Seite (Werkzeugleiste, Felder befüllen, Als Vorlage speichern).",
        "Neu: Schnellantwort deckt zusätzlich \"Schließen\", \"Verknüpfen\" und \"Zusammenfassen\" ab."
      ]
    },
    {
      version: "1.3.0",
      items: [
        "Neu: Schnellantwort deckt jetzt auch \"Besitzer\" (Personen → Besitzer) und \"Notiz\" (Kommunikation → Notiz) ab, nicht mehr nur Antworten/Allen-antworten. Öffnen bei aktivierter Schnellantwort ebenfalls als eingebettetes Fenster im Ticket, inklusive Ctrl+Enter und Warten-Schnellauswahl."
      ]
    },
    {
      version: "1.2.7",
      items: [
        "Sicherheit: Wenn die PDF-Vorschau nicht sicher als PDF bestätigt werden kann (seltener Fallback-Fall), wird der Anhang nicht mehr automatisch in einem Rahmen geöffnet, sondern nur noch über einen Download-Link nach bewusstem Klick."
      ]
    },
    {
      version: "1.2.6",
      items: [
        "Fix: PDF-Vorschau in Chrome/Edge war weiterhin kaputt. Ursache: Der eingebaute PDF-Betrachter aktiviert sich grundsätzlich nicht innerhalb eines sandboxed iframes (bekanntes Chromium-Verhalten). Sandbox für die PDF-Vorschau entfernt; der Betrachter läuft ohnehin bereits browser-seitig isoliert."
      ]
    },
    {
      version: "1.2.5",
      items: [
        "Fix: Die PDF-Vorschau war seit der letzten Version kaputt (leere/blockierte Vorschau). Die dort ergänzte Absicherung liess PDFs nicht mehr laden; jetzt behoben, ohne die Absicherung selbst zurückzunehmen."
      ]
    },
    {
      version: "1.2.4",
      items: [
        "Fix: Die Sichtbarkeitsprüfung für Formularfelder berücksichtigte innerhalb der Schnellantwort das falsche Fenster, wodurch die Warten-Schnellauswahl dort trotz des vorherigen Fixes weiterhin nicht erschien."
      ]
    },
    {
      version: "1.2.3",
      items: [
        "Fix: Die Warten-Schnellauswahl erschien nicht innerhalb der Schnellantwort. Funktioniert jetzt auch dort, inklusive bei nachträglicher Umstellung auf einen Warten-Status."
      ]
    },
    {
      version: "1.2.2",
      items: [
        "Sicherheit: Die PDF-Vorschau in der Anhang-Vorschau läuft jetzt wie die DOCX-/Tabellen-Vorschau in einem abgesicherten (\"sandboxed\") Vorschaufenster ohne Skriptausführung."
      ]
    },
    {
      version: "1.2.1",
      items: [
        "Fix: Strg+Enter zum Senden funktionierte innerhalb der Schnellantwort nicht.",
        "Fix: Nach dem Absenden einer Schnellantwort blieb die Ticketseite unverändert stehen, statt die neue Antwort zu zeigen.",
        "Schnellantwort trägt nicht mehr den Zusatz \"(Beta)\"."
      ]
    },
    {
      version: "1.2.0",
      items: [
        "Neu: Schnellantwort – \"Antworten\" und \"Allen antworten\" öffnen wahlweise als kleines Fenster direkt über dem Ticket statt in einem neuen Tab. Nach dem Absenden schliesst es sich automatisch und das Ticket wird aktualisiert. Standardmässig aus, einschaltbar im Popup."
      ]
    },
    {
      version: "1.1.1",
      items: [
        "Prioritäts-Vorlagen funktionieren jetzt auch beim \"Neues Telefon-Ticket\"-Formular, nicht mehr nur bei Besitzer-/Prioritäts-Aktionen."
      ]
    },
    {
      version: "1.1.0",
      items: [
        "Neu: Bilder, die bereits im Ticketartikel angezeigt werden (z. B. eingebettete Bilder aus HTML-Mails), sind jetzt anklickbar und öffnen sich vergrößert.",
        "Neu: Drei zusätzliche, dezente Benachrichtigungstöne für \"Ton bei neuem Ticket\" (Sanfter Ping, Zwei-Ton-Chime, Weicher Klick) – Sanfter Ping ist jetzt der Standard.",
        "Geändert: Prioritäts-Vorlagen und Ton bei neuem Ticket sind jetzt standardmäßig deaktiviert.",
        "Fix: Tab-Schließen nach dem Übermitteln blieb manchmal offen oder schloss gar nicht automatisch.",
        "Fix: Ton bei neuem Ticket erkannte neue Tickets in manchen Tabs nicht zuverlässig und konnte bei mehreren offenen Znuny-Tabs mehrfach auslösen."
      ]
    },
    {
      version: "1.0.0",
      items: [
        "Neu: Der Znuny Helper ist jetzt für Chrome, Edge und Firefox verfügbar.",
        "Neu: Ton bei neuem Ticket – spielt einen wählbaren Sound ab, sobald ein neues Ticket bei dir gesperrt wird, und aktualisiert dabei automatisch die gerade sichtbare Ticketliste. Fünf Sounds sind eingebaut, eigene Sounds lassen sich hinzufügen und wieder entfernen.",
        "Infinite Scroll: mehrere Zuverlässigkeitsprobleme behoben (falsche Folgeseite, Aussetzer nach erneutem Ein-/Ausschalten, hängender Retry nach Netzwerkfehlern).",
        "Prioritäts-Vorlagen: \"Als Vorlage speichern\" erfasst jetzt zuverlässig alle Felder (Typ, Queue, Service, Besitzer, Kategorie), auch wenn sie als Tag-Auswahl dargestellt werden."
      ]
    },
    {
      version: "0.1.44",
      items: [
        "Ticket-Kategorien: Farben werden jetzt so gesetzt, dass Dark-Reader-artige Addons sie seltener plattbügeln (betroffene Farben blieben zuvor alle gleich dunkel).",
        "Ticket-Kategorien: Keyword \"laptop\"/\"notebook\" zu Hardware/Abholung ergänzt, damit z. B. \"Neuer Arbeitslaptop benötigt\" korrekt erkannt wird."
      ]
    },
    {
      version: "0.1.43",
      items: [
        "Ticket-Kategorien: automatische Erkennung ist zurück, neu aufgebaut mit sechs Themen-Kategorien (Dringend/Störung, Externe Zuständigkeit, Software/Zugang, Hardware/Abholung, Studis, Warten/Rückmeldung).",
        "Automatisch erkannte Kategorien sind jetzt klar als Vorschlag markiert (kursiv, gestrichelter Rahmen, \"(Vorschlag)\") und nie mit einer manuellen Auswahl zu verwechseln.",
        "Kategorien bearbeiten: Keywords sind wieder pflegbar; die Reihenfolge der Kategorien bestimmt jetzt sichtbar auch die Priorität bei mehrdeutigen Treffern."
      ]
    },
    {
      version: "0.1.42",
      items: [
        "Neu: Tastenkürzel Strg+Enter übermittelt das aktuelle Formular (Antwort, Notiz, Schließen, ...); der Tab schließt danach wie gewohnt automatisch."
      ]
    },
    {
      version: "0.1.41",
      items: [
        "Neu: Knopf \"Als Vorlage speichern\" auf Prioritätsseiten übernimmt die aktuell ausgefüllten Felder direkt als neue Prioritäts-Vorlage.",
        "Prioritäts-Vorlagen bearbeiten: Design überarbeitet (klarere Karten, bessere Abstände) und ein Problem behoben, durch das der erzwungene Dunkelmodus des Browsers das Fenster unleserlich machen konnte."
      ]
    },
    {
      version: "0.1.40",
      items: [
        "Anhang-Vorschau: PDFs, deren Server-Antwort keinen application/pdf-Typ meldet, werden jetzt korrekt im Browser angezeigt statt als unbenannte Datei heruntergeladen."
      ]
    },
    {
      version: "0.1.39",
      items: [
        "Prioritäts-Vorlagen: Anzeige auf der Antwortseite wieder entfernt (Platzierung passte dort nicht).",
        "Ticket-Kategorien: Farben auf dezente Pastelltöne umgestellt (Fertig ist jetzt grau statt schwarz).",
        "Ticket-Kategorien: automatische Erkennung per Keywords entfernt, Kategorien werden nur noch manuell gesetzt.",
        "Zeitraum-Schnellauswahl in der Suche: Ausrichtung korrigiert, damit sie sauber mit den anderen Suchfeldern fluchtet."
      ]
    },
    {
      version: "0.1.38",
      items: [
        "Neu: Anhang-Erinnerung auf der Antwortseite, wenn der Text einen Anhang erwähnt, aber keiner angehängt ist.",
        "Neu: Schnellknöpfe für Wartedatum (+3/+7/+14 Tage, Standard 3) überall dort, wo ein Warten-Status ein Datum verlangt.",
        "Neu: Schnellauswahl Zeitraum (letzte Woche/Monat/Quartal/Jahr) in der Ticket-Suche.",
        "Ticket-Kategorien: Standardkategorien auf Ampelschema umgestellt (Neu/Wartend/Wichtig/Fertig) und Import/Export zum Teilen ergänzt.",
        "Prioritäts-Vorlagen: auf der Antwortseite nutzbar und ebenfalls per Import/Export teilbar."
      ]
    },
    {
      version: "0.1.37",
      items: [
        "Funktionseinstellungen nutzen jetzt lokalen statt synchronisierten Speicher, damit sie unter Firefox zuverlässig laden und speichern.",
        "Doppelt definierte interne Funktionen für den Extern-Hinweis auf Prioritätsseiten entfernt."
      ]
    },
    {
      version: "0.1.36",
      items: [
        "Tabs von Mail-Antworten werden nach \"E-Mail übermitteln\" automatisch geschlossen."
      ]
    },
    {
      version: "0.1.35",
      items: [
        "Vorlagen werden jetzt auch auf der Seite \"Besitzer wechseln\" angezeigt.",
        "Tabs von Mail-Antworten werden nach \"Übermitteln\" zuverlässiger geschlossen."
      ]
    },
    {
      version: "0.1.34",
      items: [
        "Sichtbare Texte wurden auf echte deutsche Umlaute umgestellt."
      ]
    },
    {
      version: "0.1.33",
      items: [
        "Der Extern-Hinweis auf Prioritätsseiten wird nun direkt neben \"Ist sichtbar für Kunde\" angezeigt.",
        "Der zusätzliche Hinweis im Vorlagenkasten wurde entfernt."
      ]
    },
    {
      version: "0.1.32",
      items: [
        "Externe Kunden werden auf Prioritätsseiten auch über EXTERN-Markierungen im Titel erkannt.",
        "Der Warnhinweis unter \"Ist sichtbar für Kunde\" wurde robuster platziert."
      ]
    },
    {
      version: "0.1.31",
      items: [
        "Externe Kunden werden auf Prioritätsseiten zusätzlich unten beim Bereich \"Ist sichtbar für Kunde\" markiert."
      ]
    },
    {
      version: "0.1.30",
      items: [
        "Willkommens- und Changelog-Seite bei Installation und Updates ergänzt.",
        "EB Helper ist standardmäßig deaktiviert.",
        "Suchergebnisse im neuen Tab sind standardmäßig deaktiviert."
      ]
    },
    {
      version: "0.1.29",
      items: [
        "Hinweis auf Prioritätsseiten ergänzt, wenn eine externe Kundenadresse erkannt wird."
      ]
    },
    {
      version: "0.1.28",
      items: [
        "XLSX-Vorschau robuster gemacht.",
        "Infinite Scroll lädt toleranter weiter.",
        "Suchdialog räumt leere Filterzeilen besser auf."
      ]
    },
    {
      version: "0.1.27",
      items: [
        "XLSX-Vorschau als statische Tabelle ergänzt.",
        "DOCX-, EML-, LOG- und TXT-Vorschau verbessert."
      ]
    }
  ];

  function renderChangelog() {
    const root = document.getElementById("changelog");
    root.textContent = "";

    releases.forEach((release) => {
      const section = document.createElement("section");
      section.className = "release";

      const title = document.createElement("h3");
      title.textContent = `Version ${release.version}`;
      section.appendChild(title);

      const list = document.createElement("ul");
      release.items.forEach((item) => {
        const li = document.createElement("li");
        li.textContent = item;
        list.appendChild(li);
      });
      section.appendChild(list);
      root.appendChild(section);
    });
  }

  function renderHeader() {
    const eyebrow = document.getElementById("eyebrow");
    if (reason === "update") {
      eyebrow.textContent = previousVersion
        ? `Znuny Helper wurde von ${previousVersion} auf ${manifest.version} aktualisiert`
        : `Znuny Helper wurde auf ${manifest.version} aktualisiert`;
    } else {
      eyebrow.textContent = `Znuny Helper ${manifest.version} installiert`;
    }

    document.getElementById("version").textContent = `Version ${manifest.version}`;
  }

  renderHeader();
  renderChangelog();
})();
