(function () {
  "use strict";

  const SETTINGS_KEY = "znunyHelperSettings";
  const TICKET_STATE_KEY = "znunyHelperTicketState";
  const SEARCH_HISTORY_KEY = "znunyHelperSearchHistory";
  const SEARCH_HISTORY_LIMIT = 15;
  const SEARCH_HISTORY_VISIBLE = 5;
  const CATEGORY_CONFIG_KEY = "znunyHelperCategoryConfig";
  const PRIORITY_TEMPLATE_CONFIG_KEY = "znunyHelperPriorityTemplateConfig";
  const TICKET_SOUND_CONFIG_KEY = "znunyHelperTicketSoundConfig";
  const TICKET_SOUND_SEEN_KEY = "znunyHelperSeenLockedTicketIds";
  const QUICK_REPLY_LAYOUT_KEY = "znunyHelperQuickReplyLayout";
  const QUICK_REPLY_DRAFT_KEY = "znunyHelperQuickReplyDrafts";
  const QUICK_REPLY_DRAFT_LIMIT = 10;
  const EB_BASE_URL = "https://digi-eb.staff.hsrw/new";
  const TEXT_PREVIEW_LIMIT = 2 * 1024 * 1024;
  const SPREADSHEET_PREVIEW_MAX_ROWS = 1000;
  const SPREADSHEET_PREVIEW_MAX_COLS = 80;
  const TICKET_SOUND_CHECK_INTERVAL_MS = 60000;
  // Actions the quick-reply drawer knows how to embed: replying (Compose),
  // forwarding (Forward), changing the owner (Owner), setting the priority
  // (Priority), adding a note (Note), closing (Close), linking (LinkObject) and
  // merging (Merge). AgentTicketPriority is the same action the priority templates
  // already target, so it is verified on this instance. The Close/Merge/LinkObject
  // action names are our best-known guess at the standard Znuny naming and are
  // unverified against this live instance — if one of them doesn't trigger the
  // drawer, the link simply falls back to its normal tab/popup behaviour, so this is
  // safe to leave in place either way.
  // Keep this in sync with isQuickReplyEligibleUrl in page-bridge.js.
  const QUICK_REPLY_ACTION_PATTERN = /Action=(?:AgentTicket(?:Compose|Forward|Owner|Priority|Note|Close|Merge)|AgentLinkObject)\b/i;
  // A quick-reply action is only finished when Znuny shows the ticket (or a
  // list) again. Deliberately NOT "any URL without Action": the link action's
  // search POSTs to /otrs/index.pl and renders its results under exactly that
  // bare address. Treating that as "done" closed the drawer before the agent
  // could pick a ticket - reported as "the modal closes immediately".
  const QUICK_REPLY_FINISHED_PATTERN =
    /Action=(?:AgentTicketZoom|AgentTicket(?:Queue|LockedView|OwnerView|ResponsibleView|WatchView|StatusView|EscalationView)|AgentDashboard)\b/i;
  // Visible captions of the article actions whose hover bar is rebuilt (see
  // markArticleActionLabel): localized Znuny names of reply and forward.
  const ARTICLE_ACTION_LABEL_PATTERN = /^(?:Antworten|Allen antworten|Weiterleiten|Reply|Reply to all|Forward)$/i;

  const DEFAULT_SETTINGS = {
    popupTabs: true,
    attachmentPreview: true,
    ticketNumberSearch: true,
    searchResultsPopup: false,
    ticketArticleSearch: true,
    ticketNumberCopy: true,
    pendingDatePresets: [3, 7, 14],
    ebHelper: false,
    priorityTemplates: true,
    ticketCategories: true,
    ticketListInfiniteScroll: true,
    pendingDateButtons: true,
    pendingDateDefaultDays: 7,
    keyboardShortcuts: true,
    assignedTicketSound: false,
    quickReply: false,
    directArticleActions: true,
    easmRating: false,
    christmasMode: true
  };

  const BUILTIN_TICKET_SOUNDS = [
    { id: "soft-ping", name: "Sanfter Ping", file: "sounds/soft-ping.wav" },
    { id: "two-tone-chime", name: "Zwei-Ton-Chime", file: "sounds/two-tone-chime.wav" },
    { id: "soft-click", name: "Weicher Klick", file: "sounds/soft-click.wav" },
    { id: "subtle-ping", name: "Dezenter Ping", file: "sounds/subtle-ping.mp3" },
    { id: "message-notification", name: "Neue Nachricht", file: "sounds/message-notification.mp3" },
    { id: "icq", name: "ICQ", file: "sounds/icq.mp3" },
    { id: "iphone", name: "iPhone", file: "sounds/iphone.mp3" },
    { id: "minecraft-chicken-1", name: "Minecraft Huhn 1", file: "sounds/minecraft-chicken-1.mp3" },
    { id: "minecraft-chicken-2", name: "Minecraft Huhn 2", file: "sounds/minecraft-chicken-2.mp3" },
    { id: "whatsapp", name: "WhatsApp", file: "sounds/whatsapp.mp3" }
  ];

  const DEFAULT_PRIORITY_TEMPLATES = [
    {
      id: "assignment-to-agent",
      title: "Assignment to Agent",
      color: "#3976bb",
      fields: {
        type: "ServiceRequest",
        queue: "2nd Line",
        service: "Person",
        owner: "Tim Kolodzej",
        category: "Authorisation",
        subject: "Assignment to Agent",
        body: "s.u,"
      }
    }
  ];

  // Dropdown options for the template editor. Values outside these lists are
  // still accepted and preserved when editing an existing template.
  const PRIORITY_TEMPLATE_FIELD_OPTIONS = {
    type: ["Incident", "Problem", "ServiceRequest", "Unclassified"],
    service: ["Gruppen", "Person", "Standort/Organisation"],
    priority: ["high", "critical", "low", "normal"],
    impact: ["Arbeit eingeschränkt", "Arbeit uneingeschränkt", "Arbeit unmöglich"]
  };

  // Order below doubles as auto-detection priority (checked top to bottom, first keyword
  // match wins) - see getCategoryGroups()/autoDetectCategory(). Keep the most urgent /
  // most specific categories first so they win over broader ones on overlapping keywords.
  const DEFAULT_GROUPS = [
    { id: "", title: "Ohne Kategorie", short: "Keine", color: "", order: 1 },
    { id: "dringend", title: "Dringend / Störung", short: "Dringend", color: "#ffd6d6", order: 2 },
    { id: "extern", title: "Externe Zuständigkeit", short: "Extern", color: "#ead8ff", order: 3 },
    { id: "software", title: "Software / Zugang", short: "Software", color: "#d9ecff", order: 4 },
    { id: "hardware", title: "Hardware / Abholung", short: "Hardware", color: "#ffe4c4", order: 5 },
    { id: "studis", title: "Studis", short: "Studis", color: "#d8ffd8", order: 6 },
    { id: "wartend", title: "Warten / Rückmeldung", short: "Wartend", color: "#fff3b0", order: 7 }
  ];

  const DEFAULT_KEYWORDS = {
    dringend: [
      "dringend", "sofort", "akut", "notfall", "kompletter ausfall", "komplettausfall",
      "heute noch", "kein zugriff", "keinen zugriff", "produktion steht", "urgent",
      "kritisch", "critical", "asap", "blockiert", "geht nicht mehr", "geht gar nicht",
      "funktioniert nicht mehr", "totalausfall", "system down", "alles steht", "ausfall",
      "stoerung", "störung"
    ],
    extern: [
      "campusmanagement", "personalservice", "marketing", "student services",
      "studierendenservice", "studierenden-service", "personalrat", "dekanat", "drvis",
      "pruefungsamt", "prüfungsamt", "applicant portal", "bewerberportal", "bewerber",
      "uni-assist", "uniassist"
    ],
    software: [
      "vpn", "f5", "big-ip", "bigip", "edge client", "yubikey", "ubikey", "2fa", "mfa",
      "duo", "otp", "access denied", "zugriff verweigert", "portal.hsrw.cloud",
      "outlook", "owa", "postfach", "mail-kle", "preauthentication", "pre-authentication",
      "passwort", "password", "kennwort", "account gesperrt", "konto gesperrt", "gesperrt",
      "login fehlgeschlagen", "anmeldung fehlgeschlagen", "zugang", "login", "anmeldung",
      "adobe", "citavi", "webex", "teams", "sciebo", "lizenz", "license", "sharepoint",
      "onedrive", "sap", "his", "qis", "ldap", "windows", "office", "browser", "zertifikat",
      "installation", "installieren", "programm", "software", "endpoint", "e-mail", "email"
    ],
    hardware: [
      "dockingstation", "docking station", "docking", "laptop abholen", "notebook abholen",
      "abholung", "abholen", "uebergabe", "übergabe", "bestellen", "bestellung", "beschaffen",
      "beschaffung", "inventarnummer", "inventar-nr", "akku", "tastatur", "monitor",
      "bildschirm", "netzteil", "defekt", "kaputt", "reparatur", "reparieren", "neugeraet",
      "neugerät", "neues notebook", "neues geraet", "neues gerät", "zur abholung bereit",
      "drucker", "printer", "scanner", "webcam", "headset", "maus", "thinclient",
      "thin client", "geraet", "gerät", "hardware", "rechner", "laptop", "notebook",
      "arbeitslaptop"
    ],
    studis: [
      "matrikelnummer", "matrikel-nr", "matrikel", "hisinone", "his in one", "moodle",
      "einschreibung", "exmatrikulation", "semesteranmeldung", "studienbescheinigung",
      "qisserver", "student", "studi", "studierende", "studium", "enrollment", "semester",
      "pruefung", "prüfung", "pruefungs", "prüfungs", "bewerbung", "campus", "eduroam",
      "abschlussarbeit", "thesis", "praktikum", "@students.hsrw"
    ],
    wartend: [
      "keine rueckmeldung", "keine rückmeldung", "wartet auf user", "wartet auf kunde",
      "wartet auf kunden", "bitte bescheid geben", "urlaub", "nicht erreichbar",
      "warte auf antwort", "warten auf antwort", "noch keine reaktion", "rueckmeldung",
      "rückmeldung", "feedback", "nachfrage", "termin", "terminvereinbarung", "abstimmung",
      "pending", "on hold"
    ]
  };

  const api = typeof browser !== "undefined" ? browser : chrome;
  const usesPromiseStorage = typeof browser !== "undefined";
  let settings = { ...DEFAULT_SETTINGS };

  // Kleiner Ringpuffer fuer die Diagnose im Popup. Er sammelt nur die letzten
  // Warnungen/Fehler dieser Seite, damit eine Meldung wie "geht nicht" ohne
  // Rueckfragen auswertbar ist. Rein lokal, nichts wird gesendet.
  const DIAGNOSE_FEHLER_LIMIT = 20;
  const diagnoseFehler = [];

  function merkeDiagnoseFehler(art, text) {
    diagnoseFehler.push({
      art,
      zeit: new Date().toISOString().slice(11, 19),
      text: String(text).replace(/\s+/g, " ").slice(0, 400)
    });
    if (diagnoseFehler.length > DIAGNOSE_FEHLER_LIMIT) diagnoseFehler.shift();
  }

  function installDiagnoseProtokoll() {
    // Nur die eigene Welt: Content-Script-Logs landen in derselben Konsole,
    // die Kapselung betrifft aber ausschliesslich Aufrufe aus diesem Skript.
    ["warn", "error"].forEach((art) => {
      const original = console[art].bind(console);
      console[art] = (...args) => {
        try {
          merkeDiagnoseFehler(
            art,
            args.map((wert) => (wert && wert.message) ? wert.message : String(wert)).join(" ")
          );
        } catch {
          /* Diagnose darf nie den Betrieb stoeren */
        }
        return original(...args);
      };
    });

    window.addEventListener("error", (event) => {
      const text = event?.error?.message || event?.message || "";
      if (text) merkeDiagnoseFehler("uncaught", text);
    });
  }

  let ticketState = { categories: {}, notes: {} };
  let categoryConfig = null;
  let priorityTemplateConfig = { templates: DEFAULT_PRIORITY_TEMPLATES };
  let priorityTemplateFilter = "";
  const priorityTemplateOpenIds = new Set();
  let ticketSoundConfig = { customSounds: [], selectedId: BUILTIN_TICKET_SOUNDS[0].id };
  // Remembered size/position of the quick-reply drawer. Zero/null means "use the
  // default" (bottom right), so a stored layout only takes over once the user
  // actually resized or moved the window.
  let quickReplyLayout = { width: 0, height: 0, left: null, top: null, maximized: false };
  // Unsubmitted reply texts, keyed by "<Action>|<TicketID>". Written when the drawer
  // is closed and restored the next time the same action is opened for that ticket.
  let quickReplyDrafts = {};
  let openNoteTicketId = null;
  // Object URL of the attachment preview that is currently open. It must be
  // released when the preview closes; otherwise the whole previewed file stays in
  // memory until the page is left.
  let previewObjectUrl = "";
  let scanQueued = false;
  let searchModalFixQueued = false;
  let suppressMutationScanUntil = 0;
  let infiniteScrollState = {
    enabledUrl: "",
    nextUrl: "",
    loading: false,
    done: false,
    bound: false,
    hasLoadedPage: false,
    currentPage: 0,
    failCount: 0,
    nextRetryAt: 0,
    seenIds: new Set(),
    loadedPages: new Set(),
    seenFingerprints: new Set(),
    appendedTotal: 0,
    pageParamSupported: false,
    startHitStep: 0,
    pollTimer: 0
  };
  let articleSearchState = {
    terms: [],
    matches: [],
    rowMatches: [],
    blockMatches: [],
    activeIndex: -1,
    debounceTimer: 0,
    runId: 0,
    fetchCache: new Map()
  };

  function normalizeCategoryId(value) {
    return String(value || "")
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_-]+/g, "-")
      .replace(/^-+|-+$/g, "");
  }

  function normalizeCategoryConfig(config) {
    const sourceGroups = Array.isArray(config?.groups) ? config.groups : DEFAULT_GROUPS;
    const sourceKeywords = config?.keywords && typeof config.keywords === "object" ? config.keywords : DEFAULT_KEYWORDS;

    const groups = sourceGroups.map((group, index) => ({
      id: index === 0 ? "" : normalizeCategoryId(group.id || group.short || group.title || `cat-${index}`),
      title: String(group.title || group.short || "Kategorie").trim(),
      short: String(group.short || group.title || "Kat").trim(),
      color: String(group.color || "").trim(),
      order: Number(group.order || index + 1)
    }));

    if (!groups.some((group) => group.id === "")) {
      groups.unshift({ id: "", title: "Ohne Kategorie", short: "Keine", color: "", order: 1 });
    }

    const seenIds = new Set();
    const uniqueGroups = groups.filter((group) => {
      if (seenIds.has(group.id)) return false;
      seenIds.add(group.id);
      return true;
    }).sort((a, b) => a.order - b.order);

    const keywords = {};
    uniqueGroups.forEach((group) => {
      keywords[group.id] = Array.isArray(sourceKeywords[group.id])
        ? sourceKeywords[group.id].map((word) => String(word).trim()).filter(Boolean)
        : [];
    });

    return { groups: uniqueGroups, keywords };
  }

  function getCategoryGroups() {
    if (!categoryConfig) {
      categoryConfig = normalizeCategoryConfig({ groups: DEFAULT_GROUPS, keywords: DEFAULT_KEYWORDS });
    }

    return categoryConfig.groups;
  }

  function getCategoryKeywords() {
    if (!categoryConfig) getCategoryGroups();
    return categoryConfig.keywords;
  }

  function saveCategoryConfig() {
    categoryConfig = normalizeCategoryConfig(categoryConfig);
    syncSet("local", { [CATEGORY_CONFIG_KEY]: categoryConfig });
  }

  function setProtectedFill(element, color) {
    // Dark Reader (and similar recoloring extensions) rewrite plain background-color,
    // which flattens all category colors to the same dark tone. A same-stop gradient
    // renders identically but is generally left alone by those extensions, so the
    // category colors stay distinguishable.
    element.style.background = "";
    element.style.backgroundColor = "";
    element.style.backgroundImage = color ? `linear-gradient(${color}, ${color})` : "";
  }

  function getReadableTextColor(hexColor) {
    const hex = String(hexColor || "").trim();
    if (!/^#[0-9a-f]{6}$/i.test(hex)) return "#111";

    const r = Number.parseInt(hex.slice(1, 3), 16);
    const g = Number.parseInt(hex.slice(3, 5), 16);
    const b = Number.parseInt(hex.slice(5, 7), 16);
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;

    return luminance < 0.55 ? "#fff" : "#111";
  }

  function downloadJsonFile(filename, data) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function importJsonFile(onLoad) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json,.json";
    input.style.display = "none";

    input.addEventListener("change", () => {
      const file = input.files?.[0];
      input.remove();
      if (!file) return;

      const reader = new FileReader();
      reader.onload = () => {
        try {
          onLoad(JSON.parse(String(reader.result || "")));
        } catch (error) {
          window.alert("Datei konnte nicht gelesen werden: ungültiges JSON.");
        }
      };
      reader.readAsText(file);
    });

    document.body.appendChild(input);
    input.click();
  }

  function normalizePriorityTemplateConfig(config) {
    const sourceTemplates = Array.isArray(config?.templates) && config.templates.length
      ? config.templates
      : DEFAULT_PRIORITY_TEMPLATES;

    const templates = sourceTemplates.map((template, index) => {
      const id = String(template.id || `priority-template-${index + 1}`).trim() || `priority-template-${index + 1}`;
      const title = String(template.title || "Vorlage").trim();
      const fields = {
        type: String(template.fields?.type || "").trim(),
        queue: String(template.fields?.queue || "").trim(),
        service: String(template.fields?.service || "").trim(),
        owner: String(template.fields?.owner || "").trim(),
        priority: String(template.fields?.priority || "").trim(),
        impact: String(template.fields?.impact || "").trim(),
        category: String(template.fields?.category || "").trim(),
        subject: String(template.fields?.subject || "").trim(),
        body: String(template.fields?.body || "").trim()
      };
      const isAssignmentTemplate =
        id === "assignment-to-agent" ||
        /assignment\s+to\s+(agent|me)/i.test(title) ||
        /assignment\s+to\s+(agent|me)/i.test(fields.subject);

      if (isAssignmentTemplate) {
        fields.type ||= "ServiceRequest";
        fields.queue ||= "2nd Line";
        fields.service ||= "Person";
        fields.owner ||= "Tim Kolodzej";
        fields.category ||= "Authorisation";
        if (!fields.subject || /^s\.?u\.?,?$/i.test(fields.subject)) fields.subject = "Assignment to Agent";
        fields.body ||= "s.u,";
      }

      return {
        id,
        title,
        color: String(template.color || "#3976bb").trim(),
        group: String(template.group || "").trim(),
        fields
      };
    });

    const declaredGroups = Array.isArray(config?.groups)
      ? config.groups.map((name) => String(name || "").trim()).filter(Boolean)
      : [];
    const groups = [...new Set([...declaredGroups, ...templates.map((template) => template.group).filter(Boolean)])];

    return { groups, templates };
  }

  function getPriorityGroups() {
    priorityTemplateConfig = normalizePriorityTemplateConfig(priorityTemplateConfig);
    return priorityTemplateConfig.groups || [];
  }

  function orderPriorityGroups(byGroup) {
    const configured = getPriorityGroups().filter((name) => byGroup.has(name));
    const extra = [...byGroup.keys()]
      .filter((name) => name && !configured.includes(name))
      .sort((left, right) => left.localeCompare(right, "de"));
    return [...configured, ...extra, ...(byGroup.has("") ? [""] : [])];
  }

  function savePriorityTemplateConfig() {
    priorityTemplateConfig = normalizePriorityTemplateConfig(priorityTemplateConfig);
    syncSet("local", { [PRIORITY_TEMPLATE_CONFIG_KEY]: priorityTemplateConfig });
  }

  function normalizeTicketSoundConfig(config) {
    const customSounds = Array.isArray(config?.customSounds)
      ? config.customSounds
          .filter((sound) => sound?.dataUrl)
          .map((sound, index) => ({
            id: String(sound.id || `custom-${index + 1}`),
            name: String(sound.name || `Eigener Sound ${index + 1}`).trim(),
            dataUrl: String(sound.dataUrl)
          }))
      : [];

    const availableIds = [...BUILTIN_TICKET_SOUNDS, ...customSounds].map((sound) => sound.id);
    const selectedId = availableIds.includes(config?.selectedId) ? config.selectedId : BUILTIN_TICKET_SOUNDS[0].id;

    return { customSounds, selectedId };
  }

  function getTicketSoundSource(sound) {
    if (!sound) return "";
    if (sound.dataUrl) return sound.dataUrl;
    if (sound.file) return api.runtime.getURL(sound.file);
    return "";
  }

  function playAssignedTicketSound() {
    const allSounds = [...BUILTIN_TICKET_SOUNDS, ...ticketSoundConfig.customSounds];
    const selected = allSounds.find((sound) => sound.id === ticketSoundConfig.selectedId) || allSounds[0];
    const src = getTicketSoundSource(selected);
    if (!src) return;

    try {
      const audio = new Audio(src);
      audio.volume = 0.6;
      audio.play().catch((error) => console.warn("Znuny Helper: Sound konnte nicht abgespielt werden:", error));
    } catch (error) {
      console.warn("Znuny Helper: Sound konnte nicht abgespielt werden:", error);
    }
  }

  function getLockedTicketsUrl() {
    // Built directly instead of scanning the page for the "Gesperrte Tickets" toolbar
    // link: that link (and its accessible text) isn't present on every Znuny page —
    // e.g. bare action tabs opened by "Popups als Tabs" — which made the periodic
    // check silently do nothing whenever it happened to run in one of those tabs.
    try {
      return new URL("index.pl?Action=AgentTicketLockedView", window.location.href).href;
    } catch (error) {
      return "";
    }
  }

  async function refreshCurrentTicketList() {
    if (!isTicketListPage()) return;

    const table = findTicketTable();
    const tbody = table?.querySelector("tbody");
    if (!table || !tbody) return;

    try {
      const response = await fetch(window.location.href, { credentials: "include", cache: "no-store" });
      if (!response.ok) return;

      const html = await response.text();
      const freshDoc = new DOMParser().parseFromString(html, "text/html");
      const freshTable = findTicketTable(freshDoc);
      const freshBody = freshTable?.querySelector("tbody");
      if (!freshTable || !freshBody) return;

      const freshRows = [...freshBody.querySelectorAll("tr")].map((row) => document.importNode(row, true));

      // Live table and freshly fetched table are resolved independently; they must
      // describe the same list, otherwise the live table would be filled with rows
      // that belong to a different table.
      if (tableColumnSignature(table) !== tableColumnSignature(freshTable)) return;

      tbody.replaceChildren(...freshRows);

      if (settings.ticketCategories && isCategoryTicketListPage()) {
        applyTicketCategories();
      }
    } catch (error) {
      console.warn("Znuny Helper: Ticketliste konnte nicht aktualisiert werden:", error);
    }
  }

  async function runAssignedTicketsCheck(url) {
    try {
      const response = await fetch(url, { credentials: "include", cache: "no-store" });
      if (!response.ok) return;

      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const table = findTicketTable(doc);
      if (!table) return;

      const indexes = getIndexes(table);
      const currentIds = [...table.querySelectorAll("tbody tr")]
        .map((row) => getTicketId(row, indexes))
        .filter(Boolean);

      const stored = await syncGet("local", { [TICKET_SOUND_SEEN_KEY]: null });
      const seen = stored[TICKET_SOUND_SEEN_KEY];

      // Persist the new baseline before playing anything: another tab's poll
      // running right after this one reads the already-updated baseline and
      // correctly sees no new tickets, instead of also sounding off for the
      // same ticket. See the navigator.locks wrapper below for the other half
      // of this (serializing concurrent polls from multiple open Znuny tabs).
      await syncSet("local", { [TICKET_SOUND_SEEN_KEY]: currentIds });

      // First run ever: just record the current baseline, don't sound off for
      // every ticket already locked before this feature existed.
      if (!Array.isArray(seen)) return;

      const seenIds = new Set(seen);
      if (currentIds.some((id) => !seenIds.has(id))) {
        playAssignedTicketSound();
        refreshCurrentTicketList();
      }
    } catch (error) {
      console.warn("Znuny Helper: Ticket-Sound-Prüfung fehlgeschlagen:", error);
    }
  }

  async function checkForAssignedTickets() {
    if (!settings.assignedTicketSound) return;

    const url = getLockedTicketsUrl();
    if (!url) return;

    if (navigator.locks?.request) {
      try {
        await navigator.locks.request("znuny-helper-ticket-sound-check", () => runAssignedTicketsCheck(url));
        return;
      } catch (error) {
        // Fall through to an unlocked check if the Locks API itself rejects.
      }
    }

    await runAssignedTicketsCheck(url);
  }

  function syncGet(area, defaults) {
    const storageArea = api.storage[area];

    if (usesPromiseStorage) {
      return storageArea.get(defaults).then((value) => value || defaults);
    }

    return new Promise((resolve) => storageArea.get(defaults, (value) => resolve(value || defaults)));
  }

  function syncSet(area, value) {
    if (usesPromiseStorage) {
      return api.storage[area]
        .set(value)
        .catch((error) => console.warn("Znuny Helper storage write failed:", error));
    }

    return new Promise((resolve) => api.storage[area].set(value, resolve));
  }

  function dispatchPageSettings() {
    document.documentElement.dataset.zhPopupTabs = settings.popupTabs ? "1" : "0";
    document.documentElement.dataset.zhSearchResultsPopup = settings.searchResultsPopup ? "1" : "0";
    document.documentElement.dataset.zhQuickReply = settings.quickReply ? "1" : "0";

    window.dispatchEvent(new CustomEvent("znuny-helper-settings", {
      detail: {
        popupTabs: settings.popupTabs,
        searchResultsPopup: settings.searchResultsPopup,
        quickReply: settings.quickReply
      }
    }));
  }

  function normalizeText(text) {
    return (text || "")
      .replace(/\u00a0/g, " ")
      .replace(/\r/g, "")
      .split("\n")
      .map((line) => line.replace(/\s+/g, " ").trim())
      .filter(Boolean)
      .join("\n");
  }

  function stopEvent(event) {
    event.preventDefault();
    event.stopPropagation();
  }

  function addStyleToDocument(doc, id, css) {
    if (doc.getElementById(id)) return;

    const style = doc.createElement("style");
    style.id = id;
    style.textContent = css;
    doc.documentElement.appendChild(style);
  }

  function addStyle(id, css) {
    addStyleToDocument(document, id, css);
  }

  function removeStyle(id) {
    getAccessibleSearchDocuments().forEach((doc) => {
      doc.getElementById(id)?.remove();
    });
  }

  function isTicketZoomPage() {
    return window.location.href.includes("Action=AgentTicketZoom");
  }

  // The customer portal (customer.pl) is a separate interface with its own actions. The
  // addon only enhances the local ticket categories there - everything else (agent action
  // URLs, priority templates, quick reply, ...) belongs to the agent interface.
  function isCustomerPortal() {
    return /\/customer\.pl(?:$|[?;])/i.test(window.location.href);
  }

  // MyTickets / CompanyTickets overviews and the customer search results.
  const CUSTOMER_TICKET_LIST_ACTION_PATTERN = /Action=CustomerTicket(?:Overview|Search)\b/i;

  function isCustomerTicketListPage() {
    const href = decodeUrlSeparators(window.location.href);
    if (CUSTOMER_TICKET_LIST_ACTION_PATTERN.test(href)) return true;

    // customer.pl without an action renders the same overview.
    return isCustomerPortal() && !getActionFromUrl(href);
  }

  function isCategoryTicketListPage() {
    if (/Action=AgentTicket(?:Owner|Locked)View/i.test(window.location.href)) return true;

    // Same feature in the customer portal: local categories, colours and notes for
    // "Meine Tickets" / "Firmentickets".
    return isCustomerTicketListPage();
  }

  function isPriorityTicketPage(href = window.location.href) {
    return /Action=AgentTicketPriority/i.test(href);
  }

  function isOwnerTicketPage(href = window.location.href) {
    return /Action=AgentTicketOwner/i.test(href);
  }

  function isPhoneTicketPage(href = window.location.href) {
    return /Action=AgentTicketPhone/i.test(href);
  }

  function isComposeTicketPage() {
    return /Action=AgentTicketCompose/i.test(window.location.href);
  }

  function isPriorityTemplatePage(href = window.location.href) {
    return isPriorityTicketPage(href) || isOwnerTicketPage(href) || isPhoneTicketPage(href);
  }

  function getFormControlValue(form, name) {
    return form?.querySelector?.(`[name="${name}"]`)?.value || "";
  }

  function isTransmitSubmitControl(control) {
    if (!control) return false;

    const text = normalizeText(control.value || control.textContent || control.title || control.getAttribute?.("aria-label") || "");
    return /bermitteln/i.test(text);
  }

  function requestCloseSubmittedTab(delayMs = 300, returnUrl = "") {
    try {
      const response = api.runtime?.sendMessage?.({
        type: "znuny-helper-close-submitted-tab",
        delayMs,
        returnUrl: returnUrl || document.referrer || ""
      });

      response?.catch?.(() => {});
    } catch (error) {
      // The browser API is unavailable on plain page contexts.
    }
  }

  const AUTO_CLOSE_FLAG_KEY = "zhAutoCloseAfterSubmit";
  const AUTO_CLOSE_FLAG_TTL_MS = 20000;

  // Window-name prefix and URL fragment that page-bridge.js puts on a tab it opens for
  // an action page. Keep both in sync with page-bridge.js.
  const ACTION_TAB_NAME_PREFIX = "zhActionTab-";
  const ACTION_TAB_MARKER = "zhActionTab";
  const ACTION_TAB_STORAGE_KEY = "zhActionTabMarker";

  function logAutoClose(message, detail) {
    console.info(`Znuny Helper: ${message}`, detail);
  }

  // The fragment is only in the URL of the first load; remember it for this tab, so it
  // is still known after the submit navigation (which drops the fragment).
  function markActionTabIfRequested() {
    if (window.location.hash !== `#${ACTION_TAB_MARKER}`) return;

    try {
      sessionStorage.setItem(ACTION_TAB_STORAGE_KEY, "1");
    } catch (error) {
      // Private mode or blocked storage; the window name still marks the tab.
    }
  }

  // Action pages that return to the ticket after submitting. Only these may
  // close their tab after a successful submit; zoom/queue/search must stay open.
  const CLOSE_AFTER_SUBMIT_ACTION = /Action=AgentTicket(?:Compose|Owner|Note|Close|Merge|Phone|Priority|Pending|Responsible|FreeText|Bounce|Forward|Move|LinkObject|Watch|Unwatch|Customer|Email|Process|Appointment)\b/i;

  function isCloseAfterSubmitPage(href = window.location.href) {
    return CLOSE_AFTER_SUBMIT_ACTION.test(String(href || ""));
  }

  function isZnunyActionSubmitContext(form) {
    const formAction = getFormControlValue(form, "Action");
    if (formAction) return /^AgentTicket/i.test(formAction);

    const urlAction = new URLSearchParams(window.location.search).get("Action") || "";
    return /^AgentTicket/i.test(urlAction);
  }

  function isExtensionActionTab() {
    // Two independent markers: the window name (page-bridge sets it, but Znuny's popup
    // code works with window.name as well) and the fragment marker remembered in this
    // tab's session storage.
    if (String(window.name || "").startsWith(ACTION_TAB_NAME_PREFIX)) return true;

    try {
      return sessionStorage.getItem(ACTION_TAB_STORAGE_KEY) === "1";
    } catch (error) {
      return false;
    }
  }

  function wasOpenedInOwnTab() {
    // Only a tab that the extension itself opened for an action page may close itself
    // after submitting. window.opener alone is not enough: it is also set for ordinary
    // target="_blank" links, and the quick-reply drawer does not open a tab at all.
    return isExtensionActionTab();
  }

  // Additional, independent signal: the page that led here inside this very tab. After
  // submitting an action Znuny loads the ticket, so the referrer is the action page. A
  // ticket tab opened from a list has a list page as referrer, never an action page.
  function cameFromActionPage() {
    const referrer = String(document.referrer || "");
    return Boolean(referrer) && isCloseAfterSubmitPage(referrer);
  }

  function armAutoCloseOnSubmit(event) {
    // The quick-reply drawer embeds the action inside the ticket tab; that tab must
    // never close itself.
    if (document.getElementById("zh-quick-reply-drawer")) return;

    if (event.type === "submit") {
      if (!isZnunyActionSubmitContext(event.target)) return;
    } else {
      const control = event.target?.closest?.('button, input[type="submit"], input[type="button"], a, [role="button"]');
      if (!control || !isTransmitSubmitControl(control)) return;
      if (!isZnunyActionSubmitContext(control.closest?.("form") || null)) return;
    }

    if (!wasOpenedInOwnTab()) {
      logAutoClose("Tab bleibt offen: nicht vom Addon als Aktions-Tab geoeffnet", {
        name: window.name || "",
        seite: window.location.href
      });
      return;
    }

    const returnUrl = document.referrer || "";

    try {
      // The referrer of this action page is the ticket/list that opened the tab - the
      // page that should be reloaded after submitting.
      sessionStorage.setItem(AUTO_CLOSE_FLAG_KEY, JSON.stringify({ at: Date.now(), returnUrl }));
    } catch (error) {
      // sessionStorage can be unavailable in rare privacy-mode edge cases; ignore.
    }

    // Hand the tab over to the background as well: it closes the tab once Znuny has
    // left the action page, independent of this page's script and of window.name.
    try {
      api.runtime?.sendMessage?.({
        type: "znuny-helper-arm-auto-close",
        returnUrl,
        actionPattern: CLOSE_AFTER_SUBMIT_ACTION.source,
        actionFlags: CLOSE_AFTER_SUBMIT_ACTION.flags
      })?.catch?.(() => {});
    } catch (error) {
      // The browser API is unavailable on plain page contexts.
    }
  }

  function enableCloseTabAfterSubmit() {
    if (window.top !== window.self) return;
    if (!isCloseAfterSubmitPage()) return;
    if (document.documentElement.dataset.zhCloseAfterSubmitBound === "1") return;

    document.documentElement.dataset.zhCloseAfterSubmitBound = "1";
    // Arm on the click that precedes submission (so the message can still be
    // sent before navigation starts) and on the form submit event, which also
    // covers Enter-key submission.
    document.addEventListener("click", armAutoCloseOnSubmit, true);
    document.addEventListener("submit", armAutoCloseOnSubmit, true);
  }

  function enableActionPopupCancelFallback() {
    if (window.top !== window.self || !settings.popupTabs) return;

    document.querySelectorAll(".CancelClosePopup").forEach((link) => {
      if (link.dataset.zhCancelFallbackBound === "1") return;
      link.dataset.zhCancelFallbackBound = "1";
      link.addEventListener("click", (event) => {
        stopEvent(event);
        window.close();
      });
    });
  }

  // Reads and clears the flag. Supports the older plain-timestamp form as well.
  function readAutoCloseFlag() {
    let raw = null;
    try {
      raw = sessionStorage.getItem(AUTO_CLOSE_FLAG_KEY);
      sessionStorage.removeItem(AUTO_CLOSE_FLAG_KEY);
    } catch (error) {
      return null;
    }

    if (!raw) return null;

    if (raw.startsWith("{")) {
      try {
        const parsed = JSON.parse(raw);
        return { at: Number(parsed?.at) || 0, returnUrl: String(parsed?.returnUrl || "") };
      } catch (error) {
        return null;
      }
    }

    return { at: Number(raw) || 0, returnUrl: "" };
  }

  function consumeAutoCloseFlag() {
    if (window.top !== window.self) return;

    const flag = readAutoCloseFlag();
    if (!flag?.at || Date.now() - flag.at > AUTO_CLOSE_FLAG_TTL_MS) return;

    // Only a tab that the extension opened for an action may close itself. This keeps
    // the ticket tab - and every tab the agent opened by hand - out of it, even if a
    // flag ever ends up in the session storage that tabs share.
    const markedTab = isExtensionActionTab();
    const actionReferrer = cameFromActionPage();

    if (!markedTab && !actionReferrer) {
      logAutoClose("Tab bleibt offen: keine Aktions-Tab-Markierung", {
        seite: window.location.href,
        herkunft: document.referrer || "(keine)"
      });
      return;
    }

    // If we are still on an action page, the submit did not succeed (e.g. a
    // validation error re-rendered the form) - keep the tab open.
    if (isCloseAfterSubmitPage()) {
      logAutoClose("Tab bleibt offen: noch auf der Aktionsseite (Vermutlich Validierungsfehler)");
      return;
    }

    logAutoClose("Aktions-Tab wird nach dem Übermitteln geschlossen", {
      markiert: markedTab,
      herkunft: actionReferrer ? document.referrer : "(ohne)"
    });

    window.setTimeout(() => {
      try {
        // One-shot markers: a tab that stays open for other reasons must not be closed
        // later on because of a stale name or marker.
        window.name = "";
        sessionStorage.removeItem(ACTION_TAB_STORAGE_KEY);
      } catch (error) {
        // Ignore; the tab closes right away.
      }
      requestCloseSubmittedTab(300, flag.returnUrl);
    }, 400);
  }

  // Which document an event came from. Needed because the quick-reply window embeds the
  // action page in a frame that has no content script of its own (content scripts run in
  // the top frame only) - the shortcut therefore has to be handled from here, for the
  // frame's document.
  function getEventDocument(event, fallback = document) {
    const target = event?.target;
    const doc = target?.nodeType === 9 ? target : target?.ownerDocument;
    return doc?.querySelectorAll ? doc : fallback;
  }

  function findSubmitShortcutControl(doc = document) {
    const candidates = [...doc.querySelectorAll('button, input[type="submit"], input[type="button"]')]
      .filter(isVisibleFormControl)
      .filter((control) => !control.closest("#zh-priority-template-toolbar, .zh-priority-modal, .zh-category-modal-backdrop, .zh-note-popup, .zh-pending-date-row"))
      .filter(isTransmitSubmitControl);

    if (!candidates.length) return null;

    // Prefer the form the agent is actually working in: a page can hold several
    // forms, and blindly taking the first "Übermitteln" button could submit the
    // wrong one.
    const activeForm = doc.activeElement?.closest?.("form") || null;
    if (activeForm) {
      const inActiveForm = candidates.find((control) => control.closest("form") === activeForm);
      if (inActiveForm) return inActiveForm;
    }

    return candidates.find((control) => {
      const form = control.closest("form");
      return form ? elementIsVisible(form) : true;
    }) || candidates[0];
  }

  // A rich text editor can live in a nested frame without a submit button of its own.
  // Then the window the agent is working in decides: first the quick-reply drawer (the
  // ticket page itself also has "Übermitteln" buttons in its widgets).
  function findFallbackSubmitControl(eventDocument) {
    if (eventDocument === document) return null;

    const drawerDoc = getQuickReplyDocument(document.getElementById("zh-quick-reply-drawer"));
    if (drawerDoc) {
      const inDrawer = findSubmitShortcutControl(drawerDoc);
      if (inDrawer) return inDrawer;
    }

    return findSubmitShortcutControl(document);
  }

  function handleSubmitShortcutKeydown(event) {
    if (!settings.keyboardShortcuts) return;
    if (!(event.ctrlKey || event.metaKey) || event.key !== "Enter") return;
    if (event.target?.closest?.("#zh-priority-template-toolbar, .zh-priority-modal, .zh-category-modal-backdrop, .zh-note-popup")) return;

    const eventDocument = getEventDocument(event);
    const control = findSubmitShortcutControl(eventDocument) || findFallbackSubmitControl(eventDocument);
    if (!control) return;

    event.preventDefault();
    event.stopPropagation();
    control.click();
  }

  // Documents inside iframes belong to another realm: a property written on them from
  // here is not readable again (Firefox) and can even make the whole binding fail. The
  // "already bound" markers therefore live in this realm.
  const submitShortcutBoundDocuments = new WeakSet();
  const quickReplyShortcutBoundDocuments = new WeakSet();
  const quickReplyChangeBoundDocuments = new WeakSet();

  function bindSubmitShortcutToDocument(doc) {
    if (!doc || submitShortcutBoundDocuments.has(doc)) return;

    try {
      submitShortcutBoundDocuments.add(doc);
      doc.addEventListener("keydown", handleSubmitShortcutKeydown, true);
    } catch (error) {
      // Cross-origin document access can fail; nothing to bind in that case.
    }
  }

  function enableSubmitShortcut() {
    // Content scripts run in the top frame only, so the frame documents (including the
    // quick-reply window) are bound from here. The shared marker set keeps every
    // document bound exactly once.
    if (window.top !== window.self) return;

    bindSubmitShortcutToDocument(document);

    document.querySelectorAll("iframe").forEach((iframe) => {
      try {
        if (iframe.contentDocument) bindSubmitShortcutToDocument(iframe.contentDocument);
      } catch (error) {
        // Cross-origin iframe; the page's own shortcuts still apply there.
      }
    });
  }

  function findArticleWidget(doc = document) {
    const byId = doc.getElementById("WidgetArticle");
    if (byId) return byId;

    return [...doc.querySelectorAll(".WidgetSimple")]
      .find((widget) => /artikel hinzuf|add article/i.test(normalizeText(getElementText(widget.querySelector(".Header") || widget)))) || null;
  }

  function expandArticleWidget(doc = document) {
    const widget = findArticleWidget(doc);
    if (!widget || widget.dataset.zhArticleExpanded === "1") return;

    widget.dataset.zhArticleExpanded = "1";

    // Open it by default on every screen. Done via classes (not a click) so it
    // cannot trigger Znuny's anchor navigation/scroll; the CreateArticle
    // checkbox is set so submitting still creates the article.
    if (widget.classList.contains("Collapsed")) {
      widget.classList.remove("Collapsed");
      widget.classList.add("Expanded");
    }

    const createArticle = widget.querySelector("#CreateArticle");
    if (createArticle && createArticle.type === "checkbox" && !createArticle.checked) {
      createArticle.checked = true;
      createArticle.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }

  const DEFAULT_PENDING_DATE_PRESETS = [3, 7, 14];

  function normalizePendingDatePresets(value) {
    const raw = Array.isArray(value) ? value : String(value ?? "").split(/[,;\s]+/);
    const seen = new Set();
    const presets = [];

    raw.forEach((entry) => {
      const days = Math.trunc(Number(entry));
      if (!Number.isFinite(days) || days <= 0 || days > 3650) return;
      if (seen.has(days)) return;
      seen.add(days);
      presets.push(days);
    });

    return presets.length ? presets.slice(0, 8) : DEFAULT_PENDING_DATE_PRESETS.slice();
  }

  function getPendingDatePresets() {
    return normalizePendingDatePresets(settings.pendingDatePresets);
  }

  // Waiting period that is filled in automatically as soon as a pending state (e.g.
  // "Warten zur Erinnerung" or "Warten auf erfolgreich schließen") asks for a date.
  // Configurable in the popup; falls back to the first quick button.
  function getPendingDateDefaultDays() {
    const days = Math.trunc(Number(settings.pendingDateDefaultDays));

    if (Number.isFinite(days) && days > 0 && days <= 3650) return days;

    return DEFAULT_PENDING_DATE_PRESETS[0];
  }

  function selectNearestDateNumber(select, target) {
    if (!select?.options?.length) return false;

    let best = null;
    let bestDiff = Infinity;

    [...select.options].forEach((option) => {
      const num = optionNumber(option);
      if (!Number.isFinite(num)) return;
      const diff = Math.abs(num - target);
      if (diff < bestDiff) {
        bestDiff = diff;
        best = option;
      }
    });

    if (!best) return false;

    if (select.value !== best.value || !best.selected) {
      select.value = best.value;
      best.selected = true;
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
    }

    return true;
  }

  function findPendingDateGroups(doc = document) {
    const selects = [...doc.querySelectorAll("select")]
      .filter((select) => !select.closest("#zh-search-primary-fields, .zh-priority-modal, #zh-priority-template-toolbar"));

    const byPrefix = new Map();

    selects.forEach((select) => {
      const name = select.name || select.id || "";
      const match = name.match(/^(.*?)(Year|Month|Day|Hour|Minute)$/);
      if (!match) return;

      const prefix = match[1];
      const part = match[2];
      if (!byPrefix.has(prefix)) byPrefix.set(prefix, {});
      byPrefix.get(prefix)[part] = select;
    });

    const groups = [];
    byPrefix.forEach((parts, prefix) => {
      if (parts.Year && parts.Month && parts.Day && parts.Hour && parts.Minute && isVisibleFormControl(parts.Year)) {
        groups.push({ prefix, ...parts });
      }
    });

    return groups;
  }

  function pageHasPendingStateSelected(doc = document) {
    return [...doc.querySelectorAll("select")].some((select) => {
      const signature = `${select.name || ""} ${select.id || ""}`.toLowerCase();
      if (!signature.includes("state")) return false;

      const text = normalizeText(select.selectedOptions?.[0]?.textContent || "").toLowerCase();
      return /warten|pending/.test(text);
    });
  }

  function setPendingDateOffset(group, days) {
    const now = new Date();
    const target = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);

    selectDateNumber(group.Day, target.getDate());
    selectDateNumber(group.Month, target.getMonth() + 1);
    selectDateNumber(group.Year, target.getFullYear());
    selectNearestDateNumber(group.Hour, now.getHours());
    selectNearestDateNumber(group.Minute, now.getMinutes());
  }

  function findPendingDateContainer(group) {
    const anchor = group.Minute;
    const fieldContainer = anchor.closest(".Field, .Row, fieldset, li");
    if (fieldContainer) return fieldContainer;

    const row = anchor.closest("tr");
    if (row) return row.querySelector("td:last-child") || row;

    return anchor.parentElement;
  }

  function pendingDateValueSignature(group) {
    return ["Year", "Month", "Day", "Hour", "Minute"]
      .map((part) => normalizeText(group?.[part]?.value || ""))
      .join("|");
  }

  function ensurePendingDateButtons(group, doc = document) {
    const presets = getPendingDatePresets();
    const defaultDays = getPendingDateDefaultDays();
    const signature = `${presets.join(",")}|${defaultDays}`;
    if (group.Year.dataset.zhPendingButtonsBound === signature) return;

    const container = findPendingDateContainer(group);
    if (!container) return;

    container.querySelector(".zh-pending-date-row")?.remove();
    group.Year.dataset.zhPendingButtonsBound = signature;

    const row = doc.createElement("div");
    row.className = "zh-pending-date-row";

    const label = doc.createElement("span");
    label.className = "zh-pending-date-label";
    label.textContent = "Warten bis:";
    row.appendChild(label);

    presets.forEach((days) => {
      const unit = days === 1 ? "Tag" : "Tage";
      const button = doc.createElement("button");
      button.type = "button";
      button.textContent = days === defaultDays ? `+${days} ${unit} (Standard)` : `+${days} ${unit}`;
      button.addEventListener("click", (event) => {
        stopEvent(event);
        setPendingDateOffset(group, days);
      });
      row.appendChild(button);
    });

    container.appendChild(row);

    // Pre-fill the default only while the date fields still hold what they had when
    // the row first appeared. The default used to be written on every rebuild, which
    // could overwrite a date the agent had already picked.
    const currentSignature = pendingDateValueSignature(group);
    const storedInitialSignature = group.Year.dataset.zhPendingInitialValue;
    const lastAppliedDefault = Number(group.Year.dataset.zhPendingDefaultApplied || 0);

    if (storedInitialSignature === undefined) {
      group.Year.dataset.zhPendingInitialValue = currentSignature;
      group.Year.dataset.zhPendingDefaultApplied = String(defaultDays);
      setPendingDateOffset(group, defaultDays);
      return;
    }

    // The configured waiting period changed in the popup: apply it right away instead of
    // waiting for the next page load. The row is only rebuilt when the setting really
    // changed, so a date the agent picked is not overwritten otherwise.
    if (lastAppliedDefault !== defaultDays) {
      group.Year.dataset.zhPendingDefaultApplied = String(defaultDays);
      setPendingDateOffset(group, defaultDays);
      return;
    }

    if (currentSignature === storedInitialSignature) {
      setPendingDateOffset(group, defaultDays);
    }
  }

  function addPendingDateStyles(doc = document) {
    addStyleToDocument(doc, "zh-pending-date-style", `
      .zh-pending-date-row { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; margin: 6px 0 0; }
      .zh-pending-date-label { color: #777; font-size: 12px; }
      .zh-pending-date-row button { font-size: 11px; padding: 3px 8px; border: 1px solid #bdbdbd; border-radius: 3px; background: #f7f7f7; color: #333; cursor: pointer; }
      .zh-pending-date-row button:hover { background: #fff; border-color: #888; }
    `);
  }

  function enablePendingDateQuickButtons(doc = document) {
    if (doc === document && window.top !== window.self) return;
    if (!pageHasPendingStateSelected(doc)) return;

    const groups = findPendingDateGroups(doc);
    if (!groups.length) return;

    addPendingDateStyles(doc);
    groups.forEach((group) => ensurePendingDateButtons(group, doc));
  }

  function disablePendingDateQuickButtons() {
    document.querySelectorAll(".zh-pending-date-row").forEach((row) => row.remove());
    document.querySelectorAll("select[data-zh-pending-buttons-bound]").forEach((select) => {
      delete select.dataset.zhPendingButtonsBound;
    });
    // Forget the remembered "untouched" state too, so switching the feature back on
    // behaves like the date fields appearing for the first time.
    document.querySelectorAll("select[data-zh-pending-initial-value]").forEach((select) => {
      delete select.dataset.zhPendingInitialValue;
    });
    document.querySelectorAll("select[data-zh-pending-default-applied]").forEach((select) => {
      delete select.dataset.zhPendingDefaultApplied;
    });
    removeStyle("zh-pending-date-style");
  }

  // ------------------------------------------------- article action dropdowns
  // Znuny renders "Antworten" and "Weiterleiten" per article as a Modernize select
  // whose visible part is an empty search field: the agent has to click that field
  // and then pick the only entry ("leere Antwort") before the action starts. When
  // exactly one template exists there is nothing to choose, so it is preselected and
  // the empty field is hidden - one click on the action is enough. With several
  // templates nothing is touched, the normal selection stays available.
  function getSingleTemplateOptionValue(options) {
    const values = [...(options || [])]
      .map((option) => String(option?.value ?? "").trim())
      .filter(Boolean);

    return values.length === 1 ? values[0] : "";
  }

  function findArticleActionForm(control) {
    const form = control?.closest?.("form");
    if (!form) return null;

    const action = getFormControlValue(form, "Action");
    if (!/^AgentTicket(?:Compose|Forward)$/.test(action)) return null;

    return form;
  }

  function getArticleActionSelect(form) {
    return form?.querySelector?.('select[name="ResponseID"], select[name="ForwardTemplateID"]') || null;
  }

  function prepareArticleActionForm(form) {
    const select = getArticleActionSelect(form);
    if (!select) return false;

    const value = getSingleTemplateOptionValue(select.options);
    if (!value) return false;

    const searchInput = (select.id ? form.querySelector(`#${select.id}_Search`) : null) ||
      form.querySelector(".InputField_Search");
    if (!searchInput) return false;

    const container = searchInput.closest(".InputField_Container") || searchInput;

    // Select silently, without input/change events: Znuny reacts to those on these
    // menu widgets and would start the action on its own.
    [...select.options].forEach((option) => {
      option.selected = option.value === value;
    });
    select.value = value;

    container.style.display = "none";
    container.dataset.zhDirectActionHidden = "1";
    form.dataset.zhDirectActionPrepared = "1";

    // The visible action text stays reachable, but it is not a Znuny link and therefore
    // never got the orange hover bar of the action bar - add it here.
    addArticleActionStyles(form.ownerDocument || document);
    markArticleActionLabel(form, searchInput);
    return true;
  }

  function addArticleActionStyles(doc = document) {
    addStyleToDocument(doc, "zh-article-action-style", `
      .zh-direct-action-label { position: relative; cursor: pointer; }
      .zh-direct-action-label::after { content: ""; position: absolute; left: 0; right: 0; bottom: -3px; height: 2px; border-radius: 1px; background: #ff9900; opacity: 0; transition: opacity .12s ease; pointer-events: none; }
      .zh-direct-action-label:hover::after, .zh-direct-action-label:focus-within::after { opacity: 1; }
      @media (prefers-reduced-motion: reduce) { .zh-direct-action-label::after { transition: none; } }
    `);
  }

  function isRenderableArticleActionElement(element) {
    if (!element || element.closest?.('[data-zh-direct-action-hidden="1"]')) return false;

    const rect = element.getBoundingClientRect?.();
    return Boolean(rect && rect.width > 0 && rect.height > 0);
  }

  // The visible "Antworten"/"Weiterleiten" text sits next to the (now hidden) search
  // field. Depending on the Znuny version it is a label for that field, a label that
  // wraps it or a label beside it - all shapes are collected here, then the first
  // visible one is marked. A label carrying the action name is always preferred, so a
  // shared wrapper never marks the wrong entry.
  function markArticleActionLabel(form, searchInput) {
    const container = searchInput.closest(".InputField_Container") || searchInput;
    const candidates = [];

    const collect = (node) => {
      if (!node) return;
      if (node.matches?.("label")) candidates.push(node);
      candidates.push(node.querySelector?.("label"));
    };

    if (searchInput.id) {
      collect(form.querySelector(`label[for="${searchInput.id}"]`));
      collect(document.querySelector(`label[for="${searchInput.id}"]`));
    }
    collect(searchInput.closest("label"));

    let before = container.previousElementSibling;
    for (let hops = 0; before && hops < 3; hops += 1) {
      collect(before);
      before = before.previousElementSibling;
    }

    let after = container.nextElementSibling;
    for (let hops = 0; after && hops < 3; hops += 1) {
      collect(after);
      after = after.nextElementSibling;
    }

    form.querySelectorAll("label").forEach((label) => candidates.push(label));

    const unique = [...new Set(candidates)].filter(isRenderableArticleActionElement);
    const label = unique.find((candidate) =>
      ARTICLE_ACTION_LABEL_PATTERN.test(String(candidate.textContent || "").trim())
    ) || unique[0];

    if (!label) return null;

    label.classList.add("zh-direct-action-label");
    label.dataset.zhDirectActionLabel = "1";
    return label;
  }

  function unmarkArticleActionLabels() {
    document.querySelectorAll('[data-zh-direct-action-label="1"]').forEach((element) => {
      element.classList.remove("zh-direct-action-label");
      delete element.dataset.zhDirectActionLabel;
    });
  }

  function buildArticleActionUrl(form) {
    const select = getArticleActionSelect(form);
    if (!select) return "";

    const params = [];

    form.querySelectorAll("input[name]").forEach((input) => {
      // Znuny's own menu links never carry the session token; keep it out of the URL.
      if (input.name === "ChallengeToken") return;

      const value = String(input.value || "").trim();
      if (!value) return;

      params.push(`${input.name}=${value}`);
    });

    const selectValue = String(select.value || "").trim();
    if (selectValue) params.push(`${select.name}=${selectValue}`);

    if (!params.length) return "";

    return `${window.location.pathname}?${params.join(";")}`;
  }

  function handleArticleActionClick(event) {
    const label = event.target?.closest?.("label, .InputField_Container, .InputField_Search");
    const form = label ? findArticleActionForm(label) : null;

    if (!form || form.dataset.zhDirectActionPrepared !== "1") return;
    if (form.dataset.zhDirectActionRunning === "1") return;

    const url = buildArticleActionUrl(form);
    if (!url) return;

    event.preventDefault();
    event.stopPropagation();

    form.dataset.zhDirectActionRunning = "1";
    window.setTimeout(() => {
      delete form.dataset.zhDirectActionRunning;
    }, 1000);

    // The MAIN world bridge runs the action through Znuny's own popup layer - so quick
    // reply, "Popups als Tabs" and real popups keep working. The URL travels as a plain
    // string and additionally as a DOM attribute: Firefox content scripts live in their
    // own realm, and an object in `detail` does not arrive readable on the page side.
    document.documentElement.dataset.zhArticleActionUrl = url;
    window.dispatchEvent(new CustomEvent("znuny-helper-run-article-action", { detail: url }));
  }

  function enableDirectArticleActions() {
    if (window.top !== window.self) return;
    if (!isTicketZoomPage()) return;

    document.querySelectorAll("form").forEach((form) => {
      if (form.dataset.zhDirectActionPrepared === "1") return;
      prepareArticleActionForm(form);
    });

    if (document.documentElement.dataset.zhDirectActionBound !== "1") {
      document.documentElement.dataset.zhDirectActionBound = "1";
      document.addEventListener("click", handleArticleActionClick, true);
    }
  }

  function disableDirectArticleActions() {
    unmarkArticleActionLabels();

    document.querySelectorAll('[data-zh-direct-action-prepared="1"]').forEach((form) => {
      delete form.dataset.zhDirectActionPrepared;

      form.querySelectorAll('[data-zh-direct-action-hidden="1"]').forEach((container) => {
        container.style.display = "";
        delete container.dataset.zhDirectActionHidden;
      });
    });
  }

  function queueScan() {
    if (Date.now() < suppressMutationScanUntil) return;
    if (scanQueued) return;

    scanQueued = true;
    window.setTimeout(() => {
      scanQueued = false;
      runEnabledFeatures();
    }, 150);
  }

  function handleDocumentMutation() {
    const form = settings.ticketNumberSearch && !isCustomerPortal() ? findVisibleSearchForm() : null;

    if (form?.dataset.zhSearchEnhanced === "1") {
      window.setTimeout(() => cleanupEnhancedSearchForm(form), 0);
    } else if (form && !searchModalFixQueued) {
      searchModalFixQueued = true;
      window.setTimeout(() => {
        searchModalFixQueued = false;
        fixTicketNumberSearch();
      }, 0);
    }

    queueScan();
  }

  function closeAttachmentPreview() {
    document.querySelectorAll(".zh-preview-backdrop").forEach((element) => element.remove());

    if (previewObjectUrl) {
      try {
        URL.revokeObjectURL(previewObjectUrl);
      } catch (error) {
        // Nothing to do; the URL is dropped either way.
      }
      previewObjectUrl = "";
    }
  }

  function getExtension(text) {
    const clean = decodeURIComponent(String(text).split("?")[0].split("#")[0]).toLowerCase();
    const match = clean.match(/\.([a-z0-9]+)$/);
    return match ? match[1] : "";
  }

  function getFileName(anchor, index) {
    const text = anchor.innerText.trim();
    if (text) return text.split("\n")[0].trim();

    const title = anchor.getAttribute("title");
    if (title) return title.trim();

    return `Anhang-${index + 1}`;
  }

  function looksLikeAttachmentLink(anchor) {
    const href = (anchor.getAttribute("href") || "").toLowerCase();

    return (
      href.includes("action=agentticketattachment") ||
      href.includes("subaction=download") ||
      href.includes("subaction=attachment") ||
      href.includes("downloadattachment") ||
      href.includes("attachmentid=")
    );
  }

  function isUsableAttachmentHref(href) {
    const clean = String(href || "").trim();
    if (!clean) return false;

    return !/^(#|javascript:)/i.test(clean);
  }

  function attachmentUrlScore(href, isOriginalLink) {
    const clean = String(href || "").toLowerCase();
    let score = 0;

    if (clean.includes("action=agentticketattachment")) score += 30;
    if (clean.includes("subaction=download")) score += 20;
    if (clean.includes("subaction=attachment")) score += 15;
    if (clean.includes("downloadattachment")) score += 15;
    if (clean.includes("attachmentid=")) score += 10;
    if (!isOriginalLink) score += 1;

    return score;
  }

  function getAttachmentPreviewHrefs(anchor, fileName) {
    const expectedName = normalizeText(fileName).toLowerCase();
    return [anchor, ...document.querySelectorAll("a[href]")]
      .filter(Boolean)
      .filter((candidate, index, list) => list.indexOf(candidate) === index)
      .filter((candidate) => {
        const href = candidate.href || candidate.getAttribute("href") || "";
        if (!isUsableAttachmentHref(href)) return false;

        if (candidate === anchor) return true;
        if (!expectedName) return false;

        const candidateName = normalizeText(getFileName(candidate, 0)).toLowerCase();
        const candidateText = normalizeText(candidate.innerText || candidate.textContent || "").toLowerCase();

        return candidateName === expectedName || candidateText.includes(expectedName);
      })
      .map((candidate) => ({
        href: candidate.href || candidate.getAttribute("href") || "",
        isOriginalLink: candidate === anchor
      }))
      .sort((left, right) =>
        attachmentUrlScore(right.href, right.isOriginalLink) - attachmentUrlScore(left.href, left.isOriginalLink)
      )
      .map((candidate) => candidate.href);
  }

  function getAttachmentPreviewHref(anchor, fileName) {
    return getAttachmentPreviewHrefs(anchor, fileName)[0] || "";
  }

  function renderAttachmentDownloadFallback(content, href, message) {
    // Replaces the "loading" placeholder instead of appending below it.
    content.textContent = "";

    const fallback = document.createElement("div");
    fallback.className = "zh-preview-loading";
    fallback.textContent = message;

    const link = document.createElement("a");
    link.href = href;
    link.target = "_blank";
    link.rel = "noopener";
    link.textContent = "Anhang herunterladen";

    fallback.append(document.createElement("br"), document.createElement("br"), link);
    content.appendChild(fallback);
  }

  function renderDirectAttachmentPreview(content, href, fileName) {
    const type = guessAttachmentType(fileName || href, "");

    content.textContent = "";

    if (type === "pdf") {
      // Deliberately no inline iframe here: this path is only reached when
      // the normal fetch-based preview (which forces the blob's MIME type
      // to application/pdf before rendering it) failed or the server itself
      // reported HTML instead of a PDF, so the content can't be confirmed
      // safe to render inline. A same-origin iframe pointed straight at the
      // URL would otherwise let a mislabeled HTML/JS attachment execute
      // script with access to the Znuny session. Sandboxing isn't a fix
      // here either, since it also disables Chromium's PDF viewer outright.
      renderAttachmentDownloadFallback(content, href, "Vorschau nicht möglich, da der Anhang nicht sicher als PDF bestätigt werden konnte.");
      return true;
    }

    if (type === "image") {
      const image = document.createElement("img");
      image.src = href;
      content.appendChild(image);
      return true;
    }

    return false;
  }

  function guessAttachmentType(fileName, blobType) {
    const ext = getExtension(fileName);
    const mime = String(blobType || "").toLowerCase();

    if (ext === "pdf" || mime.includes("pdf")) return "pdf";
    if (
      ["png", "jpg", "jpeg", "gif", "webp", "bmp", "svg", "avif"].includes(ext) ||
      mime.startsWith("image/")
    ) return "image";
    if (["txt", "log", "text"].includes(ext) || mime.startsWith("text/plain")) return "text";
    if (ext === "eml" || mime.includes("message/rfc822")) return "eml";
    if (ext === "docx" || mime.includes("wordprocessingml")) return "docx";
    if (
      ["xlsx", "xlsm", "xlsb", "xls", "ods"].includes(ext) ||
      mime.includes("spreadsheet") ||
      mime.includes("ms-excel") ||
      mime.includes("opendocument.spreadsheet")
    ) return "spreadsheet";
    if (ext === "doc" || mime.includes("msword")) return "word";

    return "unknown";
  }

  function decodeBytes(bytes, charset = "utf-8") {
    try {
      return new TextDecoder(charset).decode(bytes);
    } catch (error) {
      return new TextDecoder("utf-8").decode(bytes);
    }
  }

  async function decodeAttachmentText(blob) {
    const buffer = await blob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const utf8Text = decodeBytes(bytes, "utf-8");
    const replacementCount = (utf8Text.match(/\uFFFD/g) || []).length;

    if (replacementCount > Math.max(3, utf8Text.length / 200)) {
      return decodeBytes(bytes, "windows-1252");
    }

    return utf8Text;
  }

  function decodeMimeWords(value) {
    return String(value || "").replace(/=\?([^?]+)\?([bq])\?([^?]*)\?=/gi, (match, charset, mode, encoded) => {
      try {
        let bytes;

        if (mode.toLowerCase() === "b") {
          const binary = atob(encoded.replace(/\s/g, ""));
          bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
        } else {
          const qp = encoded
            .replace(/_/g, " ")
            .replace(/=([a-f0-9]{2})/gi, (_, hex) => String.fromCharCode(parseInt(hex, 16)));
          bytes = Uint8Array.from(qp, (char) => char.charCodeAt(0));
        }

        return decodeBytes(bytes, charset);
      } catch (error) {
        return match;
      }
    });
  }

  function parseMailHeaders(rawHeaderText) {
    const headers = {};
    let current = "";

    String(rawHeaderText || "").split(/\r?\n/).forEach((line) => {
      if (/^[\t ]/.test(line) && current) {
        headers[current][headers[current].length - 1] += ` ${line.trim()}`;
        return;
      }

      const match = line.match(/^([^:]+):\s*(.*)$/);
      if (!match) return;

      current = match[1].toLowerCase();
      if (!headers[current]) headers[current] = [];
      headers[current].push(decodeMimeWords(match[2].trim()));
    });

    return headers;
  }

  function splitMailHeaderBody(rawText) {
    const match = String(rawText || "").match(/\r?\n\r?\n/);
    if (!match) return { headerText: rawText || "", bodyText: "" };

    return {
      headerText: rawText.slice(0, match.index),
      bodyText: rawText.slice(match.index + match[0].length)
    };
  }

  function getMailHeader(headers, name) {
    return (headers[String(name).toLowerCase()] || []).join(", ");
  }

  function getMimeBoundary(contentType) {
    const match = String(contentType || "").match(/boundary=(?:"([^"]+)"|([^;\s]+))/i);
    return match ? (match[1] || match[2] || "") : "";
  }

  function decodeQuotedPrintable(value) {
    const cleaned = String(value || "").replace(/=\r?\n/g, "");
    const bytes = [];

    for (let index = 0; index < cleaned.length; index += 1) {
      if (cleaned[index] === "=" && /^[a-f0-9]{2}$/i.test(cleaned.slice(index + 1, index + 3))) {
        bytes.push(parseInt(cleaned.slice(index + 1, index + 3), 16));
        index += 2;
      } else {
        bytes.push(cleaned.charCodeAt(index) & 0xff);
      }
    }

    return decodeBytes(new Uint8Array(bytes), "utf-8");
  }

  function decodeBase64Body(value) {
    try {
      const binary = atob(String(value || "").replace(/\s/g, ""));
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      return decodeBytes(bytes, "utf-8");
    } catch (error) {
      return value || "";
    }
  }

  function stripHtmlToText(html) {
    const doc = new DOMParser().parseFromString(String(html || ""), "text/html");
    return normalizeText(doc.body?.innerText || doc.body?.textContent || "");
  }

  function decodeMailBody(bodyText, headers) {
    const transfer = getMailHeader(headers, "content-transfer-encoding").toLowerCase();
    const contentType = getMailHeader(headers, "content-type").toLowerCase();
    let decoded = String(bodyText || "");

    if (transfer.includes("quoted-printable")) decoded = decodeQuotedPrintable(decoded);
    else if (transfer.includes("base64")) decoded = decodeBase64Body(decoded);

    if (contentType.includes("text/html")) decoded = stripHtmlToText(decoded);
    return decoded.trim();
  }

  function extractEmlBody(headerText, bodyText) {
    const headers = parseMailHeaders(headerText);
    const boundary = getMimeBoundary(getMailHeader(headers, "content-type"));

    if (!boundary) return decodeMailBody(bodyText, headers);

    const parts = String(bodyText || "")
      .split(`--${boundary}`)
      .map((part) => part.replace(/--\s*$/, "").trim())
      .filter(Boolean)
      .map((part) => {
        const split = splitMailHeaderBody(part);
        const partHeaders = parseMailHeaders(split.headerText);
        const contentType = getMailHeader(partHeaders, "content-type").toLowerCase();

        return {
          contentType,
          text: decodeMailBody(split.bodyText, partHeaders)
        };
      });

    return (parts.find((part) => part.contentType.includes("text/plain")) ||
      parts.find((part) => part.contentType.includes("text/html")) ||
      parts.find((part) => part.text))?.text || "";
  }

  function renderTextPreview(content, text, fileName, truncated = false) {
    content.textContent = "";

    const wrap = document.createElement("div");
    wrap.className = "zh-preview-text";

    if (truncated) {
      const notice = document.createElement("div");
      notice.className = "zh-preview-notice";
      notice.textContent = "Vorschau gekürzt, da die Datei sehr groß ist.";
      wrap.appendChild(notice);
    }

    const pre = document.createElement("pre");
    pre.textContent = text || `Keine lesbaren Textinhalte in ${fileName || "dieser Datei"} gefunden.`;
    wrap.appendChild(pre);

    content.appendChild(wrap);
  }

  function renderEmlPreview(content, rawText, truncated = false) {
    content.textContent = "";

    const split = splitMailHeaderBody(rawText);
    const headers = parseMailHeaders(split.headerText);
    const body = extractEmlBody(split.headerText, split.bodyText);

    const wrap = document.createElement("div");
    wrap.className = "zh-preview-mail";

    if (truncated) {
      const notice = document.createElement("div");
      notice.className = "zh-preview-notice";
      notice.textContent = "Vorschau gekürzt, da die E-Mail sehr groß ist.";
      wrap.appendChild(notice);
    }

    const meta = document.createElement("dl");
    [
      ["Von", getMailHeader(headers, "from")],
      ["An", getMailHeader(headers, "to")],
      ["Cc", getMailHeader(headers, "cc")],
      ["Datum", getMailHeader(headers, "date")],
      ["Betreff", getMailHeader(headers, "subject")]
    ].forEach(([label, value]) => {
      if (!value) return;

      const dt = document.createElement("dt");
      dt.textContent = label;
      const dd = document.createElement("dd");
      dd.textContent = value;
      meta.append(dt, dd);
    });

    const pre = document.createElement("pre");
    pre.textContent = body || rawText || "Keine lesbaren E-Mail-Inhalte gefunden.";

    wrap.append(meta, pre);
    content.appendChild(wrap);
  }

  function renderDocxMessages(container, messages) {
    if (!Array.isArray(messages) || messages.length === 0) return;

    const details = document.createElement("details");
    details.className = "zh-preview-docx-messages";

    const summary = document.createElement("summary");
    summary.textContent = `${messages.length} Hinweis(e) zur DOCX-Konvertierung`;
    details.appendChild(summary);

    const list = document.createElement("ul");
    messages.forEach((message) => {
      const item = document.createElement("li");
      item.textContent = message.message || String(message);
      list.appendChild(item);
    });
    details.appendChild(list);
    container.appendChild(details);
  }

  // Read a Blob into a Uint8Array that belongs to this content-script realm.
  // In Firefox, blob.arrayBuffer() can hand back a page-realm ArrayBuffer;
  // constructing a typed array from it (or handing it to a library) then throws
  // "Permission denied to access property 'constructor'". A content-script
  // FileReader produces a same-realm buffer, with a forced copy as fallback.
  function readBlobAsUint8Array(blob) {
    return new Promise((resolve, reject) => {
      const fallback = () => {
        if (typeof blob?.arrayBuffer !== "function") {
          reject(new Error("Datei konnte nicht gelesen werden"));
          return;
        }
        Promise.resolve()
          .then(() => blob.arrayBuffer())
          .then((buffer) => {
            const raw = new Uint8Array(buffer);
            const copy = new Uint8Array(raw.length);
            copy.set(raw);
            resolve(copy);
          })
          .catch(reject);
      };

      if (typeof FileReader === "undefined") {
        fallback();
        return;
      }

      let reader;
      try {
        reader = new FileReader();
      } catch (error) {
        fallback();
        return;
      }

      reader.onload = () => {
        const result = reader.result;
        if (result instanceof ArrayBuffer) resolve(new Uint8Array(result));
        else fallback();
      };
      reader.onerror = fallback;

      try {
        reader.readAsArrayBuffer(blob);
      } catch (error) {
        fallback();
      }
    });
  }

  async function renderDocxPreview(content, blob) {
    content.textContent = "";

    const mammothApi = globalThis.mammoth;
    if (!mammothApi?.convertToHtml) {
      throw new Error("Mammoth ist nicht geladen");
    }

    // Mammoth hands the data to JSZip, whose internal `instanceof` checks fail
    // for objects that belong to another realm. If our same-realm bytes are not
    // accepted, fall back to the Blob itself, which JSZip detects via
    // Object.prototype.toString and reads with a content-script FileReader.
    let result;
    try {
      const bytes = await readBlobAsUint8Array(blob);
      result = await mammothApi.convertToHtml({ arrayBuffer: bytes.buffer });
    } catch (error) {
      if (!/Can't read the data of/i.test(String(error?.message || ""))) throw error;
      result = await mammothApi.convertToHtml({ arrayBuffer: blob });
    }

    const wrap = document.createElement("div");
    wrap.className = "zh-preview-docx";

    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "");
    iframe.srcdoc = `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
  body { margin: 0; padding: 18px 22px; font: 14px/1.5 Arial, sans-serif; color: #111; background: #fff; }
  img { max-width: 100%; height: auto; }
  table { border-collapse: collapse; max-width: 100%; }
  td, th { border: 1px solid #ccc; padding: 4px 6px; vertical-align: top; }
  a { color: #064f9e; }
</style>
</head>
<body>${result.value || "<p>Keine lesbaren DOCX-Inhalte gefunden.</p>"}</body>
</html>`;
    iframe.title = "DOCX-Vorschau";
    wrap.appendChild(iframe);

    renderDocxMessages(wrap, result.messages);
    content.appendChild(wrap);
  }

  function spreadsheetColumnName(index) {
    let value = index + 1;
    let name = "";

    while (value > 0) {
      value -= 1;
      name = String.fromCharCode(65 + (value % 26)) + name;
      value = Math.floor(value / 26);
    }

    return name;
  }

  function buildSpreadsheetTableHtml(sheetApi, sheet) {
    const range = sheet?.["!ref"] ? sheetApi.utils.decode_range(sheet["!ref"]) : null;
    if (!range) {
      return {
        html: "",
        notice: ""
      };
    }

    const rowCount = range.e.r - range.s.r + 1;
    const colCount = range.e.c - range.s.c + 1;
    if (rowCount <= 0 || colCount <= 0) {
      return {
        html: "",
        notice: ""
      };
    }

    const visibleRowCount = Math.min(rowCount, SPREADSHEET_PREVIEW_MAX_ROWS);
    const maxCols = Math.min(colCount, SPREADSHEET_PREVIEW_MAX_COLS);
    const truncatedRows = rowCount > SPREADSHEET_PREVIEW_MAX_ROWS;
    const truncatedCols = colCount > SPREADSHEET_PREVIEW_MAX_COLS;

    if (!maxCols) {
      return {
        html: "",
        notice: truncatedRows || truncatedCols ? "Die Vorschau wurde gekürzt." : ""
      };
    }

    const headerCells = Array.from({ length: maxCols }, (_, index) =>
      `<th scope="col">${spreadsheetColumnName(range.s.c + index)}</th>`
    ).join("");

    const bodyRows = Array.from({ length: visibleRowCount }, (_, rowOffset) => {
      const rowIndex = range.s.r + rowOffset;
      const cells = Array.from({ length: maxCols }, (_, colOffset) => {
        const address = sheetApi.utils.encode_cell({ r: rowIndex, c: range.s.c + colOffset });
        const cell = sheet[address];
        const value = cell?.w ?? cell?.v ?? "";
        return `<td>${escapeHtml(value)}</td>`;
      }).join("");

      return `<tr><th scope="row">${rowIndex + 1}</th>${cells}</tr>`;
    }).join("");

    const noticeParts = [];
    if (truncatedRows) noticeParts.push(`maximal ${SPREADSHEET_PREVIEW_MAX_ROWS} Zeilen`);
    if (truncatedCols) noticeParts.push(`maximal ${SPREADSHEET_PREVIEW_MAX_COLS} Spalten`);

    return {
      html: `<table class="zh-spreadsheet-table"><thead><tr><th></th>${headerCells}</tr></thead><tbody>${bodyRows}</tbody></table>`,
      notice: noticeParts.length ? `Die Vorschau zeigt ${noticeParts.join(" und ")}.` : ""
    };
  }

  function buildSpreadsheetHtml(tableHtml, sheetName, notice) {
    return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
  body { margin: 0; padding: 14px; font: 13px/1.35 Arial, sans-serif; color: #111; background: #fff; }
  h1 { margin: 0 0 10px; font-size: 16px; }
  table { border-collapse: collapse; max-width: none; }
  td, th { border: 1px solid #c7c7c7; padding: 4px 7px; vertical-align: top; white-space: pre-wrap; }
  thead th { position: sticky; top: 0; background: #f0f0f0; z-index: 2; }
  tbody th { position: sticky; left: 0; background: #f0f0f0; z-index: 1; text-align: right; color: #555; }
  tr:nth-child(even) td { background: #fafafa; }
  .zh-spreadsheet-notice { margin: 0 0 10px; padding: 7px 9px; border: 1px solid #e3b34d; background: #fff4cf; color: #4b3a00; font-size: 12px; }
</style>
</head>
<body>
<h1>${escapeHtml(sheetName)}</h1>
${notice ? `<p class="zh-spreadsheet-notice">${escapeHtml(notice)}</p>` : ""}
${tableHtml || "<p>Keine lesbaren Tabelleninhalte gefunden.</p>"}
</body>
</html>`;
  }

  async function renderSpreadsheetPreview(content, blob) {
    content.textContent = "";

    const sheetApi = globalThis.XLSX;
    if (!sheetApi?.read || !sheetApi.utils?.decode_range || !sheetApi.utils?.encode_cell) {
      throw new Error("SheetJS ist nicht geladen");
    }

    // Read the bytes as a same-realm Uint8Array with an explicit type. In
    // Firefox the ArrayBuffer from blob.arrayBuffer() can come from the page
    // realm, which breaks SheetJS (and can throw "Permission denied to access
    // property 'constructor'").
    const bytes = await readBlobAsUint8Array(blob);
    const workbook = sheetApi.read(bytes, {
      type: "array",
      cellDates: true,
      cellNF: false,
      cellStyles: false
    });

    const sheetNames = workbook.SheetNames || [];
    if (sheetNames.length === 0) throw new Error("Keine Tabellenblaetter gefunden");

    const wrap = document.createElement("div");
    wrap.className = "zh-preview-spreadsheet";

    const tabs = document.createElement("div");
    tabs.className = "zh-preview-spreadsheet-tabs";

    const iframe = document.createElement("iframe");
    iframe.setAttribute("sandbox", "");
    iframe.title = "XLSX-Vorschau";

    const showSheet = (sheetName, button) => {
      [...tabs.querySelectorAll("button")].forEach((item) => item.classList.toggle("is-active", item === button));
      const table = buildSpreadsheetTableHtml(sheetApi, workbook.Sheets[sheetName]);
      iframe.srcdoc = buildSpreadsheetHtml(table.html, sheetName, table.notice);
    };

    sheetNames.forEach((sheetName, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = sheetName || `Tabelle ${index + 1}`;
      button.addEventListener("click", () => showSheet(sheetName, button));
      tabs.appendChild(button);
    });

    wrap.append(tabs, iframe);
    content.appendChild(wrap);

    showSheet(sheetNames[0], tabs.querySelector("button"));
  }

  function findAttachmentContainer(anchor) {
    let element = anchor.parentElement;

    for (let index = 0; index < 6 && element; index += 1) {
      const text = element.innerText || "";
      const hasSize = /\b\d+[,.]?\d*\s*(KB|MB|GB)\b/i.test(text);

      if (hasSize && text.length < 500) {
        return element;
      }

      element = element.parentElement;
    }

    return anchor.parentElement;
  }

  async function openAttachmentPreview(anchor, fileName) {
    closeAttachmentPreview();
    const previewHrefs = getAttachmentPreviewHrefs(anchor, fileName);
    const previewHref = previewHrefs[0] || "";

    const backdrop = document.createElement("div");
    backdrop.className = "zh-preview-backdrop";

    const modal = document.createElement("div");
    modal.className = "zh-preview-modal";

    const header = document.createElement("div");
    header.className = "zh-preview-header";

    const title = document.createElement("div");
    title.className = "zh-preview-title";
    title.textContent = fileName;

    const actions = document.createElement("div");
    actions.className = "zh-preview-actions";

    const openTab = document.createElement("a");
    openTab.href = previewHref || anchor.href;
    openTab.target = "_blank";
    openTab.rel = "noopener";
    openTab.textContent = "Tab";

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.textContent = "Schließen";

    actions.append(openTab, closeButton);
    header.append(title, actions);

    const content = document.createElement("div");
    content.className = "zh-preview-content";
    content.innerHTML = '<div class="zh-preview-loading">Lade Vorschau...</div>';

    modal.append(header, content);
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    closeButton.addEventListener("click", (event) => {
      stopEvent(event);
      closeAttachmentPreview();
    });

    backdrop.addEventListener("click", (event) => {
      if (event.target === backdrop) closeAttachmentPreview();
    });

    const escHandler = (event) => {
      if (event.key === "Escape") {
        closeAttachmentPreview();
        document.removeEventListener("keydown", escHandler);
      }
    };
    document.addEventListener("keydown", escHandler);

    try {
      if (previewHrefs.length === 0) throw new Error("Keine Anhang-URL gefunden");

      let response = null;
      let loadedHref = "";

      for (const href of previewHrefs) {
        try {
          response = await fetch(href, {
            credentials: "include",
            cache: "no-store"
          });

          if (response.ok) {
            loadedHref = href;
            break;
          }
        } catch (error) {
          response = null;
        }
      }

      if (!response?.ok) {
        if (renderDirectAttachmentPreview(content, previewHref, fileName)) return;
        throw new Error("Anhang konnte nicht geladen werden");
      }

      const blob = await response.blob();
      const type = guessAttachmentType(fileName, blob.type);

      content.textContent = "";

      if (type === "pdf" && blob.type.includes("html") && renderDirectAttachmentPreview(content, loadedHref || previewHref, fileName)) {
        return;
      }

      const previewBlob = type === "pdf" && !blob.type.toLowerCase().includes("pdf")
        ? new Blob([blob], { type: "application/pdf" })
        : blob;
      const blobUrl = URL.createObjectURL(previewBlob);
      previewObjectUrl = blobUrl;

      if (type === "pdf") {
        const iframe = document.createElement("iframe");
        // No "sandbox" here: Chromium's built-in PDF viewer refuses to
        // activate inside a sandboxed iframe at all (a known Chromium
        // limitation, independent of which tokens are granted), so sandboxing
        // this frame breaks PDF rendering outright rather than adding
        // protection. The viewer itself already runs isolated at the browser
        // process level.
        iframe.src = blobUrl;
        content.appendChild(iframe);
      } else if (type === "image") {
        const image = document.createElement("img");
        image.src = blobUrl;
        content.appendChild(image);
      } else if (type === "text") {
        const textBlob = blob.size > TEXT_PREVIEW_LIMIT ? blob.slice(0, TEXT_PREVIEW_LIMIT) : blob;
        const text = await decodeAttachmentText(textBlob);
        renderTextPreview(content, text, fileName, blob.size > TEXT_PREVIEW_LIMIT);
      } else if (type === "eml") {
        const textBlob = blob.size > TEXT_PREVIEW_LIMIT ? blob.slice(0, TEXT_PREVIEW_LIMIT) : blob;
        const text = await decodeAttachmentText(textBlob);
        renderEmlPreview(content, text, blob.size > TEXT_PREVIEW_LIMIT);
      } else if (type === "docx") {
        await renderDocxPreview(content, blob);
      } else if (type === "spreadsheet") {
        await renderSpreadsheetPreview(content, blob);
      } else {
        const fallback = document.createElement("div");
        fallback.className = "zh-preview-loading";
        fallback.textContent = type === "word"
          ? "Alte DOC-Dateien kann Mammoth nicht direkt anzeigen. Bitte die Datei öffnen oder in DOCX umwandeln."
          : "Für diesen Dateityp ist keine direkte Vorschau möglich.";

        const link = document.createElement("a");
        link.href = blobUrl;
        link.target = "_blank";
        link.rel = "noopener";
        link.textContent = "Datei öffnen";

        fallback.append(document.createElement("br"), document.createElement("br"), link);
        content.appendChild(fallback);
      }

      openTab.href = blobUrl;
    } catch (error) {
      content.innerHTML = "";
      const failure = document.createElement("div");
      failure.className = "zh-preview-loading";
      failure.textContent = `Vorschau konnte nicht geladen werden: ${error.message}`;
      content.appendChild(failure);
    }
  }

  function closeArticleImageLightbox() {
    document.querySelectorAll(".zh-image-lightbox-backdrop").forEach((element) => element.remove());
  }

  function openArticleImageLightbox(img) {
    closeArticleImageLightbox();

    const backdrop = document.createElement("div");
    backdrop.className = "zh-image-lightbox-backdrop";

    const large = document.createElement("img");
    large.src = img.currentSrc || img.src;
    large.alt = img.alt || "";

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.className = "zh-image-lightbox-close";
    closeButton.textContent = "Schließen";
    closeButton.addEventListener("click", (event) => {
      stopEvent(event);
      closeArticleImageLightbox();
    });

    backdrop.append(large, closeButton);
    document.body.appendChild(backdrop);

    backdrop.addEventListener("click", (event) => {
      if (event.target === backdrop) closeArticleImageLightbox();
    });

    const escHandler = (event) => {
      if (event.key === "Escape") {
        closeArticleImageLightbox();
        document.removeEventListener("keydown", escHandler);
      }
    };
    document.addEventListener("keydown", escHandler);
  }

  function isEnlargeableArticleImage(img) {
    if (!img) return false;
    if (img.closest(".zh-preview-backdrop, .zh-image-lightbox-backdrop, #zh-ticket-article-search")) return false;
    if (isNonArticleSearchArea(img)) return false;

    const table = img.closest("table");
    if (table && isArticleOverviewTable(table)) return false;

    const width = img.naturalWidth || img.width || 0;
    const height = img.naturalHeight || img.height || 0;
    return width >= 24 && height >= 24;
  }

  function bindArticleImageZoom() {
    const selector = [
      ".ArticleBody img",
      ".ArticleContent img",
      ".ArticleMailContent img",
      ".ArticleMailContentHTML img",
      ".MessageBody img",
      ".RichText img",
      ".Article img"
    ].join(", ");

    [...document.querySelectorAll(selector)].forEach((img) => {
      if (img.dataset.zhZoomBound === "1") return;
      img.dataset.zhZoomBound = "1";

      const markClickable = () => {
        if (isEnlargeableArticleImage(img)) img.classList.add("zh-article-image-zoomable");
      };

      if (img.complete) markClickable();
      else img.addEventListener("load", markClickable, { once: true });

      img.addEventListener("click", (event) => {
        if (!img.classList.contains("zh-article-image-zoomable")) return;
        stopEvent(event);
        openArticleImageLightbox(img);
      });
    });
  }

  function disableArticleImageZoom() {
    closeArticleImageLightbox();
    document.querySelectorAll("[data-zh-zoom-bound]").forEach((img) => {
      delete img.dataset.zhZoomBound;
      img.classList.remove("zh-article-image-zoomable");
    });
  }

  function enableAttachmentPreview() {
    addStyle("zh-attachment-preview-style", `
      .zh-attachment-container { position: relative !important; padding-right: 150px !important; min-height: 52px !important; }
      .zh-attachment-btn { position: absolute; right: 38px; top: 9px; z-index: 50; font-size: 12px; font-weight: 700; padding: 6px 11px; cursor: pointer; border: 1px solid #d98200; border-radius: 999px; background: #ff9900; color: #111; box-shadow: 0 2px 5px rgba(0,0,0,.25); line-height: 1.2; white-space: nowrap; }
      .zh-attachment-btn:hover { background: #ffb13b; border-color: #b86f00; }
      .zh-attachment-btn:active { transform: translateY(1px); }
      .zh-preview-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 999998; display: flex; align-items: center; justify-content: center; }
      .zh-preview-modal { width: 88vw; height: 88vh; background: #f7f7f7; border-radius: 8px; box-shadow: 0 10px 40px rgba(0,0,0,.45); display: flex; flex-direction: column; overflow: hidden; border: 1px solid #999; }
      .zh-preview-header { height: 38px; flex: 0 0 38px; background: #222; color: white; display: flex; align-items: center; justify-content: space-between; padding: 0 10px; font-size: 13px; border-bottom: 3px solid #ff9900; }
      .zh-preview-title { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; max-width: 70vw; font-weight: bold; }
      .zh-preview-actions { display: flex; gap: 6px; align-items: center; }
      .zh-preview-actions button, .zh-preview-actions a { font-size: 11px; padding: 3px 8px; border: 1px solid #999; border-radius: 4px; background: #eee; color: #111; cursor: pointer; text-decoration: none; }
      .zh-preview-actions button:hover, .zh-preview-actions a:hover { background: #fff; }
      .zh-preview-content { flex: 1; min-height: 0; background: #ddd; display: flex; align-items: center; justify-content: center; overflow: auto; }
      .zh-preview-content iframe { width: 100%; height: 100%; border: none; background: white; }
      .zh-preview-content img { max-width: 100%; max-height: 100%; object-fit: contain; background: white; }
      .zh-preview-loading { font-size: 14px; color: #333; padding: 20px; text-align: center; }
      .zh-preview-text, .zh-preview-mail { align-self: stretch; width: 100%; min-height: 100%; box-sizing: border-box; background: #fff; color: #111; overflow: auto; padding: 14px 16px; }
      .zh-preview-text pre, .zh-preview-mail pre { margin: 0; white-space: pre-wrap; overflow-wrap: anywhere; font: 13px/1.45 Consolas, "Courier New", monospace; }
      .zh-preview-mail dl { display: grid; grid-template-columns: max-content 1fr; gap: 5px 12px; margin: 0 0 14px; padding: 0 0 12px; border-bottom: 1px solid #ddd; }
      .zh-preview-mail dt { font-weight: 700; color: #555; }
      .zh-preview-mail dd { margin: 0; min-width: 0; overflow-wrap: anywhere; }
      .zh-preview-notice { margin: 0 0 10px; padding: 7px 9px; border: 1px solid #e3b34d; background: #fff4cf; color: #4b3a00; font-size: 12px; }
      .zh-preview-docx { align-self: stretch; width: 100%; min-height: 100%; display: flex; flex-direction: column; background: #fff; }
      .zh-preview-docx iframe { flex: 1; min-height: 0; width: 100%; border: 0; background: #fff; }
      .zh-preview-docx-messages { flex: 0 0 auto; border-top: 1px solid #ddd; background: #fff8dd; color: #4b3a00; padding: 7px 10px; font-size: 12px; }
      .zh-preview-docx-messages summary { cursor: pointer; font-weight: 700; }
      .zh-preview-docx-messages ul { margin: 6px 0 0 18px; padding: 0; }
      .zh-preview-spreadsheet { align-self: stretch; width: 100%; min-height: 100%; display: flex; flex-direction: column; background: #fff; }
      .zh-preview-spreadsheet-tabs { flex: 0 0 auto; display: flex; gap: 5px; overflow-x: auto; padding: 7px 8px; background: #f1f1f1; border-bottom: 1px solid #cfcfcf; }
      .zh-preview-spreadsheet-tabs button { border: 1px solid #aaa; background: #fff; color: #111; padding: 4px 9px; cursor: pointer; white-space: nowrap; font-size: 12px; }
      .zh-preview-spreadsheet-tabs button.is-active { background: #ff9900; border-color: #b86f00; font-weight: 700; }
      .zh-preview-spreadsheet iframe { flex: 1; min-height: 0; width: 100%; border: 0; background: #fff; }
      .zh-article-image-zoomable { cursor: zoom-in; transition: outline-color .1s ease; }
      .zh-article-image-zoomable:hover { outline: 2px solid #ff9900; outline-offset: 2px; }
      .zh-image-lightbox-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,.7); z-index: 999999; display: flex; align-items: center; justify-content: center; cursor: zoom-out; }
      .zh-image-lightbox-backdrop img { max-width: 92vw; max-height: 92vh; object-fit: contain; box-shadow: 0 10px 40px rgba(0,0,0,.5); border-radius: 4px; cursor: default; }
      .zh-image-lightbox-close { position: absolute; top: 16px; right: 20px; font-size: 13px; font-weight: 700; padding: 6px 12px; border: 1px solid #999; border-radius: 999px; background: #eee; color: #111; cursor: pointer; }
      .zh-image-lightbox-close:hover { background: #fff; }
    `);

    bindArticleImageZoom();

    [...document.querySelectorAll("a[href]")]
      .filter(looksLikeAttachmentLink)
      .forEach((anchor, index) => {
        if (anchor.dataset.zhAttachmentEnhanced === "1") return;

        const container = findAttachmentContainer(anchor);
        if (!container) return;

        anchor.dataset.zhAttachmentEnhanced = "1";
        container.classList.add("zh-attachment-container");

        const button = document.createElement("button");
        button.type = "button";
        button.className = "zh-attachment-btn";
        button.textContent = "Vorschau";
    button.title = "Anhang groß anzeigen";

        ["mousedown", "mouseup", "dblclick"].forEach((type) => {
          button.addEventListener(type, stopEvent, true);
        });

        button.addEventListener("click", (event) => {
          stopEvent(event);
          openAttachmentPreview(anchor, getFileName(anchor, index));
        }, true);

        container.appendChild(button);
      });
  }

  function disableAttachmentPreview() {
    closeAttachmentPreview();
    disableArticleImageZoom();
    removeStyle("zh-attachment-preview-style");

    document.querySelectorAll(".zh-attachment-btn").forEach((element) => element.remove());
    document.querySelectorAll(".zh-attachment-container").forEach((element) => element.classList.remove("zh-attachment-container"));
    document.querySelectorAll("[data-zh-attachment-enhanced]").forEach((element) => delete element.dataset.zhAttachmentEnhanced);
  }

  function fixTicketNumberSearch() {
    const form = findVisibleSearchForm();
    const attr = findSearchAttributeControl(form);
    if (!form) return;

    if (form.dataset.zhSearchEnhanced === "1") {
      cleanupEnhancedSearchForm(form);

      // Znuny rebuilds the dialog through AJAX (for instance when the filter selection
      // changes) and wipes the added rows with it. The marker on the form survives that,
      // so the form would never be rebuilt - check the UI and enhance again if it is gone.
      const primaryBlockPresent = document.getElementById("zh-search-primary-fields");
      const historyBlockPresent = document.getElementById("zh-search-history-block");

      if (primaryBlockPresent && historyBlockPresent) return;

      delete form.dataset.zhSearchEnhanced;
    }

    addSearchModalStyles();
    installPageSearchHistoryBridge();

    if (attr && !attr.__znunyHelperOriginalOptions) {
      attr.__znunyHelperOriginalOptions = [...attr.options].map((option) => ({
        value: option.value,
        text: option.textContent,
        selected: option.selected
      }));
    }

    if (attr?.__znunyHelperOriginalOptions && attr.options.length <= 1) {
      restoreSearchAttributeOptions(attr, false);
    }

    const fulltextControl = ensureFulltextControl(form);
    const ticketNumberControl = ensureTicketNumberControl(form);
    document.getElementById("zh-createdmonths-row")?.remove();
    ensureCreatedDateFilter(form);
    const primaryBlock = getOrCreateSearchPrimaryBlock(form);

    if (fulltextControl) {
      getOrCreateCleanSearchRow(primaryBlock, "zh-fulltext-row", "Volltext:", fulltextControl, "Suchbegriff eingeben");
      attachSearchHistory(fulltextControl, "fulltext");
    }

    if (ticketNumberControl) {
      getOrCreateCleanSearchRow(primaryBlock, "zh-ticketnumber-row", "Ticketnummer:", ticketNumberControl, "z. B. 86121234 oder 86126767");
      attachSearchHistory(ticketNumberControl, "ticketNumber");
      bindTicketNumberFulltextFallback(fulltextControl, ticketNumberControl);
    }

    ensureSearchDateRangeQuickButtons(form, primaryBlock);
    getOrCreateSearchHistoryBlock(form, primaryBlock);

    // Attach the search recording before the cosmetic work below: a failure there must
    // not be able to leave the form without its listeners.
    rememberSearchOnSubmit(form, fulltextControl, ticketNumberControl, null);
    rememberSearchFromSearchPage(form, fulltextControl, ticketNumberControl);

    moveKnownSearchSectionsAfterPrimary(form, primaryBlock);
    hideOldUsedFilterScaffold(form);
    prepareSearchFormNewTab(form);
    form.dataset.zhSearchEnhanced = "1";

    if (fulltextControl && fulltextControl.dataset.zhFocused !== "1") {
      fulltextControl.dataset.zhFocused = "1";
      window.setTimeout(() => {
        fulltextControl.focus();
        if (typeof fulltextControl.select === "function") {
          fulltextControl.select();
        }
      }, 80);
    }
  }

  function restoreTicketNumberSearch() {
    const form = findVisibleSearchForm();
    const attr = findSearchAttributeControl(form);

    document.getElementById("zh-search-history-block")?.remove();
    document.querySelectorAll(".zh-search-history").forEach((element) => element.remove());

    if (!attr?.__znunyHelperOriginalOptions) return;

    restoreSearchAttributeOptions(attr, true);

    removeStyle("zh-search-modal-style");
  }

  function restoreSearchAttributeOptions(attr, dispatchChange) {
    if (!attr?.__znunyHelperOriginalOptions) return;

    attr.innerHTML = "";
    attr.__znunyHelperOriginalOptions.forEach((original) => {
      const option = document.createElement("option");
      option.value = original.value;
      option.textContent = original.text;
      option.selected = original.selected;
      attr.appendChild(option);
    });

    delete attr.__znunyHelperOriginalOptions;
    if (dispatchChange) {
      attr.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }

  function cleanupEnhancedSearchForm(form) {
    hideOldUsedFilterScaffold(form);
  }

  function elementIsVisible(element) {
    if (!element) return false;

    const style = window.getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") return false;

    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function findVisibleSearchForm() {
    const forms = [...document.querySelectorAll("#SearchForm")];
    return forms.find(elementIsVisible) || forms[forms.length - 1] || null;
  }

  function findSearchAttributeControl(form) {
    return form?.querySelector("#Attribute") ||
      [...document.querySelectorAll("#Attribute")].find(elementIsVisible) ||
      document.querySelector("#Attribute");
  }

  function findFormControl(form, names) {
    const helperControl = form.querySelector('[data-zh-ticketnumber-control="1"]');
    if (helperControl && names.includes("TicketNumber")) return helperControl;

    for (const name of names) {
      const control = form.querySelector(`[name="${name}"], #${name}`);
      if (control) return control;
    }

    return null;
  }

  function findSearchFieldRow(control) {
    if (!control) return null;

    return control.closest("tr, li, .Field, .Row, .WidgetSimple, .ContentColumn") ||
      control.parentElement;
  }

  function ensureTicketNumberControl(form) {
    let ticketNumberControl = form.querySelector('[data-zh-ticketnumber-control="1"]');
    if (ticketNumberControl) return ticketNumberControl;

    ticketNumberControl = document.createElement("input");
    ticketNumberControl.id = "zh-ticketnumber-input";
    ticketNumberControl.name = "TicketNumber";
    ticketNumberControl.type = "text";
    ticketNumberControl.autocomplete = "off";
    ticketNumberControl.dataset.zhTicketnumberControl = "1";

    return ticketNumberControl;
  }

  function ensureFulltextControl(form) {
    let fulltextControl = findFormControl(form, ["Fulltext", "FullText", "FulltextSearch"]);
    if (fulltextControl) return fulltextControl;

    fulltextControl = document.createElement("input");
    fulltextControl.id = "zh-fulltext-input";
    fulltextControl.name = "Fulltext";
    fulltextControl.type = "text";
    fulltextControl.autocomplete = "off";
    fulltextControl.dataset.zhFulltextControl = "1";

    return fulltextControl;
  }

  function ensureHiddenInput(form, name, value) {
    let input = form.querySelector(`input[type="hidden"][name="${name}"][data-zh-created-date-filter="1"]`) ||
      form.querySelector(`input[type="hidden"][name="${name}"]`);

    if (!input) {
      input = document.createElement("input");
      input.type = "hidden";
      input.name = name;
      form.appendChild(input);
    }

    input.value = value;
    return input;
  }

  function optionText(option) {
    return normalizeText(`${option?.textContent || ""} ${option?.value || ""}`).toLowerCase();
  }

  function findOption(select, predicates) {
    if (!select?.options) return null;

    return [...select.options].find((option) => {
      const text = optionText(option);
      return predicates.some((predicate) => predicate(text, option));
    }) || null;
  }

  function selectOption(select, predicates) {
    const option = findOption(select, predicates);
    if (!option) return false;

    if (select.value !== option.value || !option.selected) {
      select.value = option.value;
      option.selected = true;
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
    }

    return true;
  }

  function isDefaultTicketTimeAttributeText(text) {
    return (/letzte\s+ticket[-\s]?\u00e4nderungszeit|letzte\s+ticket[-\s]?aenderungszeit|ticket\s*change\s*time|ticketchangetime/i.test(text)) &&
      (/zwischen|between/i.test(text));
  }

  function findDefaultTicketTimeAttributeOption(attr) {
    if (!attr) return null;

    const current = [...attr.options].find((option) => isDefaultTicketTimeAttributeText(optionText(option)));
    if (current) return current;

    const original = (attr.__znunyHelperOriginalOptions || [])
      .find((option) => isDefaultTicketTimeAttributeText(`${option.text || ""} ${option.value || ""}`));

    if (!original) return null;

    const option = document.createElement("option");
    option.value = original.value;
    option.textContent = original.text;
    attr.appendChild(option);
    return option;
  }

  function getGeneratedFilterContainer(control, form) {
    return control?.closest("tr, li, fieldset, .Field, .Row, .WidgetSimple, .ContentColumn") ||
      findGeneratedSearchFieldRow(control, form);
  }

  function findDefaultTicketTimeFilterContainers(form) {
    if (!form) return [];

    const containers = [];
    const addContainer = (container) => {
      if (!container || container === form || container.closest("#zh-search-primary-fields")) return;
      if (container.querySelector("#Attribute")) return;
      if (!container.querySelector("input, select, textarea")) return;
      if (!containers.includes(container)) containers.push(container);
    };

    [...form.querySelectorAll("input, select, textarea")].forEach((control) => {
      if (control.closest("#zh-search-primary-fields")) return;

      const signature = `${control.name || ""} ${control.id || ""}`.toLowerCase();
      if (/ticket.*change.*time|change.*time.*ticket|ticketchange/i.test(signature)) {
        addContainer(getGeneratedFilterContainer(control, form));
      }
    });

    [...form.querySelectorAll("tr, li, fieldset, div")].forEach((element) => {
      if (element.closest("#zh-search-primary-fields")) return;
      if (element.querySelector("#Attribute")) return;

      const text = normalizeText(getElementText(element)).toLowerCase();
      if (isDefaultTicketTimeAttributeText(text)) {
        addContainer(element);
      }
    });

    return containers;
  }

  function getSameDateLastYear(date) {
    const lastYear = new Date(date.getFullYear() - 1, date.getMonth(), date.getDate());
    if (lastYear.getMonth() === date.getMonth()) return lastYear;

    return new Date(date.getFullYear() - 1, date.getMonth() + 1, 0);
  }

  function optionNumber(option) {
    const value = String(option?.value || "").trim();
    const text = normalizeText(option?.textContent || "").trim();
    const raw = value || text;
    const match = raw.match(/\d{1,4}/);
    return match ? Number.parseInt(match[0], 10) : NaN;
  }

  function selectDateNumber(select, number) {
    if (!select?.options) return false;

    const padded = String(number).padStart(2, "0");
    const exact = [...select.options].find((option) => {
      const value = String(option.value || "").trim();
      const text = normalizeText(option.textContent || "").trim();
      return value === String(number) || value === padded || text === String(number) || text === padded;
    });

    const numeric = exact || [...select.options].find((option) => optionNumber(option) === number);
    if (!numeric) return false;

    if (select.value !== numeric.value || !numeric.selected) {
      select.value = numeric.value;
      numeric.selected = true;
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
    }

    return true;
  }

  function fillTicketTimeRangeWithDates(form, start, end) {
    const containers = findDefaultTicketTimeFilterContainers(form);
    if (!containers.length) return false;

    const values = [
      start.getDate(), start.getMonth() + 1, start.getFullYear(),
      end.getDate(), end.getMonth() + 1, end.getFullYear()
    ];

    let filled = false;

    containers.forEach((container) => {
      const selects = getTicketTimeRangeSelects(container);

      if (selects.length < 6) return;

      values.forEach((value, index) => {
        filled = selectDateNumber(selects[index], value) || filled;
      });
    });

    return filled || containers.length > 0;
  }

  function getTicketTimeRangeSelects(container) {
    return [...(container?.querySelectorAll?.("select") || [])]
      .filter((select) => select.id !== "Attribute")
      .filter((select) => !select.closest("#zh-search-primary-fields"))
      .filter((select) => !select.disabled)
      .filter((select) => [...select.options].some((option) => Number.isFinite(optionNumber(option))));
  }

  // The six dropdowns of the "Last ticket change" range - the same ones the Zeitraum
  // buttons fill. The search history remembers their values so a past search can be
  // restored with its period.
  function getSearchDateRangeSelects(form) {
    const containers = findDefaultTicketTimeFilterContainers(form);

    for (const container of containers) {
      const selects = getTicketTimeRangeSelects(container);
      if (selects.length >= 6) return selects.slice(0, 6);
    }

    return [];
  }

  function readSearchDateRangeValues(form) {
    const selects = getSearchDateRangeSelects(form);
    if (selects.length < 6) return null;

    const values = selects.map((select) => {
      const selected = select.options?.[select.selectedIndex] ||
        [...(select.options || [])].find((option) => option.selected);
      return optionNumber(selected);
    });

    return values.every((value) => Number.isFinite(value)) ? values : null;
  }

  function applySearchDateRangeValues(form, values) {
    if (!Array.isArray(values) || values.length < 6) return false;

    const selects = getSearchDateRangeSelects(form);
    if (selects.length < 6) return false;

    let applied = false;
    values.slice(0, 6).forEach((value, index) => {
      applied = selectDateNumber(selects[index], Number(value)) || applied;
    });

    return applied;
  }

  // Only a period the agent actually touched belongs in the history; the default
  // values of those dropdowns would otherwise show up on every entry.
  function bindSearchRangeTouchedTracking(form) {
    if (!form || form.dataset.zhSearchRangeTracked === "1") return;

    const selects = getSearchDateRangeSelects(form);
    if (!selects.length) return;

    form.dataset.zhSearchRangeTracked = "1";
    selects.forEach((select) => {
      select.addEventListener("change", () => {
        form.dataset.zhSearchRangeTouched = "1";
        delete form.dataset.zhSearchRangeLabel;
      });
    });
  }

  function fillDefaultTicketTimeRange(form) {
    const end = new Date();
    const start = getSameDateLastYear(end);
    return fillTicketTimeRangeWithDates(form, start, end);
  }

  function getDateDaysAgo(date, days) {
    const result = new Date(date);
    result.setDate(result.getDate() - days);
    return result;
  }

  function getDateMonthsAgo(date, months) {
    const result = new Date(date);
    result.setMonth(result.getMonth() - months);
    return result;
  }

  const SEARCH_DATE_RANGE_PRESETS = [
    { id: "week", label: "Letzte Woche", getStart: (now) => getDateDaysAgo(now, 7) },
    { id: "month", label: "Letzter Monat", getStart: (now) => getDateMonthsAgo(now, 1) },
    { id: "quarter", label: "Letztes Quartal", getStart: (now) => getDateMonthsAgo(now, 3) }
  ];

  function applySearchDateRangePreset(form, preset) {
    const end = new Date();
    const start = preset.getStart(end);
    fillTicketTimeRangeWithDates(form, start, end);
    cleanupEmptyGeneratedSearchFilterRows(form);
  }

  function ensureSearchDateRangeQuickButtons(form, primaryBlock) {
    let row = document.getElementById("zh-search-daterange-row");
    if (!row) {
      row = document.createElement("div");
      row.id = "zh-search-daterange-row";
      row.className = "zh-search-field-row zh-search-daterange-row";

      const label = document.createElement("span");
      label.className = "zh-search-daterange-label";
      label.textContent = "Zeitraum:";
      row.appendChild(label);

      const buttons = document.createElement("div");
      buttons.className = "zh-search-daterange-buttons";

      SEARCH_DATE_RANGE_PRESETS.forEach((preset) => {
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = preset.label;
        button.dataset.presetId = preset.id;
        button.addEventListener("click", (event) => {
          stopEvent(event);
          const activeForm = findVisibleSearchForm() || form;
          applySearchDateRangePreset(activeForm, preset);
          // After applying, so the change events of the dropdowns cannot clear it.
          activeForm.dataset.zhSearchRangeTouched = "1";
          activeForm.dataset.zhSearchRangeLabel = preset.label;
          renderSearchHistoryBlock();
        });
        buttons.appendChild(button);
      });

      row.appendChild(buttons);
    }

    primaryBlock.appendChild(row);
  }

  function removeLegacyCreatedTimeFilters(form) {
    if (!form) return;

    form.querySelectorAll('[data-zh-created-date-filter="1"], input[name="TicketCreateTimeNewerMinutes"]').forEach((element) => {
      const name = String(element.name || "");
      if (/ticket.*create.*time|ticketcreate|TicketCreateTimeNewerMinutes/i.test(name)) {
        element.remove();
      } else {
        delete element.dataset.zhCreatedDateFilter;
      }
    });

    [...form.querySelectorAll("tr, li, fieldset, div")].forEach((element) => {
      if (element.closest("#zh-search-primary-fields")) return;
      if (element.querySelector("#Attribute")) return;

      const text = normalizeText(getElementText(element)).toLowerCase();
      const hasTicketCreateInput = [...element.querySelectorAll("input, select, textarea")]
        .some((control) => /ticket.*create.*time|create.*time.*ticket|ticketcreate/i.test(`${control.name || ""} ${control.id || ""}`));

      if ((/ticket[-\s]?erstellzeit|ticket\s*create\s*time/i.test(text) || hasTicketCreateInput) &&
          element.querySelector("input, select, textarea")) {
        element.remove();
      }
    });
  }

  function requestDefaultTicketTimeAttribute(form) {
    const attr = findSearchAttributeControl(form);
    const option = findDefaultTicketTimeAttributeOption(attr);
    if (!attr || !option) return false;

    if (form.dataset.zhDefaultTicketTimeAttributeRequested === "1" &&
        findDefaultTicketTimeFilterContainers(form).length) {
      return true;
    }

    form.dataset.zhDefaultTicketTimeAttributeRequested = "1";
    attr.value = option.value;
    option.selected = true;
    attr.dispatchEvent(new Event("input", { bubbles: true }));
    attr.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function ensureCreatedDateFilter(form) {
    removeLegacyCreatedTimeFilters(form);

    if (fillDefaultTicketTimeRange(form)) {
      cleanupEmptyGeneratedSearchFilterRows(form);
      return;
    }

    if (requestDefaultTicketTimeAttribute(form)) {
      [0, 150, 600].forEach((delay) => {
        window.setTimeout(() => {
          fillDefaultTicketTimeRange(form);
          cleanupEmptyGeneratedSearchFilterRows(form);
        }, delay);
      });
    }
  }

  function cleanupEmptyGeneratedSearchFilterRows(form) {
    if (!form) return;

    [...form.querySelectorAll("tr, li, div")].forEach((element) => {
      if (element.closest("#zh-search-primary-fields")) return;
      if (element.querySelector("#Attribute")) return;
      if (element.querySelector("select, textarea")) return;

      const inputs = [...element.querySelectorAll('input[type="text"], input:not([type]), input[type="search"]')];
      if (inputs.length !== 1 || String(inputs[0].value || "").trim()) return;

      const text = normalizeText(getElementText(element));
      if (text && !/^[\s\-–—x×]+$/i.test(text)) return;

      const hasRemoveControl = element.querySelector('button, a, img, input[type="button"]');
      if (hasRemoveControl) element.remove();
    });
  }

  function isDuplicateTicketNumberInput(input, primaryControl) {
    if (!input || input === primaryControl) return false;
    if (input.closest("#zh-search-primary-fields")) return false;

    const placeholder = input.getAttribute("placeholder") || "";
    const value = input.value || "";

    // The installation uses an example ticket number in the built-in filter field
    // ("10*5155"); match that placeholder pattern generically instead of a fixed
    // number, so this keeps working when the example changes.
    return input.name === "TicketNumber" ||
      input.name === "TicketNumberRaw" ||
      /ticket/i.test(placeholder) ||
      /\d{1,3}\s?\*\s?\d{2,}/.test(placeholder) ||
      /\d{1,3}\s?\*\s?\d{2,}/.test(value);
  }

  function findGeneratedSearchFieldRow(input, form) {
    let element = input.parentElement;
    let candidate = input.parentElement;

    while (element && element !== form) {
      if (element.matches("tr, li, .Field, .Row, .WidgetSimple, .ContentColumn")) return element;

      const controls = element.querySelectorAll("input, select, textarea").length;
      const text = normalizeText(getElementText(element));

      if (controls <= 2 && text.length <= 160) {
        candidate = element;
      }

      if (element.parentElement === form) return candidate || element;
      element = element.parentElement;
    }

    return candidate;
  }

  function hideDuplicateTicketNumberRows(form, primaryControl) {
    const candidates = [...form.querySelectorAll('input[type="text"], input:not([type]), input[type="search"]')]
      .filter((input) => isDuplicateTicketNumberInput(input, primaryControl));

    candidates.forEach((input) => {
      const row = findGeneratedSearchFieldRow(input, form);
      input.disabled = true;
      input.classList.add("zh-search-hidden-scaffold");

      if (row && row !== form && !row.closest("#zh-search-primary-fields") && !row.querySelector("#Attribute")) {
        row.classList.add("zh-search-hidden-scaffold");
        row.remove();
      }
    });
  }

  let searchHistoryCache = { entries: [] };
  let searchHistoryLoaded = false;
  let lastSearchRecordSignature = "";
  let lastSearchRecordedAt = 0;
  let searchHistoryExpanded = false;

  function searchHistorySignature(entry) {
    const range = Array.isArray(entry?.range) ? entry.range.join("-") : "";
    return [entry?.fulltext || "", entry?.ticketNumber || "", range].join("|").toLowerCase();
  }

  function normalizeSearchHistoryEntry(raw) {
    const entry = {
      fulltext: String(raw?.fulltext || "").trim().slice(0, 120),
      ticketNumber: String(raw?.ticketNumber || "").trim().slice(0, 60),
      range: Array.isArray(raw?.range) && raw.range.length >= 6
        ? raw.range.slice(0, 6).map((value) => Math.trunc(Number(value)) || 0)
        : null,
      rangeLabel: String(raw?.rangeLabel || "").trim().slice(0, 40),
      at: Number.isFinite(Number(raw?.at)) ? Number(raw.at) : 0
    };

    if (!entry.fulltext && !entry.ticketNumber && !entry.range) return null;

    return entry;
  }

  // Accepts the current shape ({ entries: [...] }), the older per-field string lists
  // ({ fulltext: [...], ticketNumber: [...] }) and a bare list of strings, so an
  // existing history is carried over instead of being dropped.
  function normalizeSearchHistory(value) {
    const entries = [];
    const seen = new Set();

    const push = (entry) => {
      const clean = normalizeSearchHistoryEntry(entry);
      if (!clean) return;

      const signature = searchHistorySignature(clean);
      if (seen.has(signature)) return;

      seen.add(signature);
      entries.push(clean);
    };

    if (Array.isArray(value?.entries)) {
      value.entries.forEach(push);
    } else if (Array.isArray(value?.fulltext) || Array.isArray(value?.ticketNumber)) {
      [...(value.fulltext || [])].forEach((item) => push({ fulltext: item }));
      [...(value.ticketNumber || [])].forEach((item) => push({ ticketNumber: item }));
    } else if (Array.isArray(value)) {
      value.forEach((item) => push({ fulltext: item }));
    }

    return { entries: entries.slice(0, SEARCH_HISTORY_LIMIT) };
  }

  // The history used to live in the page's localStorage - readable by anything on
  // the Znuny origin and lost when site data is cleared. It lives in the extension
  // storage now, like every other setting; an existing localStorage entry is
  // migrated once so nothing is lost.
  async function loadSearchHistory() {
    const stored = await syncGet("local", { [SEARCH_HISTORY_KEY]: null });
    let history = normalizeSearchHistory(stored[SEARCH_HISTORY_KEY]);

    if (!stored[SEARCH_HISTORY_KEY] || !history.entries.length) {
      let legacy = null;
      try {
        legacy = JSON.parse(localStorage.getItem(SEARCH_HISTORY_KEY) || "null");
      } catch (error) {
        legacy = null;
      }

      const migrated = legacy ? normalizeSearchHistory(legacy) : null;
      if (migrated?.entries.length) {
        history = migrated;
        await syncSet("local", { [SEARCH_HISTORY_KEY]: history });
        try {
          localStorage.removeItem(SEARCH_HISTORY_KEY);
        } catch (error) {
          // Blocked storage (private mode); the extension copy is authoritative.
        }
      }
    }

    searchHistoryCache = history;
    searchHistoryLoaded = true;
    return history;
  }

  function getSearchHistory() {
    return searchHistoryCache;
  }

  function writeSearchHistory(entries) {
    searchHistoryCache = { entries: entries.slice(0, SEARCH_HISTORY_LIMIT) };
    syncSet("local", { [SEARCH_HISTORY_KEY]: searchHistoryCache });
    renderSearchHistoryBlock();
    refreshSearchHistorySuggestions();
  }

  // One entry per executed search: search term, ticket number and - when the agent
  // picked one - the period. Searching the same thing again moves the entry up.
  function saveSearchHistoryRun(run) {
    const entry = normalizeSearchHistoryEntry({
      fulltext: run?.fulltext,
      ticketNumber: run?.ticketNumber,
      range: run?.range,
      rangeLabel: run?.rangeLabel,
      at: Date.now()
    });

    if (!entry) return;

    // A search can be started right after page load, before the stored history is in
    // memory - reading it first keeps the existing entries instead of overwriting them.
    if (!searchHistoryLoaded) {
      loadSearchHistory()
        .then(() => saveSearchHistoryRun(run))
        .catch(() => {
          // Without storage access the search is simply not remembered.
        });
      return;
    }

    const signature = searchHistorySignature(entry);
    const kept = getSearchHistory().entries.filter((existing) => searchHistorySignature(existing) !== signature);
    writeSearchHistory([entry, ...kept]);

    // Diagnostic aid, like the version marker: one line per remembered search.
    console.info("Znuny Helper: Suche im Verlauf gespeichert", {
      suche: describeSearchHistoryEntry(entry),
      zeitpunkt: describeSearchHistoryMeta(entry) || "ohne Zeitangabe"
    });
  }

  function removeSearchHistoryEntry(entry) {
    const signature = searchHistorySignature(entry);
    writeSearchHistory(getSearchHistory().entries.filter((existing) => searchHistorySignature(existing) !== signature));
  }

  function clearSearchHistory() {
    writeSearchHistory([]);
  }

  function getSearchHistoryValues(type) {
    const key = type === "ticketNumber" ? "ticketNumber" : "fulltext";

    return getSearchHistory().entries
      .map((entry) => entry[key])
      .filter(Boolean)
      .filter((value, index, all) => all.indexOf(value) === index)
      .slice(0, 5);
  }

  function formatSearchHistoryTime(at) {
    const stamp = Number(at);
    if (!Number.isFinite(stamp) || stamp <= 0) return "";

    const then = new Date(stamp);
    const now = new Date();
    const minutes = Math.floor((now.getTime() - stamp) / 60000);
    const clock = `${String(then.getHours()).padStart(2, "0")}:${String(then.getMinutes()).padStart(2, "0")}`;

    if (minutes < 1) return "gerade eben";
    if (minutes < 60) return `vor ${minutes} Min.`;
    if (then.toDateString() === now.toDateString()) return `heute ${clock}`;

    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    if (then.toDateString() === yesterday.toDateString()) return `gestern ${clock}`;

    const day = String(then.getDate()).padStart(2, "0");
    const month = String(then.getMonth() + 1).padStart(2, "0");
    return `${day}.${month}.${then.getFullYear()} ${clock}`;
  }

  function describeSearchHistoryRange(entry) {
    if (entry?.rangeLabel) return entry.rangeLabel;
    if (!Array.isArray(entry?.range) || entry.range.length < 6) return "";

    const [day1, month1, year1, day2, month2, year2] = entry.range;
    const values = [day1, month1, year1, day2, month2, year2];
    if (!values.every((value) => Number.isFinite(value) && value > 0)) return "";

    const pad = (value) => String(value).padStart(2, "0");
    return `${pad(day1)}.${pad(month1)}.${year1} – ${pad(day2)}.${pad(month2)}.${year2}`;
  }

  function describeSearchHistoryEntry(entry) {
    const parts = [entry?.fulltext, entry?.ticketNumber].filter(Boolean);
    return parts.length ? parts.join(" \u00b7 ") : "Zeitraum-Suche";
  }

  // Five entries are shown at once; more are only one click away, and nothing beyond
  // the stored limit is ever kept.
  function searchHistoryVisibleCount(total, expanded) {
    const count = Number.isFinite(Number(total)) ? Math.max(0, Math.trunc(Number(total))) : 0;
    return expanded ? count : Math.min(count, SEARCH_HISTORY_VISIBLE);
  }

  function describeSearchHistoryMeta(entry) {
    return [describeSearchHistoryRange(entry), formatSearchHistoryTime(entry?.at)]
      .filter(Boolean)
      .join(" \u00b7 ");
  }

  function renderSearchHistoryBlock() {
    document.getElementById("zh-search-history-block")?.remove();
  }

  function applySearchHistoryEntry(entry) {
    const form = findVisibleSearchForm();
    if (!form) return;

    const fulltextControl = ensureFulltextControl(form);
    const ticketNumberControl = ensureTicketNumberControl(form);

    if (fulltextControl) {
      fulltextControl.value = entry.fulltext || "";
      delete fulltextControl.dataset.zhAutoWildcard;
      fulltextControl.dispatchEvent(new Event("input", { bubbles: true }));
    }

    if (ticketNumberControl) {
      ticketNumberControl.value = entry.ticketNumber || "";
      ticketNumberControl.dispatchEvent(new Event("input", { bubbles: true }));
    }

    if (entry.range) {
      applySearchDateRangeValues(form, entry.range);
      form.dataset.zhSearchRangeTouched = "1";
      if (entry.rangeLabel) form.dataset.zhSearchRangeLabel = entry.rangeLabel;
      else delete form.dataset.zhSearchRangeLabel;
    }

    syncTicketNumberFulltextFallback(fulltextControl, ticketNumberControl);
    refreshSearchHistorySuggestions();

    const focusTarget = entry.ticketNumber && !entry.fulltext ? ticketNumberControl : fulltextControl;
    focusTarget?.focus?.();
  }

  // Das grosse Verlaufs-Panel ist entfernt: Die kurzen Vorschlaege direkt
  // unter den Suchfeldern reichen. Der gespeicherte Verlauf bleibt erhalten,
  // wird aber nicht mehr als eigener Block angezeigt.
  function getOrCreateSearchHistoryBlock() {
    document.getElementById("zh-search-history-block")?.remove();
    return null;
  }

  // The global search dialog lives in its own window on this Znuny version: the search
  // is executed in one document while the history block is looked at in another. A
  // document therefore has to follow storage changes, otherwise its list stays empty
  // even though the search was stored.
  function handleSearchHistoryStorageChange(newValue) {
    searchHistoryCache = normalizeSearchHistory(newValue);
    searchHistoryLoaded = true;
    renderSearchHistoryBlock();
    refreshSearchHistorySuggestions();
  }

  function isSearchPage() {
    const href = String(window.location?.href || "");
    let decoded = href;
    try {
      decoded = decodeURIComponent(href);
    } catch (error) {
      // Keep the raw URL; it still contains the action on this instance.
    }

    return /Action=AgentTicketSearch\b/i.test(href) || /Action=AgentTicketSearch\b/i.test(decoded);
  }

  // The automatic default period (last year up to today) is not something the agent
  // chose, so it is not worth showing in every entry.
  function isDefaultSearchDateRange(values) {
    if (!Array.isArray(values) || values.length < 6) return true;

    const end = new Date();
    const start = getSameDateLastYear(end);
    const expected = [
      start.getDate(), start.getMonth() + 1, start.getFullYear(),
      end.getDate(), end.getMonth() + 1, end.getFullYear()
    ];

    return values.every((value, index) => Number(value) === expected[index]);
  }

  // A search page is only reached by running a search, and the form then carries the
  // values that were searched. Recording them here catches every search - independent
  // of click or submit events, which a Znuny popup window can swallow entirely.
  function rememberSearchFromSearchPage(form, fulltextControl, ticketNumberControl) {
    if (!isSearchPage()) return;
    if (!fulltextControl && !ticketNumberControl) return;

    const range = readSearchDateRangeValues(form);
    if (!isDefaultSearchDateRange(range)) {
      form.dataset.zhSearchRangeTouched = "1";
    }

    rememberSearchRun(form, fulltextControl, ticketNumberControl);
  }

  function attachSearchHistory(control, type) {
    if (!control) return;

    const listId = `zh-${type}-history`;
    let list = document.getElementById(listId);
    const history = getSearchHistoryValues(type);

    if (!list) {
      list = document.createElement("datalist");
      list.id = listId;
      document.body.appendChild(list);
    }

    list.innerHTML = "";
    history.forEach((value) => {
      const option = document.createElement("option");
      option.value = value;
      list.appendChild(option);
    });

    control.setAttribute("list", listId);
    renderSearchHistoryHints(control, type);
  }

  function renderSearchHistoryHints(control, type) {
    const row = control?.closest?.(".zh-search-field-row");
    if (!row) return;

    let historyWrap = row.querySelector(`.zh-search-history[data-history-type="${type}"]`);
    const history = getSearchHistoryValues(type);

    if (!historyWrap) {
      historyWrap = document.createElement("div");
      historyWrap.className = "zh-search-history";
      historyWrap.dataset.historyType = type;
      row.appendChild(historyWrap);
    }

    historyWrap.innerHTML = "";
    history.forEach((value) => {
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = value;
      button.title = `\u201e${value}\u201c in das Feld übernehmen`;
      button.addEventListener("click", (event) => {
        stopEvent(event);
        control.value = value;
        control.dispatchEvent(new Event("input", { bubbles: true }));
        control.focus();
      });
      historyWrap.appendChild(button);
    });

    historyWrap.hidden = history.length === 0;
  }

  function refreshSearchHistorySuggestions() {
    const controls = getVisibleSearchControls();
    if (!controls) return;

    if (controls.fulltextControl) attachSearchHistory(controls.fulltextControl, "fulltext");
    if (controls.ticketNumberControl) attachSearchHistory(controls.ticketNumberControl, "ticketNumber");
  }

  function getSearchControlValue(control) {
    const value = String(control?.value || "").trim();
    const placeholder = String(control?.getAttribute?.("placeholder") || "").trim();

    if (control?.dataset?.zhAutoWildcard === "1" && value === "*") return "";
    if (placeholder && value.toLowerCase() === placeholder.toLowerCase()) return "";
    if (/^suchbegriff eingeben$/i.test(value)) return "";

    return value;
  }

  function isTicketNumberOnlySearch(fulltextControl, ticketNumberControl) {
    const ticketNumber = getSearchControlValue(ticketNumberControl);
    const fulltext = getSearchControlValue(fulltextControl);
    return Boolean(ticketNumber && !fulltext);
  }

  function syncTicketNumberFulltextFallback(fulltextControl, ticketNumberControl) {
    if (!fulltextControl) return;

    const ticketNumber = getSearchControlValue(ticketNumberControl);
    const fulltext = getSearchControlValue(fulltextControl);

    if (ticketNumber && !fulltext) {
      fulltextControl.value = "*";
      fulltextControl.dataset.zhAutoWildcard = "1";
      return;
    }

    if (!ticketNumber && fulltextControl.dataset.zhAutoWildcard === "1") {
      fulltextControl.value = "";
      delete fulltextControl.dataset.zhAutoWildcard;
    }
  }

  function bindTicketNumberFulltextFallback(fulltextControl, ticketNumberControl) {
    if (!fulltextControl || !ticketNumberControl || ticketNumberControl.dataset.zhFulltextFallbackBound === "1") return;

    ticketNumberControl.dataset.zhFulltextFallbackBound = "1";
    ["input", "change"].forEach((eventName) => {
      ticketNumberControl.addEventListener(eventName, () => {
        syncTicketNumberFulltextFallback(fulltextControl, ticketNumberControl);
      });
    });
    syncTicketNumberFulltextFallback(fulltextControl, ticketNumberControl);
  }

  function isSearchSubmitControl(target, form = null) {
    const control = target?.closest?.('button, a, [role="button"], input[type="submit"], input[type="button"]');
    if (!control) return false;
    if (form && !form.contains(control) && !control.closest(".Dialog, .Modal, #SearchDialog, .Popup")) return false;

    const text = normalizeText(control.value || control.innerText || control.textContent || "").toLowerCase();

    return text.includes("suche starten") ||
      (control.tagName === "INPUT" && String(control.type || "").toLowerCase() === "submit");
  }

  function submitSearchFormDirectly(form) {
    if (form.dataset.zhDirectSearchSubmitting === "1") return;
    form.dataset.zhDirectSearchSubmitting = "1";
    prepareSearchFormNewTab(form);
    window.setTimeout(() => {
      delete form.dataset.zhDirectSearchSubmitting;
    }, 5000);

    if (typeof HTMLFormElement !== "undefined" && HTMLFormElement.prototype.submit) {
      HTMLFormElement.prototype.submit.call(form);
    } else {
      form.submit();
    }
  }

  function getVisibleSearchControls() {
    const form = findVisibleSearchForm();
    if (!form) return null;

    return {
      form,
      fulltextControl: ensureFulltextControl(form),
      ticketNumberControl: form.querySelector('[data-zh-ticketnumber-control="1"]') ||
        findFormControl(form, ["TicketNumber", "TicketNumberRaw"]),
      createdMonthsControl: form.querySelector('[data-zh-createdmonths-control="1"]')
    };
  }

  function prepareSearchFormNewTab(form) {
    if (!form) return;

    if (!settings.searchResultsPopup) {
      form.removeAttribute("target");
      form.removeAttribute("rel");
      return;
    }

    form.target = "_blank";
    form.rel = "noopener noreferrer";
  }

  function prepareTicketNumberOnlySearch(form, fulltextControl, ticketNumberControl) {
    const ticketNumber = getSearchControlValue(ticketNumberControl);
    if (!ticketNumber) return;

    ticketNumberControl.value = ticketNumber;

    if (fulltextControl) {
      fulltextControl.value = "*";
      fulltextControl.dataset.zhAutoWildcard = "1";
    } else {
      ensureHiddenInput(form, "Fulltext", "*");
    }

    // Bewusst KEIN Zeitraum: Eine Ticketnummer ist eindeutig. Das frueher
    // automatisch gesetzte Fenster "letzte 12 Monate" machte aeltere Tickets
    // unsichtbar - genau die Nummern, die sich "einfach nicht finden" liessen.
    // Reste alter Versionen werden entfernt, eine manuell gewaehlte Zeitspanne
    // des Nutzers bleibt unangetastet.
    removeLegacyCreatedTimeFilters(form);
  }

  // Eine Nummer im Formular heisst: nicht zusaetzlich auf ein Jahr einschraenken.
  function hasTicketNumberValue(form) {
    if (!form) return false;

    const control = form.querySelector('[data-zh-ticketnumber-control="1"]') ||
      form.querySelector('[name="TicketNumber"], [name="TicketNumberRaw"]');

    return Boolean(getSearchControlValue(control));
  }

  // The alert-based fallback for a ticket-number-only search lives in
  // page-bridge.js (MAIN world) - the only world where Znuny's own alert() can be
  // intercepted. This listener keeps the search history complete on that path too.
  function installPageSearchHistoryBridge() {
    if (window.__znunyHelperSearchHistoryBridge === "1") return;
    window.__znunyHelperSearchHistoryBridge = "1";

    window.addEventListener("znuny-helper-ticketnumber-search", (event) => {
      // The attribute is the transport that always survives the realm boundary.
      const ticketNumber = normalizeText(
        event.detail?.ticketNumber || document.documentElement.dataset.zhTicketnumberSearch || ""
      );
      delete document.documentElement.dataset.zhTicketnumberSearch;
      if (!ticketNumber) return;

      const controls = getVisibleSearchControls();
      const form = controls?.form || null;
      const touched = form?.dataset?.zhSearchRangeTouched === "1";

      saveSearchHistoryRun({
        ticketNumber,
        fulltext: controls ? getSearchControlValue(controls.fulltextControl) : "",
        range: touched ? readSearchDateRangeValues(form) : null,
        rangeLabel: touched ? form.dataset.zhSearchRangeLabel : ""
      });
    });
  }

  function handleTicketNumberOnlySearch(event, form, fulltextControl, ticketNumberControl) {
    if (!isTicketNumberOnlySearch(fulltextControl, ticketNumberControl)) return false;

    prepareTicketNumberOnlySearch(form, fulltextControl, ticketNumberControl);
    rememberSearchRun(form, fulltextControl, ticketNumberControl);

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation?.();
    submitSearchFormDirectly(form);
    return true;
  }

  function handleVisibleTicketNumberOnlySearch(event) {
    if (!settings.ticketNumberSearch) return false;

    const controls = getVisibleSearchControls();
    if (!controls) return false;

    return handleTicketNumberOnlySearch(
      event,
      controls.form,
      controls.fulltextControl,
      controls.ticketNumberControl
    );
  }

  // One history entry per executed search - so the entry can put search term, ticket
  // number and period back into the form at once. Recorded on the click that starts
  // the search: depending on the Znuny version the form never raises a submit event
  // (the search dialog works through its own handler), and then nothing was stored.
  function rememberSearchRun(form, fulltextControl, ticketNumberControl) {
    const touched = form?.dataset?.zhSearchRangeTouched === "1";
    const run = {
      fulltext: getSearchControlValue(fulltextControl),
      ticketNumber: getSearchControlValue(ticketNumberControl),
      range: touched ? readSearchDateRangeValues(form) : null,
      rangeLabel: touched ? form.dataset.zhSearchRangeLabel : ""
    };

    const entry = normalizeSearchHistoryEntry({ ...run, at: Date.now() });
    if (!entry) return;

    // pointerdown, mousedown and click all report the same search; remember it once.
    const signature = searchHistorySignature(entry);
    const now = Date.now();
    if (signature === lastSearchRecordSignature && now - lastSearchRecordedAt < 3000) return;

    lastSearchRecordSignature = signature;
    lastSearchRecordedAt = now;
    saveSearchHistoryRun(run);
  }

  function handleSearchStartEvent(event) {
    // Without the extended search there is nothing to remember, and the form must not be
    // touched at all.
    if (!settings.ticketNumberSearch) return;
    if (!isSearchSubmitControl(event.target)) return;

    const controls = getVisibleSearchControls();
    prepareSearchFormNewTab(controls?.form || null);

    // Remember the search on the click itself, not only on "submit": Znuny runs the
    // search through its own handler and, depending on the window, never raises a
    // submit event.
    if (controls?.form) {
      rememberSearchRun(controls.form, controls.fulltextControl, controls.ticketNumberControl);
    }

    handleVisibleTicketNumberOnlySearch(event);
  }

  function handleSearchFieldEnter(event) {
    if (!settings.ticketNumberSearch) return;
    if (event.key !== "Enter") return;

    const form = event.target?.closest?.("form");
    if (!form || form !== findVisibleSearchForm()) return;

    rememberSearchRun(form, ensureFulltextControl(form), ensureTicketNumberControl(form));
  }

  function bindGlobalSearchStartListeners() {
    if (document.documentElement.dataset.zhTicketSearchGlobalClick === "1") return;
    document.documentElement.dataset.zhTicketSearchGlobalClick = "1";

    // Bound on window and document in the capture phase and for several mouse events:
    // a Znuny popup window may swallow a single event, but not all of them.
    ["pointerdown", "pointerup", "mousedown", "mouseup", "click"].forEach((eventName) => {
      [window, document].forEach((target) => {
        target.addEventListener(eventName, handleSearchStartEvent, true);
      });
    });

    [window, document].forEach((target) => {
      target.addEventListener("keydown", handleSearchFieldEnter, true);
    });
  }

  function rememberSearchOnSubmit(form, fulltextControl, ticketNumberControl, createdMonthsControl) {
    if (form.dataset.zhSearchHistoryBound === "1") return;
    form.dataset.zhSearchHistoryBound = "1";

    form.addEventListener("click", (event) => {
      if (!isSearchSubmitControl(event.target, form)) return;
      prepareSearchFormNewTab(form);
      handleVisibleTicketNumberOnlySearch(event);
    }, true);

    form.addEventListener("submit", (event) => {
      prepareSearchFormNewTab(form);
      if (handleVisibleTicketNumberOnlySearch(event)) return;

      // Mit Ticketnummer nicht auf ein Jahr einschraenken - sonst bleiben
      // aeltere Tickets unauffindbar.
      if (!hasTicketNumberValue(form)) ensureCreatedDateFilter(form, createdMonthsControl);
      rememberSearchRun(form, fulltextControl, ticketNumberControl);
    }, true);

    bindGlobalSearchStartListeners();
  }

  function getOrCreateSearchPrimaryBlock(form) {
    let block = document.getElementById("zh-search-primary-fields");
    if (block) return block;

    block = document.createElement("div");
    block.id = "zh-search-primary-fields";

    const title = document.createElement("div");
    title.className = "zh-search-primary-title";
    title.textContent = "Suchen";
    block.appendChild(title);

    const firstContent = [...form.children].find((child) => {
      const text = getElementText(child).trim().toLowerCase();
      return text && text !== "suche";
    });

    form.insertBefore(block, firstContent || form.firstChild);
    return block;
  }

  function getOrCreateCleanSearchRow(primaryBlock, id, labelText, control, placeholder) {
    let row = document.getElementById(id);
    const sourceRow = findSearchFieldRow(control);

    if (!control.id) {
      control.id = `${id}-input`;
    }

    if (!row) {
      row = document.createElement("div");
      row.id = id;
      row.className = "zh-search-field-row";

      const label = document.createElement("label");
      label.textContent = labelText;
      label.htmlFor = control.id;
      row.appendChild(label);
    }

    control.placeholder = placeholder || "";
    control.classList.add("zh-search-primary-input");
    row.appendChild(control);
    primaryBlock.appendChild(row);

    if (sourceRow && sourceRow !== row && !sourceRow.closest("#zh-search-primary-fields")) {
      sourceRow.classList.add("zh-search-hidden-scaffold");
    }

    return row;
  }

  function moveKnownSearchSectionsAfterPrimary(form, primaryBlock) {
    const sectionTexts = ["vorlagen", "zus\u00e4tzliche filter"];

    sectionTexts.reverse().forEach((sectionText) => {
      const section = [...form.children].find((child) => {
        const text = getElementText(child).trim().toLowerCase();
        return text === sectionText || text.startsWith(`${sectionText}\n`);
      });

      if (section && section !== primaryBlock) {
        primaryBlock.after(section);
      }
    });
  }

  function hideOldUsedFilterScaffold(form) {
    [...form.querySelectorAll("h1, h2, h3, h4, strong, label, div, p, span")].forEach((element) => {
      if (element.closest("#zh-search-primary-fields")) return;

      const text = getElementText(element).trim().toLowerCase();
      if (["verwendete filter", "volltext:", "case:"].includes(text)) {
        element.classList.add("zh-search-hidden-scaffold");
      }
    });

    const emptyRows = [...form.querySelectorAll("div, li, tr")].filter((element) => {
      if (element.closest("#zh-search-primary-fields")) return false;
      if (element.querySelector("input, select, textarea, button")) return false;

      const text = getElementText(element).trim().toLowerCase();
      return ["verwendete filter", "volltext:", "case:"].includes(text);
    });

    emptyRows.forEach((element) => element.classList.add("zh-search-hidden-scaffold"));
  }

  function addSearchModalStyles() {
    addStyle("zh-search-modal-style", `
      #zh-search-primary-fields { padding: 12px 0 14px; border-bottom: 1px solid #d6d6d6; }
      #zh-search-primary-fields .zh-search-primary-title { width: 270px; margin: 0 auto 8px; font-weight: 700; text-align: left; }
      #zh-search-primary-fields .zh-search-field-row { display: grid; grid-template-columns: minmax(130px, 1fr) 270px minmax(130px, 1fr); align-items: center; gap: 8px; margin: 7px 0; }
      #zh-search-primary-fields .zh-search-field-row label { grid-column: 1; text-align: right; color: #777; }
      #zh-search-primary-fields .zh-search-primary-input { grid-column: 2; width: 270px; max-width: 45vw; box-sizing: border-box; }
      #zh-search-primary-fields .zh-search-history { grid-column: 2; display: flex; flex-wrap: wrap; gap: 4px; margin: -3px 0 2px; max-width: 270px; }
      #zh-search-primary-fields .zh-search-history[hidden] { display: none !important; }
      #zh-search-primary-fields .zh-search-history button { max-width: 128px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 10px; line-height: 1.3; padding: 2px 6px; border: 1px solid #bdbdbd; border-radius: 3px; background: #f7f7f7; color: #333; cursor: pointer; }
      #zh-search-primary-fields .zh-search-history button:hover { background: #fff; border-color: #888; }
      .zh-search-daterange-label { grid-column: 1; text-align: right; color: #777; }
      #zh-search-primary-fields .zh-search-field-row.zh-search-daterange-row { grid-template-columns: minmax(130px, 1fr) minmax(270px, max-content) minmax(130px, 1fr); }
      #zh-search-primary-fields .zh-search-daterange-buttons { grid-column: 2; display: flex; flex-wrap: nowrap; gap: 6px; width: auto; max-width: none; box-sizing: border-box; }
      #zh-search-primary-fields .zh-search-daterange-buttons button { flex: 0 0 auto; font-size: 11px; padding: 3px 8px; border: 1px solid #bdbdbd; border-radius: 3px; background: #f7f7f7; color: #333; cursor: pointer; white-space: nowrap; }
      .zh-search-daterange-buttons button:hover { background: #fff; border-color: #888; }
      #zh-search-primary-fields .zh-search-history-block { display: grid; grid-template-columns: minmax(130px, 1fr) 270px minmax(130px, 1fr); margin: 12px 0 2px; padding-top: 10px; border-top: 1px solid #e6e6e6; }
      #zh-search-primary-fields .zh-search-history-head { grid-column: 2 / 4; display: flex; align-items: baseline; justify-content: space-between; gap: 10px; margin: 0 0 6px; }
      #zh-search-primary-fields .zh-search-history-title { color: #555; font-size: 12px; font-weight: 700; }
      #zh-search-primary-fields .zh-search-history-actions { display: flex; align-items: baseline; gap: 10px; }
      #zh-search-primary-fields .zh-search-history-toggle,
      #zh-search-primary-fields .zh-search-history-clear { padding: 0; border: 0; background: none; color: #1f5f9f; font-size: 11px; cursor: pointer; text-decoration: underline; }
      #zh-search-primary-fields .zh-search-history-toggle[hidden],
      #zh-search-primary-fields .zh-search-history-clear[hidden] { display: none; }
      #zh-search-primary-fields .zh-search-history-list { grid-column: 2 / 4; display: grid; gap: 4px; margin: 0; padding: 0; list-style: none; }
      #zh-search-primary-fields .zh-search-history-entry { display: flex; align-items: stretch; gap: 4px; }
      #zh-search-primary-fields .zh-search-history-apply { flex: 1; display: grid; gap: 1px; padding: 5px 8px; border: 1px solid #ddd; border-radius: 3px; background: #fafafa; color: #222; font: inherit; text-align: left; cursor: pointer; }
      #zh-search-primary-fields .zh-search-history-apply:hover { background: #fff; border-color: #ff9900; }
      #zh-search-primary-fields .zh-search-history-text { font-size: 11.5px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      #zh-search-primary-fields .zh-search-history-meta { color: #888; font-size: 10px; }
      #zh-search-primary-fields .zh-search-history-remove { width: 24px; border: 1px solid #ddd; border-radius: 3px; background: #fafafa; color: #999; font-size: 12px; line-height: 1; cursor: pointer; }
      #zh-search-primary-fields .zh-search-history-remove:hover { background: #fff; border-color: #c0392b; color: #c0392b; }
      #zh-search-primary-fields .zh-search-history-empty { grid-column: 2 / 4; margin: 0; color: #888; font-size: 11px; }
      #zh-search-primary-fields .zh-search-history-block[data-empty="1"] .zh-search-history-list { display: none; }
      #zh-search-primary-fields .zh-search-history-block[data-empty="0"] .zh-search-history-empty { display: none; }
      .zh-search-hidden-scaffold { display: none !important; }
    `);
  }

  function findArticleOverviewTable(doc = document) {
    return [...doc.querySelectorAll("table")].find((table) => {
      return isArticleOverviewTable(table);
    });
  }

  function getElementText(element) {
    return element?.innerText || element?.textContent || "";
  }

  function isArticleOverviewTable(table) {
    const headers = [...table.querySelectorAll("th")].map((th) => getElementText(th).trim().toUpperCase());

    return headers.some((header) => header === "NR." || header === "NR") &&
      headers.some((header) => header.includes("SENDER")) &&
      headers.some((header) => header.includes("BETREFF")) &&
      headers.some((header) => header.includes("ERSTELLT"));
  }

  function getAccessibleSearchDocuments() {
    const docs = [document];

    document.querySelectorAll("iframe, frame").forEach((frame) => {
      try {
        const frameDoc = frame.contentDocument || frame.contentWindow?.document;
        if (frameDoc?.body) docs.push(frameDoc);
      } catch (error) {
        // Cross-origin frames cannot be searched directly.
      }
    });

    return docs;
  }

  function getTicketArticleSearchRoots() {
    return getAccessibleSearchDocuments().map((doc) =>
      doc.querySelector("#MainBox") ||
      doc.querySelector("#Content") ||
      doc.querySelector(".Content") ||
      doc.querySelector("#Center") ||
      doc.body
    ).filter(Boolean);
  }

  function getArticleSearchTerms(query) {
    const phrase = normalizeText(query).replace(/\s+/g, " ").trim();
    return phrase ? [phrase] : [];
  }

  function foldSearchChar(char, mode) {
    const lower = char.toLowerCase();

    if (lower === "\u00df") return "ss";

    if (mode === "german") {
      if (lower === "\u00e4") return "ae";
      if (lower === "\u00f6") return "oe";
      if (lower === "\u00fc") return "ue";
    }

    if (mode === "base") {
      if (lower === "\u00e4") return "a";
      if (lower === "\u00f6") return "o";
      if (lower === "\u00fc") return "u";
    }

    return lower.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }

  function keepFoldedSearchChar(value) {
    return /^[a-z0-9]+$/.test(value);
  }

  function foldSearchText(value, mode) {
    return Array.from(String(value || ""))
      .map((char) => foldSearchChar(char, mode))
      .filter(keepFoldedSearchChar)
      .join("");
  }

  function foldSearchTextWithMap(value, mode) {
    const source = String(value || "");
    let folded = "";
    const map = [];

    Array.from(source).forEach((char, index) => {
      const foldedChar = foldSearchChar(char, mode);
      if (!keepFoldedSearchChar(foldedChar)) return;

      folded += foldedChar;

      for (let offset = 0; offset < foldedChar.length; offset += 1) {
        map.push(index);
      }
    });

    return { folded, map };
  }

  function getFoldedTermVariants(term) {
    return [...new Set([
      foldSearchText(term, "german"),
      foldSearchText(term, "base")
    ].filter(Boolean))];
  }

  function textMatchesSearchTerms(text, terms) {
    if (terms.length === 0) return false;

    const foldedTextVariants = [
      foldSearchText(text, "german"),
      foldSearchText(text, "base")
    ];

    return terms.every((term) => {
      const termVariants = getFoldedTermVariants(term);
      return foldedTextVariants.some((foldedText) =>
        termVariants.some((foldedTerm) => foldedText.includes(foldedTerm))
      );
    });
  }

  function addArticleSearchRowMatch(row) {
    if (!row || articleSearchState.rowMatches.includes(row)) return;

    row.classList.add("zh-ticket-search-row-hit");
    articleSearchState.rowMatches.push(row);
  }

  function findRangesForFoldMode(text, terms, mode) {
    const { folded, map } = foldSearchTextWithMap(text, mode);
    const ranges = [];

    terms.forEach((term) => {
      const foldedTerm = foldSearchText(term, mode);
      if (!foldedTerm) return;

      let start = folded.indexOf(foldedTerm);
      while (start !== -1) {
        const end = start + foldedTerm.length - 1;
        const originalStart = map[start];
        const originalEnd = map[end] + 1;

        if (Number.isInteger(originalStart) && Number.isInteger(originalEnd)) {
          ranges.push([originalStart, originalEnd]);
        }

        start = folded.indexOf(foldedTerm, start + Math.max(foldedTerm.length, 1));
      }
    });

    return ranges;
  }

  function mergeSearchRanges(ranges) {
    const sorted = ranges
      .filter(([start, end]) => end > start)
      .sort((a, b) => a[0] - b[0] || b[1] - a[1]);

    const merged = [];

    sorted.forEach(([start, end]) => {
      const last = merged[merged.length - 1];

      if (!last || start > last[1]) {
        merged.push([start, end]);
      } else {
        last[1] = Math.max(last[1], end);
      }
    });

    return merged;
  }

  function findNormalizedSearchRanges(text, terms) {
    return mergeSearchRanges([
      ...findRangesForFoldMode(text, terms, "german"),
      ...findRangesForFoldMode(text, terms, "base")
    ]);
  }

  function clearArticleSearchHighlights() {
    clearArticleTextHighlights();

    document.querySelectorAll(".zh-ticket-search-row-hit").forEach((row) => {
      row.classList.remove("zh-ticket-search-row-hit");
    });

    document.querySelectorAll(".zh-ticket-search-row-active").forEach((row) => {
      row.classList.remove("zh-ticket-search-row-active");
    });

    articleSearchState.matches = [];
    articleSearchState.rowMatches = [];
    articleSearchState.blockMatches = [];
    articleSearchState.activeIndex = -1;
  }

  function clearArticleTextHighlights() {
    getAccessibleSearchDocuments().forEach((doc) => {
      doc.querySelectorAll("mark.zh-ticket-search-hit").forEach((mark) => {
        const text = doc.createTextNode(mark.textContent || "");
        mark.replaceWith(text);
        text.parentElement?.normalize();
      });

      doc.querySelectorAll(".zh-ticket-search-active").forEach((mark) => {
        mark.classList.remove("zh-ticket-search-active");
      });
    });

    getAccessibleSearchDocuments().forEach((doc) => {
      doc.querySelectorAll(".zh-ticket-search-block-hit, .zh-ticket-search-block-active").forEach((element) => {
        element.classList.remove("zh-ticket-search-block-hit", "zh-ticket-search-block-active");
      });
    });

    articleSearchState.matches = [];
    articleSearchState.blockMatches = [];
  }

  function textNodeCanBeHighlighted(node) {
    const parent = node.parentElement;
    if (!parent || !node.nodeValue.trim()) return false;

    if (parent.closest("#zh-ticket-article-search")) return false;
    if (parent.closest("script, style, textarea, input, select, button, mark")) return false;
    if (parent.closest(".zh-preview-backdrop, .zh-note-popup")) return false;
    if (isNonArticleSearchArea(parent)) return false;

    const closestTable = parent.closest("table");
    if (closestTable && isArticleOverviewTable(closestTable)) return false;

    const rect = parent.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function highlightArticleSearchTerms(root, terms) {
    const createdMarks = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!textNodeCanBeHighlighted(node)) return NodeFilter.FILTER_REJECT;
        return findNormalizedSearchRanges(node.nodeValue, terms).length > 0 ?
          NodeFilter.FILTER_ACCEPT :
          NodeFilter.FILTER_REJECT;
      }
    });

    const nodes = [];
    let current = walker.nextNode();

    while (current) {
      nodes.push(current);
      current = walker.nextNode();
    }

    nodes.forEach((node) => {
      const ownerDocument = node.ownerDocument || document;
      const fragment = ownerDocument.createDocumentFragment();
      const text = node.nodeValue;
      const ranges = findNormalizedSearchRanges(text, terms);
      let cursor = 0;

      ranges.forEach(([start, end]) => {
        if (start > cursor) {
          fragment.appendChild(ownerDocument.createTextNode(text.slice(cursor, start)));
        }

        const mark = ownerDocument.createElement("mark");
        mark.className = "zh-ticket-search-hit";
        mark.textContent = text.slice(start, end);
        createdMarks.push(mark);
        fragment.appendChild(mark);
        cursor = end;
      });

      if (cursor < text.length) {
        fragment.appendChild(ownerDocument.createTextNode(text.slice(cursor)));
      }

      node.replaceWith(fragment);
    });

    return createdMarks;
  }

  function markArticleOverviewRows(terms) {
    const table = findArticleOverviewTable();
    if (!table) return;

    [...table.querySelectorAll("tbody tr")].forEach((row) => {
      if (textMatchesSearchTerms(row.innerText, terms)) {
        addArticleSearchRowMatch(row);
      }
    });
  }

  function elementCanBeArticleSearchBlock(element) {
    if (!element || element.id === "zh-ticket-article-search") return false;
    if (element.closest("#zh-ticket-article-search")) return false;
    if (element.closest(".zh-preview-backdrop, .zh-note-popup")) return false;

    const closestTable = element.closest("table");
    if (closestTable && isArticleOverviewTable(closestTable)) return false;

    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;

    const text = normalizeText(element.innerText || "");
    return text.length >= 3 && text.length <= 5000;
  }

  function markVisibleArticleBlocks(terms) {
    getTicketArticleSearchRoots().forEach((root) => {
      const candidates = [...root.querySelectorAll("p, div, td, li, blockquote, pre, section, article")]
        .filter(elementCanBeArticleSearchBlock)
        .filter((element) => textMatchesSearchTerms(element.innerText, terms));

      candidates.forEach((element) => {
        const hasMatchingChild = candidates.some((candidate) =>
          candidate !== element && element.contains(candidate)
        );

        if (hasMatchingChild || articleSearchState.blockMatches.includes(element)) return;

        element.classList.add("zh-ticket-search-block-hit");
        articleSearchState.blockMatches.push(element);
      });
    });
  }

  function shouldUseDeepArticleSearch(terms) {
    return terms.some((term) => foldSearchText(term, "german").length >= 2);
  }

  function isNonArticleSearchArea(element) {
    return Boolean(element.closest(
      "#zh-ticket-article-search, .zh-preview-backdrop, .zh-note-popup, #Sidebar, .Sidebar, .SidebarColumn, .LayoutSidebar, .WidgetSimple.TicketInformation, .ActionRow, .LayoutActionRow, .Header, #Navigation, #ToolBar"
    ));
  }

  function getOpenedArticleSearchRoots(doc = document) {
    const selectors = [
      ".ArticleBody",
      ".ArticleContent",
      ".ArticleMailContent",
      ".ArticleMailContentHTML",
      ".MessageBody",
      ".RichText",
      ".Plain",
      ".Article"
    ];

    const candidates = selectors.flatMap((selector) => [...doc.querySelectorAll(selector)])
      .filter((element) => !isNonArticleSearchArea(element))
      .filter((element) => {
        const table = element.closest("table");
        if (table && isArticleOverviewTable(table)) return false;

        const rect = element.getBoundingClientRect();
        const text = normalizeText(getElementText(element));
        return rect.width > 0 && rect.height > 0 && text.length >= 2;
      });

    const minimalCandidates = candidates.filter((element) =>
      !candidates.some((candidate) => candidate !== element && element.contains(candidate))
    );

    if (minimalCandidates.length > 0) return minimalCandidates;

    return getTicketArticleSearchRoots()
      .filter((root) => root.ownerDocument === doc)
      .flatMap((root) => {
        const table = findArticleOverviewTable(doc);
        if (!table) return root;

        const tableBottom = table.getBoundingClientRect().bottom;
        const fallbackCandidates = [...root.querySelectorAll("div, td, pre, blockquote, section, article")]
          .filter((element) => !isNonArticleSearchArea(element))
          .filter((element) => {
            const rect = element.getBoundingClientRect();
            const text = normalizeText(getElementText(element));
            return rect.width > 0 && rect.height > 0 && rect.top > tableBottom && text.length >= 2 && text.length <= 20000;
          });

        const fallback = fallbackCandidates.filter((element) =>
          !fallbackCandidates.some((candidate) => candidate !== element && element.contains(candidate))
        );

        return fallback.length > 0 ? fallback : [root];
      });
  }

  function getTicketArticleRows() {
    const table = findArticleOverviewTable();
    return table ? [...table.querySelectorAll("tbody tr")] : [];
  }

  function getArticleRowUrl(row) {
    const directLink = row.querySelector(
      'a[href*="AgentTicketZoom"], a[href*="ArticleID"], a[href*="Article"]'
    );

    if (directLink?.href) return directLink.href;

    const clickSource = row.getAttribute("onclick") || "";
    const quotedUrl = clickSource.match(/['"]([^'"]*index\.pl[^'"]*)['"]/)?.[1];

    if (quotedUrl) {
      return new URL(quotedUrl, window.location.href).href;
    }

    const articleId = row.innerHTML.match(/ArticleID[=:]\s*["']?(\d+)/i)?.[1];
    const ticketId = window.location.href.match(/[?;]TicketID=(\d+)/i)?.[1];

    if (articleId && ticketId) {
      const url = new URL(window.location.href);
      url.search = `?Action=AgentTicketZoom;TicketID=${ticketId};ArticleID=${articleId}`;
      return url.href;
    }

    return "";
  }

  function htmlToSearchText(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll("script, style, noscript, #zh-ticket-article-search, #Sidebar, .Sidebar, .SidebarColumn, .LayoutSidebar, .ActionRow, .LayoutActionRow, #Navigation, #ToolBar").forEach((element) => element.remove());
    doc.querySelectorAll("table").forEach((table) => {
      if (isArticleOverviewTable(table)) table.remove();
    });
    return normalizeText(getElementText(doc.body));
  }

  async function searchLinkedArticleRows(terms, runId) {
    const rows = getTicketArticleRows();
    const requests = rows.map(async (row) => {
      if (articleSearchState.rowMatches.includes(row)) return;

      const url = getArticleRowUrl(row);
      if (!url) return;

      try {
        let text = articleSearchState.fetchCache.get(url);

        if (!text) {
          const response = await fetch(url, {
            credentials: "include",
            cache: "no-store"
          });

          if (!response.ok) return;
          text = htmlToSearchText(await response.text());
          articleSearchState.fetchCache.set(url, text);
        }

        if (runId !== articleSearchState.runId) return;

        if (textMatchesSearchTerms(text, terms)) {
          addArticleSearchRowMatch(row);
        }
      } catch (error) {
        console.warn("Znuny Helper article search fetch failed:", error);
      }
    });

    await Promise.all(requests);

    if (runId === articleSearchState.runId) {
      if (articleSearchState.matches.length === 0 && articleSearchState.rowMatches.length > 0 && articleSearchState.activeIndex < 0) {
        focusArticleSearchMatch(0);
      } else {
        updateArticleSearchStatus();
      }
    }
  }

  function sleep(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function getCleanArticleSearchText(root) {
    const clone = root.cloneNode(true);

    clone.querySelectorAll("#zh-ticket-article-search, .zh-preview-backdrop, .zh-note-popup, script, style, noscript, input, select, textarea, button, #Sidebar, .Sidebar, .SidebarColumn, .LayoutSidebar, .ActionRow, .LayoutActionRow, #Navigation, #ToolBar").forEach((element) => {
      element.remove();
    });

    clone.querySelectorAll("table").forEach((table) => {
      if (isArticleOverviewTable(table)) table.remove();
    });

    return normalizeText(getElementText(clone));
  }

  function getSearchableOpenedArticleText() {
    return getAccessibleSearchDocuments().map((doc) => {
      return getOpenedArticleSearchRoots(doc)
        .map(getCleanArticleSearchText)
        .join("\n");
    }).join("\n");
  }

  function clickArticleRow(row) {
    const clickable =
      row.querySelector('a[href], button, [onclick], [role="button"]') ||
      row;

    clickable.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    clickable.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    clickable.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true, view: window }));
  }

  function highlightCurrentlyOpenedArticle(terms) {
    clearArticleTextHighlights();
    addTicketArticleSearchStyles();

    getAccessibleSearchDocuments().flatMap((doc) => getOpenedArticleSearchRoots(doc)).forEach((root) => {
      articleSearchState.matches.push(...highlightArticleSearchTerms(root, terms));
    });
  }

  async function searchRowsByOpeningArticles(terms, runId) {
    const rows = getTicketArticleRows();
    if (rows.length === 0 || rows.length > 40) {
      updateArticleSearchStatus();
      return;
    }

    const matchedRows = [];
    suppressMutationScanUntil = Date.now() + Math.max(3000, rows.length * 520);
    setArticleSearchStatusText("Suche...");

    for (const row of rows) {
      if (runId !== articleSearchState.runId) return;
      if (articleSearchState.rowMatches.includes(row)) continue;

      clickArticleRow(row);
      await sleep(420);

      if (runId !== articleSearchState.runId) return;

      if (textMatchesSearchTerms(getSearchableOpenedArticleText(), terms)) {
        addArticleSearchRowMatch(row);
        matchedRows.push(row);
      }
    }

    if (runId !== articleSearchState.runId || matchedRows.length === 0) {
      updateArticleSearchStatus();
      return;
    }

    focusArticleSearchMatch(0);
  }

  function setArticleSearchStatusText(text) {
    const container = document.getElementById("zh-ticket-article-search");
    const status = container?.querySelector(".zh-ticket-search-status");
    if (status) status.textContent = text;
  }

  function updateArticleSearchStatus() {
    const container = document.getElementById("zh-ticket-article-search");
    const status = container?.querySelector(".zh-ticket-search-status");
    if (!status) return;

    if (
      articleSearchState.matches.length === 0 &&
      articleSearchState.rowMatches.length === 0 &&
      articleSearchState.blockMatches.length === 0
    ) {
      status.textContent = "0 Treffer";
      return;
    }

    if (articleSearchState.rowMatches.length > 0) {
      const current = articleSearchState.activeIndex >= 0 ? articleSearchState.activeIndex + 1 : 1;
      const textHits = articleSearchState.matches.length > 0 ? `, ${articleSearchState.matches.length} Treffer` : "";
      status.textContent = `${current}/${articleSearchState.rowMatches.length} Artikel${textHits}`;
      return;
    }

    if (articleSearchState.matches.length > 0) {
      const articleCount = articleSearchState.rowMatches.length + articleSearchState.blockMatches.length;
      const rowText = articleCount > 0 ? `, ${articleCount} Artikel` : "";
      status.textContent = `${articleSearchState.activeIndex + 1}/${articleSearchState.matches.length}${rowText}`;
      return;
    }

    status.textContent = `${articleSearchState.rowMatches.length + articleSearchState.blockMatches.length} Artikel`;
  }

  async function focusArticleSearchMatch(index) {
    document.querySelectorAll(".zh-ticket-search-row-active").forEach((row) => {
      row.classList.remove("zh-ticket-search-row-active");
    });

    getAccessibleSearchDocuments().forEach((doc) => {
      doc.querySelectorAll(".zh-ticket-search-block-active").forEach((element) => {
        element.classList.remove("zh-ticket-search-block-active");
      });
    });

    if (articleSearchState.rowMatches.length > 0) {
      articleSearchState.activeIndex = (index + articleSearchState.rowMatches.length) % articleSearchState.rowMatches.length;

      const activeRow = articleSearchState.rowMatches[articleSearchState.activeIndex];
      activeRow.classList.add("zh-ticket-search-row-active");
      activeRow.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
      clickArticleRow(activeRow);
      await sleep(420);

      if (articleSearchState.terms.length > 0) {
        highlightCurrentlyOpenedArticle(articleSearchState.terms);

        if (articleSearchState.matches.length > 0) {
          articleSearchState.matches[0].classList.add("zh-ticket-search-active");
          articleSearchState.matches[0].scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
        }
      }

      updateArticleSearchStatus();
      return;
    }

    if (articleSearchState.matches.length === 0 && articleSearchState.blockMatches.length > 0) {
      articleSearchState.activeIndex = (index + articleSearchState.blockMatches.length) % articleSearchState.blockMatches.length;

      const activeBlock = articleSearchState.blockMatches[articleSearchState.activeIndex];
      activeBlock.classList.add("zh-ticket-search-block-active");
      activeBlock.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
      updateArticleSearchStatus();
      return;
    }

    if (articleSearchState.matches.length === 0) {
      updateArticleSearchStatus();
      return;
    }

    articleSearchState.matches.forEach((match) => match.classList.remove("zh-ticket-search-active"));
    articleSearchState.activeIndex = (index + articleSearchState.matches.length) % articleSearchState.matches.length;

    const active = articleSearchState.matches[articleSearchState.activeIndex];
    active.classList.add("zh-ticket-search-active");
    active.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    updateArticleSearchStatus();
  }

  function applyArticleSearch(query) {
    const runId = articleSearchState.runId + 1;
    articleSearchState.runId = runId;
    clearArticleSearchHighlights();

    const terms = getArticleSearchTerms(query);
    articleSearchState.terms = terms;
    if (terms.length === 0) {
      updateArticleSearchStatus();
      return;
    }

    addTicketArticleSearchStyles();
    const useDeepSearch = shouldUseDeepArticleSearch(terms);

    markArticleOverviewRows(terms);

    if (articleSearchState.rowMatches.length === 0 && useDeepSearch) {
      searchRowsByOpeningArticles(terms, runId);
      return;
    }

    if (articleSearchState.rowMatches.length > 0) {
      focusArticleSearchMatch(0);
      return;
    }

    // No overview row matched: look inside the article that is currently open and
    // jump to the first hit there. This used to only refresh the status line, so a
    // term that appears only in the opened article was highlighted nowhere.
    highlightCurrentlyOpenedArticle(articleSearchState.terms);

    if (articleSearchState.matches.length > 0) {
      focusArticleSearchMatch(0);
      return;
    }

    updateArticleSearchStatus();
  }

  function scheduleArticleSearch(query) {
    window.clearTimeout(articleSearchState.debounceTimer);
    articleSearchState.debounceTimer = window.setTimeout(() => applyArticleSearch(query), 180);
  }

  function addTicketArticleSearchStyles() {
    const css = `
      #zh-ticket-article-search { display: inline-flex; align-items: center; gap: 5px; margin-left: 18px; vertical-align: middle; }
      #zh-ticket-article-search input { width: 270px; max-width: 32vw; height: 26px; box-sizing: border-box; border: 1px solid #b8c0ca; border-radius: 4px; padding: 3px 8px; font-size: 12px; background: #fff; color: #111; }
      #zh-ticket-article-search button { height: 24px; min-width: 28px; border: 1px solid #aeb6c1; border-radius: 4px; background: #f7f8fa; color: #222; cursor: pointer; font-size: 12px; line-height: 1; }
      #zh-ticket-article-search button:hover { background: #fff; border-color: #77808c; }
      #zh-ticket-article-search .zh-ticket-search-status { min-width: 54px; color: #303842; font-size: 11px; white-space: nowrap; }
      mark.zh-ticket-search-hit { background: #fff176; color: #111; padding: 0 1px; border-radius: 2px; }
      mark.zh-ticket-search-active { background: #ff9900; outline: 2px solid #333; }
      tr.zh-ticket-search-row-hit > td { box-shadow: inset 0 0 0 9999px rgba(255, 241, 118, .42); }
      tr.zh-ticket-search-row-active > td { box-shadow: inset 0 0 0 9999px rgba(255, 153, 0, .28); outline: 2px solid #ff9900; outline-offset: -2px; }
      .zh-ticket-search-block-hit { box-shadow: inset 0 0 0 9999px rgba(255, 241, 118, .28); }
      .zh-ticket-search-block-active { outline: 2px solid #ff9900; outline-offset: 2px; }
    `;

    getAccessibleSearchDocuments().forEach((doc) => {
      addStyleToDocument(doc, "zh-ticket-article-search-style", css);
    });
  }

  function getTicketArticleSearchTarget() {
    return document.querySelector(".ActionRow") ||
      document.querySelector(".LayoutActionRow") ||
      document.querySelector(".TicketHeader") ||
      document.querySelector(".Headline") ||
      document.querySelector("h1")?.parentElement ||
      document.body;
  }

  function enableTicketArticleSearch() {
    if (!isTicketZoomPage()) return;

    addTicketArticleSearchStyles();

    if (document.getElementById("zh-ticket-article-search")) return;

    const container = document.createElement("div");
    container.id = "zh-ticket-article-search";

    const input = document.createElement("input");
    input.type = "search";
    input.placeholder = "Im Ticket suchen...";
    input.autocomplete = "off";

    const previousButton = document.createElement("button");
    previousButton.type = "button";
    previousButton.textContent = "<";
    previousButton.title = "Vorheriger Treffer";

    const nextButton = document.createElement("button");
    nextButton.type = "button";
    nextButton.textContent = ">";
    nextButton.title = "Naechster Treffer";

    const clearButton = document.createElement("button");
    clearButton.type = "button";
    clearButton.textContent = "x";
    clearButton.title = "Suche leeren";

    const status = document.createElement("span");
    status.className = "zh-ticket-search-status";
    status.textContent = "0 Treffer";

    [input, previousButton, nextButton, clearButton, status].forEach(blockTicketNavigation);

    input.addEventListener("input", () => scheduleArticleSearch(input.value));
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        stopEvent(event);
        focusArticleSearchMatch(articleSearchState.activeIndex + (event.shiftKey ? -1 : 1));
      }

      if (event.key === "Escape") {
        input.value = "";
        applyArticleSearch("");
      }
    });

    previousButton.addEventListener("click", (event) => {
      stopEvent(event);
      focusArticleSearchMatch(articleSearchState.activeIndex - 1);
    });

    nextButton.addEventListener("click", (event) => {
      stopEvent(event);
      focusArticleSearchMatch(articleSearchState.activeIndex + 1);
    });

    clearButton.addEventListener("click", (event) => {
      stopEvent(event);
      input.value = "";
      applyArticleSearch("");
      input.focus();
    });

    container.append(input, previousButton, nextButton, clearButton, status);
    getTicketArticleSearchTarget().appendChild(container);
  }

  function disableTicketArticleSearch() {
    window.clearTimeout(articleSearchState.debounceTimer);
    clearArticleSearchHighlights();
    document.getElementById("zh-ticket-article-search")?.remove();
    removeStyle("zh-ticket-article-search-style");
  }

  function copyTextToClipboard(text) {
    const value = String(text || "");
    if (!value) return Promise.resolve(false);

    if (navigator.clipboard?.writeText) {
      return navigator.clipboard.writeText(value)
        .then(() => true)
        .catch(() => copyTextFallback(value));
    }

    return Promise.resolve(copyTextFallback(value));
  }

  function copyTextFallback(text) {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.top = "-1000px";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();

    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch (error) {
      ok = false;
    }

    textarea.remove();
    return ok;
  }

  function addTicketNumberCopyStyles() {
    addStyle("zh-ticket-number-copy-style", `
      .zh-ticket-number-copy { cursor: pointer; border-radius: 4px; padding: 0 4px; margin: 0 -4px; transition: background-color .15s ease, color .15s ease; }
      .zh-ticket-number-copy:hover { background: rgba(57, 118, 187, .16); text-decoration: underline; }
      .zh-ticket-number-copy:focus-visible { outline: 2px solid #3976bb; outline-offset: 1px; }
      .zh-ticket-number-copy.zh-ticket-number-copied { background: #b7f0c0; color: #0a5d1e; text-decoration: none; }
    `);
  }

  function findTicketNumberTextNode(headline) {
    const walker = document.createTreeWalker(headline, NodeFilter.SHOW_TEXT);
    let node;

    while ((node = walker.nextNode())) {
      if (/\d{4,}/.test(node.nodeValue || "")) return node;
    }

    return null;
  }

  function enableTicketNumberCopy() {
    if (!isTicketZoomPage()) return;

    addTicketNumberCopyStyles();

    const headline = document.querySelector(".MainBox.TicketZoom .Headline h1") ||
      document.querySelector(".TicketZoom .Headline h1") ||
      document.querySelector(".Headline h1");
    if (!headline || headline.querySelector(".zh-ticket-number-copy")) return;

    const node = findTicketNumberTextNode(headline);
    if (!node) return;

    const match = node.nodeValue.match(/\d{4,}/);
    if (!match) return;

    const after = node.splitText(match.index);
    after.nodeValue = after.nodeValue.slice(match[0].length);

    const span = document.createElement("span");
    span.className = "zh-ticket-number-copy";
    span.textContent = match[0];
    span.title = "Case-/Ticketnummer kopieren";
    span.setAttribute("role", "button");
    span.tabIndex = 0;

    after.parentNode.insertBefore(span, after);

    const copy = () => {
      copyTextToClipboard(match[0]).then((ok) => {
        span.title = ok ? "Kopiert!" : "Kopieren nicht möglich";
        span.classList.add("zh-ticket-number-copied");
        window.setTimeout(() => {
          span.classList.remove("zh-ticket-number-copied");
          span.title = "Case-/Ticketnummer kopieren";
        }, 900);
      });
    };

    span.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      copy();
    });
    span.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      copy();
    });
  }

  function disableTicketNumberCopy() {
    document.querySelectorAll(".zh-ticket-number-copy").forEach((span) => {
      const parent = span.parentNode;
      if (!parent) return;
      parent.replaceChild(document.createTextNode(span.textContent), span);
      parent.normalize();
    });
    removeStyle("zh-ticket-number-copy-style");
  }

  function getMainText() {
    return normalizeText(document.body ? document.body.innerText || "" : "");
  }

  function extractCase() {
    const match = getMainText().match(/Case\s*([0-9]+)/i);
    return match ? match[1] : "";
  }

  function isRelevantEbCase() {
    return /installation|\u00fcbergabe|uebergabe|ubergabe/i.test(getMainText());
  }

  function splitHardwareEntries(text) {
    const rawLines = normalizeText(text).split("\n").filter(Boolean);
    const result = [];
    let index = 0;

    while (index < rawLines.length) {
      const line = rawLines[index];

      if (/^\d+\s*x\s+/i.test(line) || /^37[01]\d{4}\s*[-\u2013\u2014>]/.test(line)) {
        result.push(line);
        index += 1;
        continue;
      }

      if (/-->\s*37[01]\d{4}\s*$/.test(line)) {
        if (index > 0 && !/^\d+\s*x\s+/i.test(rawLines[index - 1]) && !/37[01]\d{4}/.test(rawLines[index - 1])) {
          result.push(`${rawLines[index - 1]}\n${line}`);
        } else {
          result.push(line);
        }
      }

      index += 1;
    }

    return result;
  }

  function normalizeAssignedInventoryLine(line) {
    const match = normalizeText(line).match(/^(.*?)\s*(?:-->|->|=>)\s*(37[01]\d{4})\s*$/);
    if (!match) return "";

    const description = match[1].trim();
    const inventoryNumber = match[2];

    return description ? `${description} ${inventoryNumber}` : inventoryNumber;
  }

  function splitInventoryMarkerEntries(text) {
    const lines = normalizeText(text).split("\n").filter(Boolean);
    const result = [];
    let markerSeen = false;
    let inventorySeen = false;

    for (const line of lines) {
      if (/Es wurden folgende Inventarmarken vergeben:/i.test(line)) {
        markerSeen = true;
        continue;
      }

      if (!markerSeen) continue;

      const assignedLine = normalizeAssignedInventoryLine(line);
      if (assignedLine) {
        result.push(assignedLine);
        inventorySeen = true;
        continue;
      }

      if (inventorySeen && /^\d+\s*x\s+/i.test(line)) {
        break;
      }
    }

    return result;
  }

  function isInventoryLine(line) {
    return /\b(?:inv\.?\s*(?:nr\.?|nummer)?|inventar(?:nr\.?|nummer)?|inventarmarke)\s*[:#-]?\s*37[01]\d{4}\b/i.test(line) ||
      /\b37[01]\d{4}\b/.test(line);
  }

  function extractInventoryNumber(line) {
    return line.match(/\b(37[01]\d{4})\b/)?.[1] || "";
  }

  function isSerialLine(line) {
    return /\b(?:s\/n|sn|serial|serien(?:nr\.?|nummer)?)\s*[:#-]?\s*\S+/i.test(line);
  }

  function normalizeSerialLine(line) {
    const serial = line.match(/\b(?:s\/n|sn|serial|serien(?:nr\.?|nummer)?)\s*[:#-]?\s*(.+)$/i)?.[1]?.trim();
    return serial || line;
  }

  function isHardwareDescriptionLine(line) {
    if (!line || isInventoryLine(line) || isSerialLine(line)) return false;
    if (/^(hallo|sehr geehrte|viele gr|im auftrag|mit freundlichen|danke|gru[sz])/i.test(line)) return false;
    if (/^\d{1,2}\.\d{1,2}\.\d{2,4}/.test(line)) return false;
    if (/^https?:\/\//i.test(line)) return false;
    if (/^(case|ticket|beschaffungsantrag)\b/i.test(line)) return false;

    return /[a-z]/i.test(line);
  }

  function splitHardwareEntriesFromInventoryBlocks(text) {
    const lines = normalizeText(text).split("\n").filter(Boolean);
    const result = [];
    let pendingDescription = "";
    let pendingSerial = "";

    lines.forEach((line) => {
      if (isSerialLine(line)) {
        pendingSerial = normalizeSerialLine(line);
        return;
      }

      if (isInventoryLine(line)) {
        const inventoryNumber = extractInventoryNumber(line);
        if (!inventoryNumber) return;

        const parts = [];
        if (pendingDescription) parts.push(pendingDescription);
        if (pendingSerial) parts.push(pendingSerial);
        parts.push(inventoryNumber);
        result.push(parts.join(" "));

        pendingDescription = "";
        pendingSerial = "";
        return;
      }

      if (isHardwareDescriptionLine(line)) {
        pendingDescription = line;
      }
    });

    return result;
  }

  function splitHardwareEntriesSmart(text) {
    const assignedInventoryEntries = splitInventoryMarkerEntries(text);
    if (assignedInventoryEntries.length > 0) return assignedInventoryEntries;

    return [
      ...splitHardwareEntries(text),
      ...splitHardwareEntriesFromInventoryBlocks(text)
    ];
  }

  function uniqueHardwareEntries(entries) {
    const byInventoryNumber = new Map();
    const withoutInventoryNumber = [];

    entries.map((entry) => normalizeAssignedInventoryLine(entry) || normalizeText(entry)).filter(Boolean).forEach((entry) => {
      const inventoryNumber = extractInventoryNumber(entry);

      if (!inventoryNumber) {
        withoutInventoryNumber.push(entry);
        return;
      }

      const current = byInventoryNumber.get(inventoryNumber);
      if (!current || entry.length > current.length) {
        byInventoryNumber.set(inventoryNumber, entry);
      }
    });

    return [...new Set([...byInventoryNumber.values(), ...withoutInventoryNumber])];
  }

  function extractFromMainDocument() {
    const text = getMainText();
    const markerMatch = text.match(/Es wurden folgende Inventarmarken vergeben:[\s\S]*/i);
    return splitHardwareEntriesSmart(markerMatch ? markerMatch[0] : text);
  }

  function extractFromIframes() {
    const frames = Array.from(document.querySelectorAll("iframe, frame"));
    const results = [];

    for (const frame of frames) {
      try {
        const doc = frame.contentDocument || frame.contentWindow?.document;
        const text = normalizeText(doc?.body?.innerText || "");
        if (!text) continue;

        const markerMatch = text.match(/Es wurden folgende Inventarmarken vergeben:[\s\S]*/i);
        results.push(...splitHardwareEntriesSmart(markerMatch ? markerMatch[0] : text));
      } catch (error) {
        // Cross-origin frames cannot be inspected.
      }
    }

    return results;
  }

  function extractSelectedHardwareLines() {
    const selected = window.getSelection ? String(window.getSelection()).trim() : "";
    return selected ? splitHardwareEntriesSmart(selected) : [];
  }

  function extractHardwareLines() {
    let entries = extractFromMainDocument();
    if (entries.length === 0) entries = extractFromIframes();
    if (entries.length === 0) entries = extractSelectedHardwareLines();

    return uniqueHardwareEntries(entries);
  }

  function buildEbUrl(caseValue, hardwareLines) {
    const params = new URLSearchParams();
    if (caseValue) params.set("case", caseValue);
    if (hardwareLines.length > 0) params.set("hardware_text", hardwareLines.join("\n"));
    return `${EB_BASE_URL}?${params.toString()}`;
  }

  function askForHardwareText() {
    const text = window.prompt("Hardwaretext einfügen, falls er nicht automatisch erkannt wurde:", "");
    return text ? uniqueHardwareEntries(splitHardwareEntriesSmart(text)) : [];
  }

  function enableEbHelper() {
    if (window.top !== window.self || !window.location.href.includes("Action=AgentTicketZoom")) return;
    if (!isRelevantEbCase() || document.getElementById("zh-eb-open-button")) return;

    const target =
      document.querySelector(".ActionRow") ||
      document.querySelector(".LayoutActionRow") ||
      document.querySelector(".TicketHeader") ||
      document.querySelector(".Headline") ||
      document.body;

    if (!target) return;

    const button = document.createElement("button");
    button.id = "zh-eb-open-button";
    button.type = "button";
    button.textContent = "Empfangsbestätigung erstellen";
    button.style.marginLeft = "12px";
    button.style.padding = "8px 14px";
    button.style.background = "#3976bb";
    button.style.color = "#fff";
    button.style.border = "0";
    button.style.borderRadius = "6px";
    button.style.cursor = "pointer";
    button.style.fontWeight = "600";

    button.addEventListener("click", () => {
      const caseValue = extractCase();
      let hardwareLines = extractHardwareLines();

      if (!caseValue) {
        alert("Keine Case-Nummer gefunden.");
        return;
      }

      if (hardwareLines.length === 0) {
        hardwareLines = askForHardwareText();
      }

      if (hardwareLines.length === 0) {
        alert("Keine Hardwarezeilen gefunden.");
        return;
      }

      // "noopener" so the external EB page cannot reach back into the ticket page.
      window.open(buildEbUrl(caseValue, hardwareLines), "_blank", "noopener");
    });

    target.prepend(button);
  }

  function disableEbHelper() {
    document.getElementById("zh-eb-open-button")?.remove();
  }

  function getPriorityTemplates() {
    priorityTemplateConfig = normalizePriorityTemplateConfig(priorityTemplateConfig);
    return priorityTemplateConfig.templates;
  }

  function isVisibleFormControl(control) {
    if (!control) return false;
    if (control.type === "hidden") return false;

    const view = control.ownerDocument?.defaultView || window;
    const style = view.getComputedStyle(control);
    if (style.display === "none" || style.visibility === "hidden") return false;

    const rect = control.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function cleanFieldLabel(text) {
    return normalizeText(text)
      .replace(/^\*+/, "")
      .replace(/:$/, "")
      .trim()
      .toLowerCase();
  }

  function findPriorityLabelCandidates(labels, doc = document) {
    const wanted = labels.map((label) => cleanFieldLabel(label));
    return [...doc.querySelectorAll("label, dt, th, td, div, span")]
      .filter((element) => {
        if (element.closest("#zh-priority-template-toolbar, .zh-priority-modal")) return false;
        const text = cleanFieldLabel(getElementText(element));
        return wanted.some((label) => text === label || text.endsWith(label));
      });
  }

  function getVisiblePriorityControls(doc = document) {
    return [...doc.querySelectorAll("input, select, textarea")]
      .filter((control) => !control.closest("#zh-priority-template-toolbar, .zh-priority-modal"))
      .filter(isVisibleFormControl);
  }

  function findPriorityControlNearLabel(labels, doc = document) {
    const candidates = findPriorityLabelCandidates(labels, doc);
    const controls = getVisiblePriorityControls(doc);

    for (const candidate of candidates) {
      const candidateRect = candidate.getBoundingClientRect();
      const sameRow = controls
        .filter((control) => Boolean(candidate.compareDocumentPosition(control) & Node.DOCUMENT_POSITION_FOLLOWING))
        .map((control) => ({
          control,
          rect: control.getBoundingClientRect()
        }))
        .filter((item) => Math.abs(item.rect.top - candidateRect.top) <= 28 || Math.abs(item.rect.bottom - candidateRect.bottom) <= 28)
        .filter((item) => item.rect.left >= candidateRect.left)
        .sort((left, right) => Math.abs(left.rect.left - candidateRect.right) - Math.abs(right.rect.left - candidateRect.right));

      if (sameRow[0]?.control) return sameRow[0].control;

      const row = candidate.closest("tr, li, .Row, .Field");
      const rowControl = [...(row?.querySelectorAll("input, select, textarea") || [])].find(isVisibleFormControl);
      if (rowControl) return rowControl;

      let sibling = candidate.nextElementSibling;
      while (sibling) {
        const siblingControl = sibling.matches?.("input, select, textarea") && isVisibleFormControl(sibling)
          ? sibling
          : [...sibling.querySelectorAll?.("input, select, textarea") || []].find(isVisibleFormControl);
        if (siblingControl) return siblingControl;
        sibling = sibling.nextElementSibling;
      }
    }

    return null;
  }

  function findPriorityFieldRow(labels, doc = document) {
    const candidates = findPriorityLabelCandidates(labels, doc);

    for (const candidate of candidates) {
      let element = candidate;
      let fallback = null;
      while (element && element !== doc.body) {
        if (element.querySelector?.("input, select, textarea, iframe, [contenteditable='true']")) {
          const controlCount = element.querySelectorAll("input, select, textarea").length;
          const labelCount = [...element.querySelectorAll("label, dt, th, td, div, span")]
            .filter((item) => /:?\s*$/.test(getElementText(item).trim()))
            .length;

          if (controlCount <= 4 && labelCount <= 8) {
            return element;
          }

          fallback ||= element;
        }

        const sibling = element.nextElementSibling;
        if (sibling?.querySelector?.("input, select, textarea, iframe, [contenteditable='true']")) {
          return element.parentElement || sibling;
        }

        if (fallback && element.matches?.("fieldset, .WidgetSimple")) {
          return fallback;
        }
        element = element.parentElement;
      }

      if (fallback) return fallback;
    }

    return null;
  }

  function findPriorityFieldSection(labels, doc = document) {
    const row = findPriorityFieldRow(labels, doc);
    if (!row) return null;

    const section = row.closest("fieldset, .WidgetSimple, .Field, .Row, tr, li");
    return section || row;
  }

  function findPriorityControl(labels, ids = [], doc = document) {
    for (const id of ids) {
      const direct = [
        doc.getElementById(id),
        doc.querySelector(`[name="${id}"]`),
        ...doc.querySelectorAll(`[id^="${id}_"], [id$="_${id}"], [name^="${id}_"], [name$="_${id}"]`)
      ].find((control) => control && isVisibleFormControl(control));
      if (direct) return direct;
    }

    const nearLabel = findPriorityControlNearLabel(labels, doc);
    if (nearLabel) return nearLabel;

    const row = findPriorityFieldRow(labels, doc);
    if (!row) return null;

    return [...row.querySelectorAll("input, select, textarea")]
      .find(isVisibleFormControl) || null;
  }

  function getControlText(control) {
    return normalizeText(control?.value || control?.textContent || "");
  }

  function matchesAutocompleteText(text, value) {
    const cleanText = normalizeText(text).toLowerCase();
    const expected = String(value || "").trim().toLowerCase();
    if (!expected) return false;
    if (cleanText === expected || cleanText.includes(expected)) return true;

    const tokens = expected.split(/\s+/).filter((token) => token.length > 1);
    return tokens.length > 0 && tokens.every((token) => cleanText.includes(token));
  }

  function findAutocompleteSuggestion(value) {
    const expected = String(value || "").trim().toLowerCase();
    if (!expected) return null;

    const selectors = [
      ".ui-autocomplete li",
      ".ui-menu-item",
      ".select2-results li",
      ".select2-results__option",
      "[role='option']",
      ".autocomplete-suggestion",
      ".AutoCompleteResult"
    ];

    const candidates = [...document.querySelectorAll(selectors.join(","))]
      .filter(elementIsVisible)
      .filter((element) => !element.closest("#zh-priority-template-toolbar, .zh-priority-modal"));

    return candidates.find((element) => normalizeText(getElementText(element)).toLowerCase() === expected) ||
      candidates.find((element) => matchesAutocompleteText(getElementText(element), value)) ||
      null;
  }

  function clickAutocompleteSuggestion(value) {
    const suggestion = findAutocompleteSuggestion(value);
    if (!suggestion) return false;

    const target = suggestion.querySelector("a, button, div, span") || suggestion;
    ["mousedown", "mouseup", "click"].forEach((eventName) => {
      target.dispatchEvent(new MouseEvent(eventName, { bubbles: true, cancelable: true, view: window }));
    });
    if (typeof target.click === "function") target.click();

    return true;
  }

  function dispatchControlEvents(control, includeBlur = true) {
    const events = includeBlur ? ["input", "change", "keyup", "blur"] : ["input", "change", "keyup"];
    events.forEach((eventName) => {
      control.dispatchEvent(new Event(eventName, { bubbles: true }));
    });
  }

  function setControlValue(control, value, options = {}) {
    if (!control || !value) return false;

    if (control.tagName === "SELECT") {
      const option = [...control.options].find((item) =>
        normalizeText(item.textContent).toLowerCase() === String(value).toLowerCase() ||
        String(item.value).toLowerCase() === String(value).toLowerCase()
      );
      if (option) {
        control.value = option.value;
        option.selected = true;
      } else {
        control.value = value;
      }
    } else {
      if (options.focus !== false) control.focus({ preventScroll: true });
      control.value = value;
    }

    dispatchControlEvents(control, options.blur !== false);

    return true;
  }

  function clickPriorityTokenRemovers(row) {
    if (!row) return;

    const controls = [...row.querySelectorAll("a, button, span, div")]
      .filter((element) => !element.closest("#zh-priority-template-toolbar, .zh-priority-modal"))
      .filter(elementIsVisible)
      .filter((element) => {
        const text = normalizeText(getElementText(element)).toLowerCase();
        const title = String(element.getAttribute("title") || element.getAttribute("aria-label") || "").toLowerCase();
        const className = String(element.className || "").toLowerCase();
        return text === "x" ||
          title.includes("entfernen") ||
          title.includes("remove") ||
          className.includes("remove") ||
          className.includes("close") ||
          className.includes("delete");
      });

    controls.slice(0, 3).forEach((element) => {
      ["mousedown", "mouseup", "click"].forEach((eventName) => {
        element.dispatchEvent(new MouseEvent(eventName, { bubbles: true, cancelable: true, view: window }));
      });
      if (typeof element.click === "function") element.click();
    });
  }

  function findPriorityTokenContainer(control) {
    if (!control) return null;

    let element = control.parentElement;
    let fallback = control.parentElement;
    while (element && element !== document.body) {
      const controlCount = element.querySelectorAll("input, select, textarea").length;
      const text = normalizeText(getElementText(element));
      if (controlCount <= 3 && text.length <= 180) {
        return element;
      }

      fallback ||= element;
      if (element.matches("tr, li, .Row, .Field")) return element;
      element = element.parentElement;
    }

    return fallback;
  }

  function priorityRowHasValue(row, value) {
    return row ? matchesAutocompleteText(getElementText(row), value) : false;
  }

  function getAutocompleteQueries(value) {
    const clean = String(value || "").trim();
    const parts = clean.split(/\s+/).filter(Boolean);
    const queries = [clean];

    if (parts.length >= 2) {
      const first = parts[0];
      const last = parts.slice(1).join(" ");
      queries.push(`${last}, ${first}`, last);
    }

    return [...new Set(queries.filter(Boolean))];
  }

  function setPriorityAutocompleteField(labels, ids, value, doc = document) {
    if (!value) return false;

    const control = findPriorityControl(labels, ids, doc);
    if (!control) return false;

    const changed = setControlValue(control, value, { blur: true });
    control.dispatchEvent(new KeyboardEvent("keydown", {
      bubbles: true,
      cancelable: true,
      key: "Escape",
      view: window
    }));
    control.blur?.();
    closePriorityAutocompleteDropdowns(doc);

    return changed;
  }

  function setPriorityField(ids, value, labels = [], doc = document) {
    if (!value) return false;

    const select = findPrioritySelectControl(ids, labels, doc);
    if (select) {
      if (applySelectTemplateValue(select, value, doc)) return true;

      // A select was found but the configured value matches none of its
      // options. Do not fall through to the input path (that would clear the
      // select) - log the available options so the template can be corrected.
      console.warn(
        "Znuny Helper: Wert", JSON.stringify(value), "nicht in Feld",
        select.id || select.name || "(select)", "- Optionen:",
        [...(select.options || [])].map((option) => getSelectOptionText(option))
      );
      return false;
    }

    // Fallback for setups that render the field as an autocomplete/plain input.
    if (setPriorityAutocompleteField(labels.length ? labels : [].concat(ids), ids, value, doc)) return true;

    console.warn("Znuny Helper: Vorlagenfeld nicht gefunden:", [].concat(ids).join(", "));
    return false;
  }

  function setPriorityPlainField(labels, ids, value, doc = document) {
    if (!value) return false;

    const control = findPriorityControl(labels, ids, doc);
    if (!control) return false;

    return setControlValue(control, value, { blur: true, focus: false });
  }

  function closePriorityAutocompleteDropdowns(doc = document) {
    doc.activeElement?.blur?.();

    doc.querySelectorAll(".ui-autocomplete, .select2-drop, .select2-dropdown, .autocomplete-suggestions, .AutoCompleteResult")
      .forEach((element) => {
        element.style.display = "none";
      });
  }

  function getSelectOptionText(option) {
    return normalizeText(option?.textContent || "").replace(/\u00a0/g, " ").trim();
  }

  function findSelectOptionByTemplateValue(select, value) {
    if (!select || !value) return null;

    const expected = normalizeText(value).toLowerCase();
    const options = [...select.options];

    return options.find((option) => getSelectOptionText(option).toLowerCase() === expected) ||
      options.find((option) => String(option.value || "").toLowerCase() === expected) ||
      options.find((option) => getSelectOptionText(option).toLowerCase().replace(/^\d+\s*:\s*/, "") === expected) ||
      options.find((option) => matchesAutocompleteText(getSelectOptionText(option), value)) ||
      null;
  }

  function updateModernizedSelectDisplay(select, label) {
    const doc = select.ownerDocument || document;
    const field = select.closest(".Field") || select.parentElement;
    const searchInput = doc.getElementById(`${select.id}_Search`) ||
      field?.querySelector(".InputField_Search");
    const inputContainer = searchInput?.closest(".InputField_InputContainer") ||
      field?.querySelector(".InputField_InputContainer");

    if (searchInput) {
      searchInput.value = "";
      searchInput.setAttribute("title", label);
      searchInput.blur?.();
    }

    let selection = inputContainer?.querySelector(".InputField_Selection");
    if (!selection && inputContainer) {
      selection = doc.createElement("div");
      selection.className = "InputField_Selection";
      selection.style.left = "5px";
      selection.style.display = "block";

      const text = doc.createElement("div");
      text.className = "Text";
      selection.appendChild(text);

      inputContainer.appendChild(selection);
    }

    const textElement = selection?.querySelector(".Text");
    if (textElement) textElement.textContent = label;

    selection?.querySelector(".Remove")?.remove();
    if (selection) selection.style.display = "block";
  }

  function isModernizedSelectWidgetVisible(select) {
    const doc = select.ownerDocument || document;
    const field = select.closest(".Field") || select.parentElement;
    const searchInput = doc.getElementById(`${select.id}_Search`) ||
      field?.querySelector(".InputField_Search");
    const inputContainer = searchInput?.closest(".InputField_InputContainer") ||
      field?.querySelector(".InputField_InputContainer");
    return Boolean(inputContainer && isVisibleFormControl(inputContainer));
  }

  function applySelectTemplateValue(select, value, doc = document) {
    const option = findSelectOptionByTemplateValue(select, value);
    if (!option) return false;

    const changed = select.value !== option.value || !option.selected;
    [...select.options].forEach((item) => {
      item.selected = item === option;
    });
    select.value = option.value;

    updateModernizedSelectDisplay(select, getSelectOptionText(option));
    if (changed) {
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
    }
    return true;
  }

  function setPrioritySelectField(ids, value, labels = [], doc = document) {
    const select = findPrioritySelectControl(ids, labels, doc);
    if (!select) return false;
    return applySelectTemplateValue(select, value, doc);
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function fragmentFromLines(text, doc = document) {
    const fragment = doc.createDocumentFragment();
    String(text || "")
      .split("\n")
      .forEach((line, index) => {
        if (index > 0) fragment.appendChild(doc.createElement("br"));
        fragment.appendChild(doc.createTextNode(line));
      });
    return fragment;
  }

  function insertRichTextInto(target, value, prepend) {
    const doc = target.ownerDocument || document;
    if (prepend) {
      const fragment = fragmentFromLines(value, doc);
      fragment.appendChild(doc.createElement("br"));
      target.insertBefore(fragment, target.firstChild);
    } else {
      // Same shape as a restored draft: real paragraphs keep the line structure, which
      // some editors otherwise squeeze together.
      insertPlainTextAsParagraphs(target, value);
      return;
    }
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function setPriorityRichText(value, options = {}, doc = document) {
    if (!value) return false;

    const prepend = Boolean(options.prepend);
    const row = findPriorityFieldSection(["Text"], doc);
    const textarea = [...(row?.querySelectorAll("textarea") || [])]
      .find((control) => {
        const signature = `${control.name || ""} ${control.id || ""}`.toLowerCase();
        return /richtext|body|article|text/.test(signature);
      });
    if (textarea) {
      setControlValue(textarea, prepend ? `${value}\n${textarea.value || ""}` : value, { focus: false });
    }

    const editable =
      row?.querySelector?.("[contenteditable='true']") ||
      doc.querySelector(".cke_editable[contenteditable='true'], [contenteditable='true']");

    if (editable) {
      insertRichTextInto(editable, value, prepend);
      return true;
    }

    const iframe = row?.querySelector?.("iframe") || doc.querySelector(".cke_wysiwyg_frame, iframe");
    try {
      const iframeDoc = iframe?.contentDocument || iframe?.contentWindow?.document;
      if (iframeDoc?.body) {
        insertRichTextInto(iframeDoc.body, value, prepend);
        return true;
      }
    } catch (error) {
      // Ignore cross-document editor access errors.
    }

    return Boolean(textarea);
  }

  function applyPriorityTemplate(template, doc = document) {
    const fields = template.fields || {};
    const view = doc.defaultView || window;
    const startScrollX = view.scrollX;
    const startScrollY = view.scrollY;
    let userScrolled = false;

    const markUserScroll = () => {
      userScrolled = true;
    };
    const userScrollEvents = ["wheel", "touchmove", "keydown", "mousedown"];
    userScrollEvents.forEach((type) => view.addEventListener(type, markUserScroll, { passive: true }));

    const applyFields = () => {
      setPrioritySelectField(["TypeID"], fields.type, [], doc);
      setPrioritySelectField(["NewQueueID", "Dest"], fields.queue, ["An Queue", "Queue"], doc);
      setPrioritySelectField(["ServiceID"], fields.service, [], doc);
      setPrioritySelectField(["NewOwnerID", "NewUserID", "OwnerID"], fields.owner, ["Besitzer", "Owner"], doc);
      // Impact before priority: some Znuny setups derive the priority from the
      // impact/service, so the explicitly configured priority should win.
      setPriorityField(["ImpactID", "DynamicField_Auswirkung", "DynamicField_Impact"], fields.impact, ["Auswirkung", "Impact"], doc);
      setPriorityField(["PriorityID", "DynamicField_Priorität", "DynamicField_Prioritaet"], fields.priority, ["Priorität", "Priority"], doc);
      setPrioritySelectField(["DynamicField_Kategorie"], fields.category, [], doc);
      setPriorityPlainField(["Betreff"], ["Subject"], fields.subject, doc);
      setPriorityRichText(fields.body, {}, doc);
      closePriorityAutocompleteDropdowns(doc);
    };

    const applyAndKeepPosition = () => {
      applyFields();
      // Znuny re-renders dependent fields after a select change and can scroll
      // the page (to top or bottom). Restore the previous position unless the
      // user scrolled on purpose in the meantime.
      if (!userScrolled && Math.abs(view.scrollY - startScrollY) > 30) {
        view.scrollTo({ top: startScrollY, left: startScrollX });
      }
    };

    // Repeat a few times: after a select change Znuny may re-render the form and
    // wipe the free-text fields, which is why a template sometimes only applied
    // fully on the second click.
    applyAndKeepPosition();
    [150, 350, 700, 1200].forEach((delay) => view.setTimeout(applyAndKeepPosition, delay));
    view.setTimeout(() => {
      userScrollEvents.forEach((type) => view.removeEventListener(type, markUserScroll));
    }, 1300);
  }

  function isSelectControl(control) {
    return Boolean(control && control.tagName === "SELECT");
  }

  function isVisibleSelect(candidate) {
    return isSelectControl(candidate) &&
      (isVisibleFormControl(candidate) || isModernizedSelectWidgetVisible(candidate));
  }

  function findSelectByLabel(labels, doc = document) {
    const wanted = labels.map((label) => cleanFieldLabel(label)).filter(Boolean);
    if (!wanted.length) return null;

    for (const labelElement of doc.querySelectorAll("label, dt, th, .ControlLabel")) {
      const text = cleanFieldLabel(getElementText(labelElement));
      if (!wanted.some((label) => text === label || text.endsWith(label))) continue;

      const forId = labelElement.getAttribute("for");
      const direct = [
        forId ? doc.getElementById(forId) : null,
        ...labelElement.querySelectorAll("select")
      ].find(isVisibleSelect);
      if (direct) return direct;

      // Znuny often wraps the label and the control in a .Field/row container
      // without a matching "for" attribute; search that container.
      const container = labelElement.closest(".Field") ||
        labelElement.closest("tr, li, .Row, .WidgetSimple") ||
        labelElement.parentElement;
      const selects = [...(container?.querySelectorAll("select") || [])];
      const inContainer = selects.find(isVisibleSelect);
      if (inContainer) return inContainer;

      // The field may be a hidden select driven by JavaScript (no modernized
      // InputField wrapper) - the label match is authoritative here.
      const usable = selects.find((candidate) =>
        isSelectControl(candidate) &&
        !candidate.disabled &&
        !/search/i.test(`${candidate.id} ${candidate.name}`)
      );
      if (usable) return usable;
    }

    return null;
  }

  function findPrioritySelectControl(ids, labels = [], doc = document) {
    for (const id of [].concat(ids)) {
      // Exact id/name match is authoritative even if the select is hidden -
      // the value still has to be set on it.
      const exact = [
        doc.getElementById(id),
        doc.querySelector(`[name="${id}"]`)
      ].find((candidate) => isSelectControl(candidate) && !candidate.disabled);
      if (exact) return exact;

      const fuzzy = [...doc.querySelectorAll(`[id^="${id}_"], [id$="_${id}"], [name^="${id}_"], [name$="_${id}"]`)]
        .find(isVisibleSelect);
      if (fuzzy) return fuzzy;
    }

    if (labels.length) {
      const byLabel = findSelectByLabel(labels, doc);
      if (byLabel) return byLabel;

      const row = findPriorityFieldRow(labels, doc);
      const select = row?.querySelector("select");
      if (select && (isVisibleFormControl(select) || isModernizedSelectWidgetVisible(select))) return select;
    }

    return null;
  }

  function getPrioritySelectFieldText(ids, labels = [], doc = document) {
    const select = findPrioritySelectControl(ids, labels, doc);
    if (select) return getSelectOptionText(select.selectedOptions?.[0]);

    // Some setups render the field as a plain/autocomplete input instead of a
    // select; read its value as a fallback.
    const control = findPriorityControl(labels, ids, doc);
    return control ? String(control.value || "").trim() : "";
  }

  function getPriorityPlainFieldValue(labels, ids, doc = document) {
    const control = findPriorityControl(labels, ids, doc);
    return control ? String(control.value || "").trim() : "";
  }

  function getPriorityRichTextValue(doc = document) {
    const row = findPriorityFieldSection(["Text"], doc);

    const textarea = [...(row?.querySelectorAll("textarea") || [])]
      .find((control) => {
        const signature = `${control.name || ""} ${control.id || ""}`.toLowerCase();
        return /richtext|body|article|text/.test(signature);
      });
    if (textarea?.value) return textarea.value;

    const editable = row?.querySelector?.("[contenteditable='true']") ||
      doc.querySelector(".cke_editable[contenteditable='true'], [contenteditable='true']");
    if (editable) return editable.innerText || "";

    const iframe = row?.querySelector?.("iframe") || doc.querySelector(".cke_wysiwyg_frame, iframe");
    try {
      const iframeDoc = iframe?.contentDocument || iframe?.contentWindow?.document;
      if (iframeDoc?.body) return iframeDoc.body.innerText || "";
    } catch (error) {
      // Ignore cross-document editor access errors.
    }

    return "";
  }

  function capturePriorityTemplateFields(doc = document) {
    return {
      type: getPrioritySelectFieldText(["TypeID"], [], doc),
      queue: getPrioritySelectFieldText(["NewQueueID", "Dest"], ["An Queue", "Queue"], doc),
      service: getPrioritySelectFieldText(["ServiceID"], [], doc),
      owner: getPrioritySelectFieldText(["NewOwnerID", "NewUserID", "OwnerID"], ["Besitzer", "Owner"], doc),
      priority: getPrioritySelectFieldText(["PriorityID", "DynamicField_Priorität", "DynamicField_Prioritaet"], ["Priorität", "Priority"], doc),
      impact: getPrioritySelectFieldText(["ImpactID", "DynamicField_Auswirkung", "DynamicField_Impact"], ["Auswirkung", "Impact"], doc),
      category: getPrioritySelectFieldText(["DynamicField_Kategorie"], [], doc),
      subject: getPriorityPlainFieldValue(["Betreff"], ["Subject"], doc),
      body: getPriorityRichTextValue(doc)
    };
  }

  function saveCurrentFieldsAsPriorityTemplate(doc = document) {
    const title = window.prompt("Name für die neue Vorlage:", "");
    if (!title || !title.trim()) return;

    const fields = capturePriorityTemplateFields(doc);
    const hasAnyValue = Object.values(fields).some((value) => value);
    if (!hasAnyValue) {
      window.alert("Es wurden keine ausgefüllten Felder gefunden, die als Vorlage gespeichert werden können.");
      return;
    }

    const palette = ["#3976bb", "#4caf50", "#e07b00", "#8e44ad", "#c0392b", "#009688"];
    const usedColors = getPriorityTemplates().map((template) => template.color);
    const color = palette.find((candidate) => !usedColors.includes(candidate)) || palette[0];

    priorityTemplateConfig = normalizePriorityTemplateConfig({
      templates: [
        ...getPriorityTemplates(),
        { title: title.trim(), color, fields }
      ]
    });
    savePriorityTemplateConfig();
    enablePriorityTemplates(doc);
  }

  function isAllowedHsrwCustomerEmail(email) {
    const domain = String(email || "").toLowerCase().split("@").pop() || "";
    return ["hsrw.org", "hsrw.eu", "hochschule-rhein-waal.de"]
      .some((allowed) => domain === allowed || domain.endsWith(`.${allowed}`));
  }

  function extractEmails(value) {
    return String(value || "").match(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/gi) || [];
  }

  function getPriorityExternalCustomerEmail() {
    const preferredText = [];

    [...document.querySelectorAll("input, textarea, select")].forEach((control) => {
      if (control.closest("#zh-priority-template-toolbar, .zh-priority-modal")) return;

      const signature = [
        control.name,
        control.id,
        control.getAttribute("aria-label"),
        control.getAttribute("placeholder"),
        getElementText(control.closest("tr, li, .Field, .Row") || control.parentElement)
      ].join(" ").toLowerCase();

      if (!/customer|kunde|kundenbenutzer|mail|e-mail|email|von|from/.test(signature)) return;

      preferredText.push(control.value || "");
      if (control.tagName === "SELECT") {
        preferredText.push(control.selectedOptions?.[0]?.textContent || "");
      }
    });

    const preferredEmails = preferredText.flatMap(extractEmails);
    const fallbackEmails = extractEmails(document.body?.innerText || "");
    const emails = [...new Set([...preferredEmails, ...fallbackEmails].map((email) => email.toLowerCase()))];

    return emails.find((email) => !isAllowedHsrwCustomerEmail(email)) || "";
  }

  function schedulePriorityExternalCustomerBottomNotice() {
    appendPriorityExternalCustomerBottomNotice();
    [200, 700, 1500].forEach((delay) => {
      window.setTimeout(appendPriorityExternalCustomerBottomNotice, delay);
    });
  }

  function hasPriorityExternalCustomerMarker() {
    const titleText = normalizeText(`${document.querySelector("h1")?.textContent || ""} ${document.title || ""}`);
    const pageText = normalizeText(document.body?.innerText || "");

    return /\[!?extern\]/i.test(titleText) ||
      /\b!?extern\b/i.test(titleText) ||
      /\[!?extern\]/i.test(pageText);
  }

  function getPriorityExternalCustomerWarningText(shortText = false) {
    const externalEmail = getPriorityExternalCustomerEmail();
    if (externalEmail) {
      return shortText
        ? "ACHTUNG: Kunde ist extern"
        : `Kunde scheint extern zu sein (${externalEmail}). Bitte vor dem Übermitteln prüfen, ob die Ticketdaten entsprechend angepasst werden müssen.`;
    }

    if (hasPriorityExternalCustomerMarker()) {
      return shortText
        ? "ACHTUNG: Kunde ist extern"
        : "Ticket ist als EXTERN markiert. Bitte vor dem Übermitteln prüfen, ob die Ticketdaten entsprechend angepasst werden müssen.";
    }

    return "";
  }

  function appendPriorityExternalCustomerNotice(toolbar) {
    const warningText = getPriorityExternalCustomerWarningText(false);
    if (!warningText) return;

    const notice = document.createElement("div");
    notice.id = "zh-priority-external-customer-warning";
    const strong = document.createElement("strong");
    strong.textContent = "EXTERN:";
    notice.appendChild(strong);
    notice.appendChild(document.createTextNode(` ${warningText}`));
    toolbar.appendChild(notice);
  }

  function findPriorityCustomerVisibleTarget() {
    const candidates = [...document.querySelectorAll("label, div, span, p, td, th, strong")]
      .filter((element) => !element.closest("#zh-priority-template-toolbar, .zh-priority-modal"))
      .filter((element) => {
        const text = normalizeText(getElementText(element))
          .toLowerCase()
          .replace(/\u00fc/g, "ue")
          .replace(/\u00dc/g, "ue")
          .replace(/Ã¼/g, "ue")
          .replace(/Ãœ/g, "ue");
        return /ist\s+sichtbar\s+f(?:ue|uer)\s+kunde/.test(text);
      })
      .sort((left, right) => normalizeText(getElementText(left)).length - normalizeText(getElementText(right)).length);

    const label = candidates.find(elementIsVisible) || candidates[0];
    if (!label) return null;

    return label.closest("tr, li, .Field, .Row") || label.parentElement;
  }

  function appendPriorityExternalCustomerBottomNotice() {
    const warningText = getPriorityExternalCustomerWarningText(true);
    const existing = document.getElementById("zh-priority-external-customer-bottom-warning");
    if (!warningText) {
      existing?.remove();
      return;
    }

    const target = findPriorityCustomerVisibleTarget();
    if (!target) return;

    const notice = existing || document.createElement("div");
    notice.id = "zh-priority-external-customer-bottom-warning";
    notice.textContent = warningText;

    const checkbox = target.querySelector('input[type="checkbox"]') ||
      target.parentElement?.querySelector('input[type="checkbox"]');

    if (checkbox) checkbox.insertAdjacentElement("afterend", notice);
    else target.appendChild(notice);
  }

  function addPriorityTemplateStyles(doc = document) {
    addStyleToDocument(doc, "zh-priority-template-style", `
      #zh-priority-template-toolbar { color-scheme: light; margin: 12px 26px; border: 1px solid #e2e4e8; border-radius: 8px; background: #fff; overflow: hidden; font-size: 12.5px; color: #2b2f36; }
      #zh-priority-template-toolbar.zh-priority-template-side { margin: 0; }
      .zh-priority-side-layout { display: grid !important; grid-template-columns: minmax(0, 1fr) minmax(220px, 300px); column-gap: 16px; align-items: start; }
      .zh-priority-side-layout > #zh-priority-template-toolbar { grid-column: 2; grid-row: 1; }
      .zh-priority-side-layout > :not(#zh-priority-template-toolbar) { grid-column: 1; min-width: 0; max-width: 100%; box-sizing: border-box; overflow-x: clip; }
      .zh-priority-side-layout fieldset,
      .zh-priority-side-layout .Row,
      .zh-priority-side-layout .Field,
      .zh-priority-side-layout .InputField,
      .zh-priority-side-layout .InputField_Container,
      .zh-priority-side-layout .InputField_InputContainer,
      .zh-priority-side-layout .InputField_Search,
      .zh-priority-side-layout table { max-width: 100%; box-sizing: border-box; }
      @supports not (overflow-x: clip) {
        .zh-priority-side-layout > :not(#zh-priority-template-toolbar) { overflow-x: hidden; }
      }
      .zh-priority-toolbar-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 8px 12px; background: #f4f5f7; border-bottom: 1px solid #e2e4e8; }
      .zh-priority-toolbar-head strong { font-size: 12.5px; letter-spacing: .02em; color: #2b2f36; }
      .zh-priority-toolbar-edit { border: 1px solid #c9ccd2; background: #fff; color: #3a3f47; border-radius: 5px; padding: 3px 9px; font-size: 11.5px; cursor: pointer; }
      .zh-priority-toolbar-edit:hover { background: #eef0f3; }
      .zh-priority-toolbar-groups { display: grid; gap: 12px; padding: 11px 12px; }
      .zh-priority-toolbar-group { display: grid; gap: 6px; }
      .zh-priority-toolbar-group-label { font-size: 10.5px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; color: #8a909a; }
      .zh-priority-toolbar-group-buttons { display: flex; flex-wrap: wrap; gap: 6px; }
      .zh-priority-toolbar-actions { display: flex; justify-content: flex-end; padding: 9px 12px; border-top: 1px solid #e2e4e8; background: #fafbfc; }
      .zh-priority-template-button { border: 1px solid rgba(0,0,0,.16); border-radius: 6px; padding: 5px 11px; cursor: pointer; font-weight: 600; line-height: 1.3; font-size: 12px; color: #fff; transition: filter .1s ease; }
      .zh-priority-template-button:hover { filter: brightness(1.08); }
      .zh-priority-template-save-current { border: 1px solid #3976bb; background: #fff; color: #2a5c96; border-radius: 6px; padding: 5px 12px; cursor: pointer; font-weight: 600; font-size: 12px; }
      .zh-priority-template-save-current:hover { background: #eaf1fb; }
      #zh-priority-external-customer-warning { width: 100%; box-sizing: border-box; margin-top: 4px; padding: 7px 9px; border: 1px solid #d98200; border-left: 4px solid #ff9900; background: #fff4cf; color: #4b3400; font-size: 12px; line-height: 1.35; }
      #zh-priority-external-customer-warning strong { color: #8a3b00; margin: 0; width: auto; }
      #zh-priority-external-customer-bottom-warning { display: inline-block; margin: 0 0 0 12px; padding: 5px 9px; border: 1px solid #c30000; border-left: 5px solid #d40000; background: #ffe0e0; color: #8a0000; font-size: 12px; font-weight: 700; line-height: 1.3; vertical-align: middle; }
      .zh-priority-modal-backdrop { color-scheme: light; position: fixed; inset: 0; z-index: 100000; display: flex; align-items: center; justify-content: center; padding: 20px; background: rgba(17,20,26,.55); }
      .zh-priority-modal { color-scheme: light; width: min(1040px, 100%); max-height: 100%; display: flex; flex-direction: column; overflow: hidden; background: #fff; color: #222; border-radius: 10px; box-shadow: 0 18px 50px rgba(0,0,0,.35); }
      .zh-priority-modal header, .zh-priority-modal footer { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 13px 18px; background: #f4f5f7; flex: 0 0 auto; }
      .zh-priority-modal header { border-radius: 10px 10px 0 0; border-bottom: 1px solid #e2e4e8; }
      .zh-priority-modal footer { border-top: 1px solid #e2e4e8; border-radius: 0 0 10px 10px; flex-wrap: wrap; }
      .zh-priority-modal h2 { margin: 0; font-size: 16px; color: #222; }
      .zh-priority-modal-body { flex: 1 1 auto; overflow: auto; background: #f6f7f9; }
      .zh-priority-modal-tools { display: flex; align-items: center; gap: 10px; padding: 11px 18px; background: #fff; border-bottom: 1px solid #e7e9ed; position: sticky; top: 0; z-index: 2; }
      .zh-priority-modal-tools input[type="search"] { flex: 1 1 auto; min-width: 0; padding: 7px 10px; border: 1px solid #cbd0d6; border-radius: 7px; font-size: 12.5px; }
      .zh-priority-modal-tools input[type="search"]:focus { outline: none; border-color: #3976bb; box-shadow: 0 0 0 2px rgba(57,118,187,.15); }
      .zh-priority-modal-tools .zh-priority-add { flex: 0 0 auto; border: 1px solid #3976bb; background: #fff; color: #2a5c96; border-radius: 7px; padding: 7px 12px; font-size: 12.5px; font-weight: 600; cursor: pointer; }
      .zh-priority-modal-tools .zh-priority-add:hover { background: #eaf1fb; }
      .zh-priority-groups { padding: 14px 18px 18px; display: grid; gap: 16px; }
      .zh-priority-group-section { display: grid; gap: 8px; }
      .zh-priority-group-title { display: flex; align-items: center; gap: 8px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .06em; color: #8a909a; }
      .zh-priority-group-title[draggable="true"] { cursor: grab; }
      .zh-priority-group-title[draggable="true"]:active { cursor: grabbing; }
      .zh-priority-group-handle { color: #b3b8c0; font-size: 13px; }
      .zh-priority-group-count { background: #e7e9ed; color: #5a6069; border-radius: 999px; padding: 1px 7px; font-size: 10.5px; letter-spacing: 0; }
      .zh-priority-tiles { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 10px; align-items: start; }
      .zh-priority-tile { border: 1px solid #e3e5e9; border-left-width: 4px; border-left-style: solid; border-left-color: #3976bb; border-radius: 9px; background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,.04); overflow: hidden; }
      .zh-priority-tile-head { display: flex; align-items: center; gap: 8px; padding: 9px 10px 5px; }
      .zh-priority-tile-drag { flex: 0 0 auto; cursor: grab; color: #b3b8c0; font-size: 14px; line-height: 1; user-select: none; }
      .zh-priority-tile-drag:active { cursor: grabbing; }
      .zh-priority-tile.zh-priority-dragging { opacity: .45; }
      .zh-priority-tile.zh-priority-drop-target { outline: 2px dashed #3976bb; outline-offset: -2px; }
      .zh-priority-tile-color { flex: 0 0 auto; width: 26px; height: 26px; padding: 1px; border: 1px solid #d4d8de; border-radius: 6px; background: #fff; cursor: pointer; }
      .zh-priority-tile-main { flex: 1 1 auto; min-width: 0; }
      .zh-priority-tile-title { font-weight: 600; }
      .zh-priority-tile-main input, .zh-priority-tile-meta input, .zh-priority-tile-meta select { width: 100%; box-sizing: border-box; border: 1px solid transparent; background: transparent; border-radius: 5px; padding: 3px 5px; font-size: 12.5px; color: #222; }
      .zh-priority-tile-main input:hover, .zh-priority-tile-meta input:hover, .zh-priority-tile-meta select:hover { border-color: #dfe2e7; }
      .zh-priority-tile-main input:focus, .zh-priority-tile-meta input:focus, .zh-priority-tile-meta select:focus { outline: none; border-color: #3976bb; background: #fff; box-shadow: 0 0 0 2px rgba(57,118,187,.14); }
      .zh-priority-tile-meta { display: flex; align-items: center; gap: 6px; padding: 0 10px 9px; }
      .zh-priority-tile-group { flex: 1 1 auto; min-width: 0; font-size: 11.5px; color: #7a808a; cursor: pointer; }
      .zh-priority-tile-actions { flex: 0 0 auto; display: flex; align-items: center; gap: 3px; }
      .zh-priority-tile-actions button { border: 1px solid #d4d8de; background: #fff; color: #4a5058; border-radius: 6px; width: 26px; height: 26px; padding: 0; font-size: 12px; line-height: 1; cursor: pointer; }
      .zh-priority-tile-actions button:hover { background: #eef0f3; }
      .zh-priority-tile-actions .zh-priority-tile-toggle { width: auto; padding: 0 8px; font-size: 11px; }
      .zh-priority-tile-actions .zh-priority-tile-remove { color: #a30000; border-color: #e6bcbc; }
      .zh-priority-tile-actions .zh-priority-tile-remove:hover { background: #ffecec; }
      .zh-priority-tile-fields { display: none; padding: 10px; border-top: 1px dashed #e7e9ed; background: #fbfbfc; }
      .zh-priority-tile.is-open .zh-priority-tile-fields { display: grid; }
      .zh-priority-tile-fields-grid { display: grid; grid-template-columns: repeat(2, minmax(110px, 1fr)); gap: 9px; }
      .zh-priority-tile-fields-grid .zh-priority-field-wide { grid-column: 1 / -1; }
      .zh-priority-field { display: grid; gap: 3px; min-width: 0; }
      .zh-priority-field label { color: #7a808a; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; }
      .zh-priority-field input, .zh-priority-field textarea, .zh-priority-field select { width: 100%; box-sizing: border-box; font-size: 12.5px; padding: 6px 8px; border: 1px solid #cbd0d6; border-radius: 6px; background: #fff; color: #222; }
      .zh-priority-field input:focus, .zh-priority-field textarea:focus, .zh-priority-field select:focus { outline: none; border-color: #3976bb; box-shadow: 0 0 0 2px rgba(57,118,187,.15); }
      .zh-priority-field textarea { min-height: 48px; resize: vertical; font-family: inherit; }
      .zh-priority-empty { padding: 28px; text-align: center; color: #8a909a; font-size: 12.5px; }
      .zh-priority-modal button { cursor: pointer; border-radius: 6px; }
      .zh-priority-modal header button { border: 1px solid #c9ccd2; background: #fff; color: #333; padding: 6px 12px; font-size: 12.5px; }
      .zh-priority-modal header button:hover { background: #eef0f3; }
      .zh-priority-modal footer button { border: 1px solid #c9ccd2; background: #fff; color: #333; padding: 7px 14px; font-size: 12.5px; }
      .zh-priority-modal footer button:hover { background: #eef0f3; }
      .zh-priority-modal footer .zh-priority-template-save { border-color: #2f6a2f; background: #e9f7e9; color: #1e5c1e; font-weight: 700; }
      .zh-priority-modal footer .zh-priority-template-save:hover { background: #dcf1dc; }
      @media (max-width: 820px) {
        .zh-priority-side-layout { display: block !important; }
        .zh-priority-side-layout > #zh-priority-template-toolbar { margin: 0 0 12px; }
        .zh-priority-tiles { grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); }
      }
      @media (max-width: 560px) {
        .zh-priority-tile-fields-grid { grid-template-columns: 1fr; }
      }
    `);
  }

  function createPriorityTemplateField(name, label, value, multiline = false, wide = false) {
    const wrapper = document.createElement("div");
    wrapper.className = wide ? "zh-priority-field zh-priority-field-wide" : "zh-priority-field";

    const labelElement = document.createElement("label");
    labelElement.textContent = label;
    wrapper.appendChild(labelElement);

    const input = multiline ? document.createElement("textarea") : document.createElement("input");
    input.name = name;
    input.value = value || "";
    wrapper.appendChild(input);

    return wrapper;
  }

  function createPriorityTemplateSelect(name, label, value, options) {
    const wrapper = document.createElement("div");
    wrapper.className = "zh-priority-field";

    const labelElement = document.createElement("label");
    labelElement.textContent = label;
    wrapper.appendChild(labelElement);

    const select = document.createElement("select");
    select.name = name;
    select.className = "zh-priority-field-select";

    const current = String(value || "").trim();
    const values = [...options];
    if (current && !values.includes(current)) values.push(current);

    const empty = document.createElement("option");
    empty.value = "";
    empty.textContent = "— nicht setzen —";
    select.appendChild(empty);

    values.forEach((optionValue) => {
      const option = document.createElement("option");
      option.value = optionValue;
      option.textContent = optionValue;
      select.appendChild(option);
    });

    select.value = current;
    wrapper.appendChild(select);

    return wrapper;
  }

  function commitPriorityTemplateTiles(list) {
    priorityTemplateConfig = normalizePriorityTemplateConfig({
      groups: getPriorityGroups(),
      templates: readPriorityTemplateEditorRows(list)
    });
    // Persist right away: closing the editor through the backdrop or the X used to
    // discard every change (colour, title, fields, group, order, removals).
    savePriorityTemplateConfig();
    renderPriorityTemplateEditorRows(list);
  }

  function findPriorityTileById(list, id) {
    return [...list.querySelectorAll(".zh-priority-tile")]
      .find((tile) => tile.dataset.templateId === id) || null;
  }

  function movePriorityTileToGroup(tile, groupName) {
    const select = tile.querySelector('select[name="group"]');
    if (!select) return;

    if (![...select.options].some((option) => option.value === groupName)) {
      const option = document.createElement("option");
      option.value = groupName;
      option.textContent = groupName || "Ohne Gruppe";
      select.insertBefore(option, select.lastElementChild);
    }

    select.value = groupName;
  }

  function createPriorityTemplateTile(template, list) {
    const tile = document.createElement("div");
    tile.className = "zh-priority-tile";
    tile.dataset.templateId = template.id || "";
    tile.style.borderLeftColor = template.color || "#3976bb";
    if (priorityTemplateOpenIds.has(template.id)) tile.classList.add("is-open");

    const head = document.createElement("div");
    head.className = "zh-priority-tile-head";

    const dragHandle = document.createElement("span");
    dragHandle.className = "zh-priority-tile-drag";
    dragHandle.textContent = "⠿";
    dragHandle.title = "Zum Sortieren ziehen";
    dragHandle.draggable = true;
    dragHandle.addEventListener("dragstart", (event) => {
      event.dataTransfer.setData("text/plain", `tile:${tile.dataset.templateId}`);
      event.dataTransfer.effectAllowed = "move";
      try {
        event.dataTransfer.setDragImage(tile, 24, 24);
      } catch (error) {
        // setDragImage is not supported everywhere; the default image is fine.
      }
      tile.classList.add("zh-priority-dragging");
    });
    dragHandle.addEventListener("dragend", () => tile.classList.remove("zh-priority-dragging"));

    const colorInput = document.createElement("input");
    colorInput.type = "color";
    colorInput.name = "color";
    colorInput.className = "zh-priority-tile-color";
    colorInput.value = /^#[0-9a-f]{6}$/i.test(template.color) ? template.color : "#3976bb";
    colorInput.title = "Farbe";
    colorInput.addEventListener("input", () => {
      tile.style.borderLeftColor = colorInput.value;
    });

    const main = document.createElement("div");
    main.className = "zh-priority-tile-main";

    const titleInput = document.createElement("input");
    titleInput.name = "title";
    titleInput.className = "zh-priority-tile-title";
    titleInput.value = template.title || "";
    titleInput.placeholder = "Buttonname";
    main.appendChild(titleInput);

    const toggleButton = document.createElement("button");
    toggleButton.type = "button";
    toggleButton.className = "zh-priority-tile-toggle";
    toggleButton.textContent = "Felder";
    toggleButton.title = "Felder ein-/ausblenden";
    toggleButton.addEventListener("click", () => {
      const open = tile.classList.toggle("is-open");
      if (open) priorityTemplateOpenIds.add(tile.dataset.templateId);
      else priorityTemplateOpenIds.delete(tile.dataset.templateId);
    });

    head.append(dragHandle, colorInput, main, toggleButton);

    const meta = document.createElement("div");
    meta.className = "zh-priority-tile-meta";

    const groupSelect = document.createElement("select");
    groupSelect.name = "group";
    groupSelect.className = "zh-priority-tile-group";
    groupSelect.title = "Gruppe";

    const knownGroups = getPriorityGroups();
    const groupNames = [...new Set([template.group, ...knownGroups].filter(Boolean))];
    [["", "Ohne Gruppe"], ...groupNames.map((name) => [name, name])].forEach(([value, label]) => {
      const option = document.createElement("option");
      option.value = value;
      option.textContent = label;
      groupSelect.appendChild(option);
    });

    const newGroupOption = document.createElement("option");
    newGroupOption.value = "__new";
    newGroupOption.textContent = "＋ Neue Gruppe…";
    groupSelect.appendChild(newGroupOption);

    groupSelect.value = template.group || "";
    groupSelect.addEventListener("change", () => {
      if (groupSelect.value !== "__new") {
        commitPriorityTemplateTiles(list);
        return;
      }

      const name = window.prompt("Name der neuen Gruppe:", "");
      if (!name || !name.trim()) {
        groupSelect.value = template.group || "";
        return;
      }

      const groupName = name.trim();
      if (![...groupSelect.options].some((option) => option.value === groupName)) {
        const option = document.createElement("option");
        option.value = groupName;
        option.textContent = groupName;
        groupSelect.insertBefore(option, newGroupOption);
      }
      groupSelect.value = groupName;
      commitPriorityTemplateTiles(list);
    });

    const actions = document.createElement("div");
    actions.className = "zh-priority-tile-actions";

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "zh-priority-tile-remove";
    removeButton.textContent = "✕";
    removeButton.title = "Vorlage entfernen";
    removeButton.addEventListener("click", () => {
      priorityTemplateOpenIds.delete(tile.dataset.templateId);
      tile.remove();
      commitPriorityTemplateTiles(list);
    });

    actions.append(removeButton);
    meta.append(groupSelect, actions);

    tile.addEventListener("dragover", (event) => {
      if (!event.dataTransfer?.types?.includes("text/plain")) return;
      event.preventDefault();
      tile.classList.add("zh-priority-drop-target");
    });
    tile.addEventListener("dragleave", () => tile.classList.remove("zh-priority-drop-target"));
    tile.addEventListener("drop", (event) => {
      const data = event.dataTransfer.getData("text/plain") || "";
      if (!data.startsWith("tile:")) return;
      event.preventDefault();
      event.stopPropagation();
      tile.classList.remove("zh-priority-drop-target");

      const dragged = findPriorityTileById(list, data.slice(5));
      if (!dragged || dragged === tile) return;

      const container = tile.parentElement;
      movePriorityTileToGroup(dragged, container?.dataset.group || "");

      const rect = tile.getBoundingClientRect();
      if (event.clientY > rect.top + rect.height / 2) {
        container.insertBefore(dragged, tile.nextElementSibling);
      } else {
        container.insertBefore(dragged, tile);
      }
      commitPriorityTemplateTiles(list);
    });

    const fields = document.createElement("div");
    fields.className = "zh-priority-tile-fields";

    const grid = document.createElement("div");
    grid.className = "zh-priority-tile-fields-grid";
    grid.append(
      createPriorityTemplateSelect("type", "Typ", template.fields?.type, PRIORITY_TEMPLATE_FIELD_OPTIONS.type),
      createPriorityTemplateField("queue", "Queue", template.fields?.queue),
      createPriorityTemplateSelect("service", "Service", template.fields?.service, PRIORITY_TEMPLATE_FIELD_OPTIONS.service),
      createPriorityTemplateField("owner", "Besitzer", template.fields?.owner),
      createPriorityTemplateSelect("priority", "Priorität", template.fields?.priority, PRIORITY_TEMPLATE_FIELD_OPTIONS.priority),
      createPriorityTemplateSelect("impact", "Auswirkung", template.fields?.impact, PRIORITY_TEMPLATE_FIELD_OPTIONS.impact),
      createPriorityTemplateField("category", "Kategorie", template.fields?.category),
      createPriorityTemplateField("subject", "Betreff", template.fields?.subject),
      createPriorityTemplateField("body", "Text", template.fields?.body, true, true)
    );
    fields.appendChild(grid);

    tile.append(head, meta, fields);
    return tile;
  }

  function readPriorityTemplateEditorRows(list) {
    const rows = [...list.querySelectorAll(".zh-priority-tile")];

    return rows.map((row, index) => {
      const getValue = (name) => row.querySelector(`[name="${name}"]`)?.value?.trim() || "";
      const title = getValue("title") || `Vorlage ${index + 1}`;
      const id = row.dataset.templateId || `priority-template-${index + 1}-${normalizeCategoryId(title) || Date.now()}`;

      return {
        id,
        title,
        color: getValue("color") || "#3976bb",
        group: getValue("group"),
        fields: {
          type: getValue("type"),
          queue: getValue("queue"),
          service: getValue("service"),
          owner: getValue("owner"),
          priority: getValue("priority"),
          impact: getValue("impact"),
          category: getValue("category"),
          subject: getValue("subject"),
          body: getValue("body")
        }
      };
    });
  }

  function applyPriorityTemplateFilter(list) {
    const filter = priorityTemplateFilter.trim().toLowerCase();
    let totalVisible = 0;

    list.querySelectorAll(".zh-priority-group-section").forEach((section) => {
      let visibleCount = 0;

      section.querySelectorAll(".zh-priority-tile").forEach((tile) => {
        const title = (tile.querySelector('[name="title"]')?.value || "").toLowerCase();
        const group = (tile.querySelector('[name="group"]')?.value || "").toLowerCase();
        const match = !filter || title.includes(filter) || group.includes(filter);
        tile.style.display = match ? "" : "none";
        if (match) visibleCount += 1;
      });

      section.style.display = visibleCount ? "" : "none";
      const countSpan = section.querySelector(".zh-priority-group-count");
      if (countSpan) countSpan.textContent = String(visibleCount);
      totalVisible += visibleCount;
    });

    const empty = list.querySelector(".zh-priority-empty");
    if (empty) empty.style.display = totalVisible ? "none" : "";
  }

  function renderPriorityTemplateEditorRows(list) {
    list.innerHTML = "";

    const templates = getPriorityTemplates();

    const empty = document.createElement("div");
    empty.className = "zh-priority-empty";
    empty.textContent = templates.length ? "Keine Vorlage passt zum Filter." : "Noch keine Vorlagen vorhanden.";
    empty.style.display = "none";
    list.appendChild(empty);

    const byGroup = new Map();
    templates.forEach((template) => {
      const groupName = template.group || "";
      if (!byGroup.has(groupName)) byGroup.set(groupName, []);
      byGroup.get(groupName).push(template);
    });

    const orderedGroups = orderPriorityGroups(byGroup);
    const hasGroups = orderedGroups.some((name) => name !== "");

    orderedGroups.forEach((groupName) => {
      const groupTemplates = byGroup.get(groupName) || [];
      if (!groupTemplates.length) return;

      const section = document.createElement("div");
      section.className = "zh-priority-group-section";

      if (hasGroups) {
        const heading = document.createElement("div");
        heading.className = "zh-priority-group-title";
        heading.draggable = Boolean(groupName);
        if (groupName) heading.title = "Gruppe zum Sortieren ziehen";

        const handle = document.createElement("span");
        handle.className = "zh-priority-group-handle";
        handle.textContent = groupName ? "⠿" : "";

        const nameSpan = document.createElement("span");
        nameSpan.textContent = groupName || "Ohne Gruppe";

        const countSpan = document.createElement("span");
        countSpan.className = "zh-priority-group-count";
        countSpan.textContent = String(groupTemplates.length);

        heading.append(handle, nameSpan, countSpan);
        heading.addEventListener("dragstart", (event) => {
          if (!groupName) return;
          event.dataTransfer.setData("text/plain", `group:${groupName}`);
          event.dataTransfer.effectAllowed = "move";
        });
        section.appendChild(heading);
      }

      const tiles = document.createElement("div");
      tiles.className = "zh-priority-tiles";
      tiles.dataset.group = groupName;
      groupTemplates.forEach((template) => tiles.appendChild(createPriorityTemplateTile(template, list)));
      section.appendChild(tiles);

      section.addEventListener("dragover", (event) => {
        if (!event.dataTransfer?.types?.includes("text/plain")) return;
        event.preventDefault();
      });
      section.addEventListener("drop", (event) => {
        const data = event.dataTransfer.getData("text/plain") || "";
        if (!data.startsWith("group:")) return;
        event.preventDefault();

        const draggedGroup = data.slice(6);
        if (!draggedGroup || draggedGroup === groupName) return;

        const order = getPriorityGroups().filter((name) => name && name !== draggedGroup);
        const targetIndex = order.indexOf(groupName);
        if (targetIndex < 0) order.push(draggedGroup);
        else order.splice(targetIndex, 0, draggedGroup);

        priorityTemplateConfig = normalizePriorityTemplateConfig({
          groups: order,
          templates: readPriorityTemplateEditorRows(list)
        });
        renderPriorityTemplateEditorRows(list);
      });

      tiles.addEventListener("dragover", (event) => {
        if (!event.dataTransfer?.types?.includes("text/plain")) return;
        event.preventDefault();
      });
      tiles.addEventListener("drop", (event) => {
        const data = event.dataTransfer.getData("text/plain") || "";
        if (!data.startsWith("tile:")) return;
        event.preventDefault();
        event.stopPropagation();

        const dragged = findPriorityTileById(list, data.slice(5));
        if (!dragged) return;

        movePriorityTileToGroup(dragged, groupName);
        tiles.appendChild(dragged);
        commitPriorityTemplateTiles(list);
      });

      list.appendChild(section);
    });

    applyPriorityTemplateFilter(list);
  }

  function closePriorityTemplateManager() {
    document.querySelector(".zh-priority-modal-backdrop")?.remove();
  }

  function openPriorityTemplateManager() {
    closePriorityTemplateManager();
    addPriorityTemplateStyles();

    const backdrop = document.createElement("div");
    backdrop.className = "zh-priority-modal-backdrop";

    const modal = document.createElement("div");
    modal.className = "zh-priority-modal";
    backdrop.appendChild(modal);

    const header = document.createElement("header");
    const title = document.createElement("h2");
    title.textContent = "Prioritäts-Vorlagen bearbeiten";
    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.textContent = "Schließen";
    closeButton.addEventListener("click", closePriorityTemplateManager);
    header.append(title, closeButton);
    modal.appendChild(header);

    const body = document.createElement("div");
    body.className = "zh-priority-modal-body";

    const tools = document.createElement("div");
    tools.className = "zh-priority-modal-tools";

    const filterInput = document.createElement("input");
    filterInput.type = "search";
    filterInput.placeholder = "Vorlagen filtern (Name oder Gruppe)…";
    filterInput.value = priorityTemplateFilter;
    filterInput.addEventListener("input", () => {
      priorityTemplateFilter = filterInput.value;
      applyPriorityTemplateFilter(list);
    });
    tools.appendChild(filterInput);

    const addButton = document.createElement("button");
    addButton.type = "button";
    addButton.className = "zh-priority-add";
    addButton.textContent = "+ Vorlage";
    addButton.addEventListener("click", () => {
      const templates = readPriorityTemplateEditorRows(list);
      templates.push({
        title: "Neue Vorlage",
        color: "#3976bb",
        group: "",
        fields: { type: "", queue: "", service: "", owner: "", priority: "", impact: "", category: "", subject: "", body: "" }
      });
      priorityTemplateConfig = normalizePriorityTemplateConfig({ groups: getPriorityGroups(), templates });
      renderPriorityTemplateEditorRows(list);
    });
    tools.appendChild(addButton);
    body.appendChild(tools);

    const list = document.createElement("div");
    list.className = "zh-priority-groups";
    body.appendChild(list);
    modal.appendChild(body);
    renderPriorityTemplateEditorRows(list);

    const footer = document.createElement("footer");

    const resetButton = document.createElement("button");
    resetButton.type = "button";
    resetButton.textContent = "Standard wiederherstellen";
    resetButton.addEventListener("click", () => {
      priorityTemplateConfig = normalizePriorityTemplateConfig({ templates: DEFAULT_PRIORITY_TEMPLATES });
      savePriorityTemplateConfig();
      renderPriorityTemplateEditorRows(list);
    });

    const exportButton = document.createElement("button");
    exportButton.type = "button";
    exportButton.textContent = "Exportieren";
    exportButton.title = "Vorlagen als Datei speichern, um sie zu teilen";
    exportButton.addEventListener("click", () => {
      priorityTemplateConfig = normalizePriorityTemplateConfig({ groups: getPriorityGroups(), templates: readPriorityTemplateEditorRows(list) });
      downloadJsonFile("znuny-helper-vorlagen.json", priorityTemplateConfig);
    });

    const importButton = document.createElement("button");
    importButton.type = "button";
    importButton.textContent = "Importieren";
    importButton.title = "Vorlagen aus einer Datei laden";
    importButton.addEventListener("click", () => {
      importJsonFile((data) => {
        if (!data || !Array.isArray(data.templates)) {
          window.alert("Diese Datei enthält keine gültigen Vorlagen.");
          return;
        }

        priorityTemplateConfig = normalizePriorityTemplateConfig(data);
        renderPriorityTemplateEditorRows(list);
      });
    });

    const saveButton = document.createElement("button");
    saveButton.type = "button";
    saveButton.className = "zh-priority-template-save";
    saveButton.textContent = "Speichern";
    saveButton.addEventListener("click", () => {
      priorityTemplateConfig = normalizePriorityTemplateConfig({ groups: getPriorityGroups(), templates: readPriorityTemplateEditorRows(list) });
      savePriorityTemplateConfig();
      closePriorityTemplateManager();
      enablePriorityTemplates();
    });

    footer.append(resetButton, exportButton, importButton, saveButton);
    modal.appendChild(footer);

    backdrop.addEventListener("click", (event) => {
      if (event.target === backdrop) closePriorityTemplateManager();
    });

    document.body.appendChild(backdrop);
  }

  function getPriorityToolbarTarget(doc = document) {
    const settingsWidget = [...doc.querySelectorAll(".WidgetSimple")]
      .find((widget) => /ticket-einstellungen/i.test(normalizeText(getElementText(widget.querySelector(".Header") || widget))));

    if (settingsWidget) {
      const settingsContent = settingsWidget.querySelector(".Content");
      if (settingsContent) {
        return { mode: "prepend-side", element: settingsContent };
      }
      return { mode: "before", element: settingsWidget };
    }

    const firstWidget = [...doc.querySelectorAll(".WidgetSimple, fieldset")]
      .find((element) => /ticket-einstellungen|artikel hinzuf/i.test(normalizeText(getElementText(element))));
    if (firstWidget?.parentElement) {
      return { mode: "before", element: firstWidget };
    }

    return { mode: "prepend", element: doc.querySelector("form") || doc.body };
  }

  function enablePriorityTemplates(doc = document) {
    if (doc === document && window.top !== window.self) return;

    const href = doc.defaultView?.location?.href || window.location.href;
    if (!isPriorityTemplatePage(href)) return;

    addPriorityTemplateStyles(doc);

    const target = getPriorityToolbarTarget(doc);

    const templates = getPriorityTemplates();
    const signature = JSON.stringify({
      mode: target.mode,
      templates: templates.map((template) => [template.id, template.title, template.color, template.group])
    });

    const existing = doc.getElementById("zh-priority-template-toolbar");
    if (existing && existing.dataset.zhSignature === signature) return;
    if (existing) {
      existing.parentElement?.classList.remove("zh-priority-side-layout");
      existing.remove();
    }

    const toolbar = doc.createElement("div");
    toolbar.id = "zh-priority-template-toolbar";
    toolbar.dataset.zhSignature = signature;
    if (target.mode === "prepend-side") {
      toolbar.classList.add("zh-priority-template-side");
      target.element.classList.add("zh-priority-side-layout");
    }

    const byGroup = new Map();
    templates.forEach((template) => {
      const groupName = template.group || "";
      if (!byGroup.has(groupName)) byGroup.set(groupName, []);
      byGroup.get(groupName).push(template);
    });

    const orderedGroups = orderPriorityGroups(byGroup);
    const hasGroups = orderedGroups.some((name) => name !== "");

    const head = doc.createElement("div");
    head.className = "zh-priority-toolbar-head";

    const headTitle = doc.createElement("strong");
    headTitle.textContent = "Vorlagen";
    head.appendChild(headTitle);

    const configButton = doc.createElement("button");
    configButton.type = "button";
    configButton.className = "zh-priority-toolbar-edit";
    configButton.textContent = "Bearbeiten";
    configButton.title = "Vorlagen verwalten";
    configButton.addEventListener("click", openPriorityTemplateManager);
    head.appendChild(configButton);
    toolbar.appendChild(head);

    const groupsWrap = doc.createElement("div");
    groupsWrap.className = "zh-priority-toolbar-groups";

    orderedGroups.forEach((groupName) => {
      const groupTemplates = byGroup.get(groupName) || [];
      if (!groupTemplates.length) return;

      const section = doc.createElement("div");
      section.className = "zh-priority-toolbar-group";

      if (hasGroups) {
        const groupLabel = doc.createElement("div");
        groupLabel.className = "zh-priority-toolbar-group-label";
        groupLabel.textContent = groupName || "Ohne Gruppe";
        section.appendChild(groupLabel);
      }

      const buttons = doc.createElement("div");
      buttons.className = "zh-priority-toolbar-group-buttons";
      groupTemplates.forEach((template) => {
        const button = doc.createElement("button");
        button.type = "button";
        button.className = "zh-priority-template-button";
        button.textContent = template.title;
        button.style.background = template.color || "#3976bb";
        button.title = "Felder mit dieser Vorlage befüllen";
        button.addEventListener("click", () => applyPriorityTemplate(template, doc));
        buttons.appendChild(button);
      });

      section.appendChild(buttons);
      groupsWrap.appendChild(section);
    });

    toolbar.appendChild(groupsWrap);

    const actions = doc.createElement("div");
    actions.className = "zh-priority-toolbar-actions";

    const saveCurrentButton = doc.createElement("button");
    saveCurrentButton.type = "button";
    saveCurrentButton.className = "zh-priority-template-save-current";
    saveCurrentButton.textContent = "Als Vorlage speichern";
    saveCurrentButton.title = "Aktuell ausgefüllte Felder als neue Vorlage speichern";
    saveCurrentButton.addEventListener("click", () => saveCurrentFieldsAsPriorityTemplate(doc));
    actions.appendChild(saveCurrentButton);
    toolbar.appendChild(actions);

    if (doc === document && isPriorityTicketPage(href)) schedulePriorityExternalCustomerBottomNotice();

    if (target.mode === "after") target.element.after(toolbar);
    else if (target.mode === "before") target.element.before(toolbar);
    else target.element.prepend(toolbar);
  }

  function disablePriorityTemplates() {
    closePriorityTemplateManager();
    document.querySelectorAll(".zh-priority-side-layout").forEach((element) => {
      element.classList.remove("zh-priority-side-layout");
    });
    document.getElementById("zh-priority-template-toolbar")?.remove();
    removeStyle("zh-priority-template-style");
  }

  function saveTicketState() {
    syncSet("local", { [TICKET_STATE_KEY]: ticketState });
  }

  function hasManualCategory(ticketId) {
    return Object.prototype.hasOwnProperty.call(ticketState.categories, ticketId);
  }

  function getManualCategory(ticketId) {
    return hasManualCategory(ticketId) ? ticketState.categories[ticketId] : null;
  }

  function setManualCategory(ticketId, category) {
    if (category === "__auto") {
      delete ticketState.categories[ticketId];
    } else {
      ticketState.categories[ticketId] = category;
    }

    saveTicketState();
  }

  function parseAge(text) {
    return ((text.match(/(\d+)\s*d/)?.[1] || 0) * 1440) +
      ((text.match(/(\d+)\s*h/)?.[1] || 0) * 60) +
      Number(text.match(/(\d+)\s*m/)?.[1] || 0);
  }

  function countTicketRowLinks(table) {
    return table.querySelectorAll(
      'a[href*="AgentTicketZoom"], a[href*="TicketID="], a[href*="TicketNumber="]'
    ).length;
  }

  // Widget tables on ticket pages ("Artikeluebersicht", "Verknuepft",
  // "Ticketinformationen", history, attachments, ...) are structurally similar to a
  // ticket list. They must never be treated as a paginated ticket list, no matter
  // how many links they contain.
  const NON_LIST_WIDGET_PATTERN =
    /artikel(?:\u00fc|ue)bersicht|verkn(?:\u00fc|ue)pft|linked|ticketinformation|kundeninformation|customerinformation|(?:\u00e4|ae)hnliche|similar|historie|history|anhang|attachment/i;

  function isKnownWidgetTable(table) {
    if (!table) return true;
    if (isArticleOverviewTable(table)) return true;

    for (let node = table.parentElement; node && node !== document.documentElement; node = node.parentElement) {
      const className = typeof node.className === "string" ? node.className : "";
      if (/(?:^|\s)(?:Sidebar|SidebarColumn|TicketInformation)(?:\s|$)/.test(className)) return true;

      const header = node.querySelector?.(":scope > .Header, :scope > header");
      if (header && NON_LIST_WIDGET_PATTERN.test(getElementText(header))) return true;

      const heading = node.querySelector?.(":scope > h1, :scope > h2, :scope > h3, :scope > legend");
      if (heading && NON_LIST_WIDGET_PATTERN.test(getElementText(heading))) return true;
    }

    return false;
  }

  // `relaxed` additionally accepts a creation date as a list column. The customer
  // portal's overview has fewer columns than the agent list (no age, sometimes no
  // status), so the strict rule would not recognise it. Only the local ticket
  // categories use the relaxed check - pagination and the sound check stay strict.
  function tableLooksLikeTicketList(table, options = {}) {
    if (isKnownWidgetTable(table)) return false;

    // Strong, language-independent signal: several table rows link to the
    // ticket zoom. This also matches the search results table, whose column
    // names differ from the regular ticket list ("Ticket"/"Betreff"/"Von").
    const bodyRows = table.querySelectorAll("tbody tr").length;
    if (bodyRows >= 2 && countTicketRowLinks(table) >= 2) return true;

    // A real ticket list always shows more than one row. Requiring at least two
    // keeps single-row widget details (e.g. "Verknuepft: Ticket (1)") out.
    if (bodyRows < 2) return false;

    const headers = [...table.querySelectorAll("th")].map((th) => getElementText(th).toUpperCase());
    if (!headers.length) {
      const text = getElementText(table).toUpperCase();
      if (text.includes("CASE") && text.includes("ALTER") &&
        (text.includes("SENDER") || text.includes("TITEL") || text.includes("BETREFF"))) {
        return true;
      }

      // Customer portal tables sometimes come without a <th> row at all.
      return Boolean(options.relaxed) && text.includes("TICKET") &&
        (text.includes("TITEL") || text.includes("BETREFF") || text.includes("ERSTELLT") || text.includes("DATUM"));
    }

    if (!headers.some((header) => header.includes("CASE") || header.includes("TICKET"))) return false;

    const has = (terms) => headers.some((header) => terms.some((term) => header.includes(term)));
    let score = 0;
    if (has(["ALTER", "AGE"])) score += 1;
    if (has(["SENDER", "VON", "FROM", "ABSENDER"])) score += 1;
    if (has(["TITEL", "BETREFF", "SUBJECT"])) score += 1;
    if (has(["STATUS"])) score += 1;
    if (options.relaxed && has(["ERSTELLT", "CREATED", "DATUM"])) score += 1;
    return score >= 2;
  }

  function ticketTableScore(table) {
    return table.querySelectorAll("tbody tr").length + countTicketRowLinks(table) * 3;
  }

  function findTicketTable(doc = document, options = {}) {
    const candidates = [...doc.querySelectorAll("table")].filter((table) => tableLooksLikeTicketList(table, options));
    if (!candidates.length) return null;

    // A page can hold several small tables; the real list has the most rows /
    // ticket links. Picking the best candidate avoids scrolling a widget table.
    candidates.sort((left, right) => ticketTableScore(right) - ticketTableScore(left));
    return candidates[0];
  }

  // Die Ticket-Kategorien (und nur sie) brauchen die grosszuegige Erkennung:
  // Das Kundenportal hat weniger Spalten als die Agenten-Liste. An einer Stelle
  // gebuendelt, damit Nachladen und Ton-Pruefung nachweislich streng bleiben.
  function findCategoryTable() {
    return findTicketTable(document, { relaxed: true });
  }

  function getIndexes(table) {
    const headers = [...table.querySelectorAll("th")].map((th) => getElementText(th).trim().toUpperCase());

    return {
      case: headers.findIndex((header) => header.includes("CASE") || header.includes("TICKET")),
      age: headers.findIndex((header) => header.includes("ALTER") || header.includes("AGE")),
      sender: headers.findIndex((header) => header.includes("SENDER") || header.includes("ABSENDER") || header.includes("VON") || header.includes("FROM")),
      title: headers.findIndex((header) => header.includes("TITEL") || header.includes("BETREFF") || header.includes("SUBJECT")),
      status: headers.findIndex((header) => header.includes("STATUS")),
      customer: headers.findIndex((header) => header.includes("KUNDENNUMMER") || header.includes("CUSTOMER"))
    };
  }

  // The customer portal's overview sometimes has no "Ticket"/"Case" column header. Then
  // the column carrying the ticket link is the ticket column - without it the category
  // control (badge, selection, note) would have nowhere to go and could not be edited.
  function resolveTicketColumnIndex(table, indexes) {
    if (indexes.case >= 0) return indexes.case;

    const rows = [...table.querySelectorAll("tbody tr")];
    const cellCount = rows.reduce((max, row) => Math.max(max, row.querySelectorAll("td").length), 0);

    for (let index = 0; index < cellCount; index += 1) {
      const hasTicketLink = rows.some((row) => {
        const cell = row.querySelectorAll("td")[index];
        return Boolean(cell?.querySelector?.('a[href*="TicketID="], a[href*="TicketNumber="]'));
      });

      if (hasTicketLink) return index;
    }

    return -1;
  }

  function getCellText(row, index) {
    if (index < 0) return "";
    return getElementText(row.querySelectorAll("td")[index]).trim() || "";
  }

  function getTicketId(row, indexes) {
    const cell = row.querySelectorAll("td")[indexes.case];
    if (cell?.dataset.zhTicketId) return cell.dataset.zhTicketId;

    let id = "";
    if (cell) id = getElementText(cell).trim().match(/\b\d{7,}\b/)?.[0] || "";

    if (!id) {
      const href = decodeURIComponent(
        row.querySelector('a[href*="TicketID="], a[href*="TicketNumber="]')?.getAttribute("href") || ""
      );
      id = href.match(/[?;&](?:TicketID|TicketNumber)=(\d{5,})/i)?.[1] || "";
    }

    if (!id) id = getElementText(row).match(/\b\d{7,}\b/)?.[0] || "";

    if (id && cell) cell.dataset.zhTicketId = id;
    return id;
  }

  function getAgeMinutes(row, indexes) {
    return parseAge(getCellText(row, indexes.age));
  }

  function getSearchText(row, indexes) {
    return [
      getCellText(row, indexes.case),
      getCellText(row, indexes.sender),
      getCellText(row, indexes.title),
      getCellText(row, indexes.status),
      getCellText(row, indexes.customer)
    ].join(" ").toLowerCase();
  }

  // The page check must be action-based, not structural. "Boolean(findTicketTable())"
  // also matched widget tables on ticket zoom pages - the article overview ("Nr.",
  // "Sender", "Betreff", "Erstellt") and the "Verknuepft" (linked tickets) widget -
  // so infinite scroll ran on ordinary ticket pages: it appended rows that belong to
  // a different context into those widgets and even fetched further "pages" for them.
  // Only real ticket list views may be extended.
  const TICKET_LIST_ACTION_PATTERN =
    /Action=(?:AgentTicket(?:Queue|LockedView|OwnerView|ResponsibleView|WatchView|StatusView|EscalationView|Search)|AgentSearch)\b/i;

  // Used for links that are followed while loading more tickets. Deliberately wider
  // than TICKET_LIST_ACTION_PATTERN (some views paginate through a dedicated result
  // action), but it must never allow a ticket page itself - hence the "Zoom" guard.
  const LIST_PAGER_ACTION_PATTERN = /Action=(?:AgentTicket(?!Zoom\b)|AgentSearch|AgentDashboard)/i;

  function decodeUrlSeparators(url) {
    return String(url || "").replace(/%3B/gi, ";").replace(/%3D/gi, "=");
  }

  function getActionFromUrl(url) {
    return decodeUrlSeparators(url).match(/[?;&]Action=([A-Za-z0-9_]+)/i)?.[1] || "";
  }

  function isTicketListPage() {
    return TICKET_LIST_ACTION_PATTERN.test(decodeUrlSeparators(window.location.href));
  }

  function normalizeListUrl(url, base = window.location.href) {
    try {
      const parsed = new URL(url, base);
      parsed.hash = "";
      return parsed.href;
    } catch (error) {
      return "";
    }
  }

  function getPageNumberFromUrl(url) {
    const decoded = String(url || "").replace(/%3B/gi, ";").replace(/%3D/gi, "=");
    const match = decoded.match(/[?;&]Page=(\d+)/i);
    return match ? Number(match[1]) : 0;
  }

  function urlSupportsPageParam(url) {
    const decoded = String(url || "").replace(/%3B/gi, ";").replace(/%3D/gi, "=");
    return /[?;&]Page=\d+/i.test(decoded);
  }

  // A "next page" of a ticket list is always the same Znuny action with a different
  // page/offset parameter. Anything else (a toolbar link, a ticket page, another
  // view) must never be requested - that is how unrelated content used to be pulled
  // into widget tables.
  function isTrustedNextPageUrl(currentUrl, candidateUrl, requirePaginationParam = false) {
    if (!candidateUrl) return false;

    const current = decodeUrlSeparators(currentUrl);
    const candidate = decodeUrlSeparators(candidateUrl);

    if (normalizeListUrl(candidate) === normalizeListUrl(current)) return false;

    const currentAction = getActionFromUrl(current);
    const candidateAction = getActionFromUrl(candidate);
    if (currentAction && candidateAction && currentAction.toLowerCase() !== candidateAction.toLowerCase()) {
      return false;
    }

    if (requirePaginationParam && !urlSupportsPageParam(candidate) && getStartHitFromUrl(candidate) <= 0) {
      return false;
    }

    return true;
  }

  // Some views (e.g. AgentTicketQueue) paginate by offset instead of page index:
  // page 2 = "...;StartHit=36", page 3 = "...;StartHit=71", i.e. step = page size.
  function getStartHitFromUrl(url) {
    const decoded = String(url || "").replace(/%3B/gi, ";").replace(/%3D/gi, "=");
    const match = decoded.match(/[?;&]StartHit=(\d+)/i);
    return match ? Number(match[1]) : 0;
  }

  function replaceStartHit(url, value) {
    const decoded = String(url || "").replace(/%3B/gi, ";").replace(/%3D/gi, "=");
    if (/[?;&]StartHit=\d+/i.test(decoded)) {
      return decoded.replace(/([?;&])StartHit=\d+/i, `$1StartHit=${value}`);
    }

    const [beforeHash, hash = ""] = decoded.split("#");
    const separator = beforeHash.includes("?") ? ";" : "?";
    return `${beforeHash}${separator}StartHit=${value}${hash ? `#${hash}` : ""}`;
  }

  function getPageNumberFromStartHit(startHit, step) {
    if (!startHit || !step) return 0;
    const base = startHit % step === 0 ? 0 : 1;
    return Math.floor((startHit - base) / step) + 1;
  }

  function inferStartHitStep(doc, baseUrl = window.location.href) {
    const hitsByPage = new Map();
    doc.querySelectorAll(".Pagination a, .OverviewActions a").forEach((link) => {
      const page = Number((link.textContent || "").trim());
      const hit = getStartHitFromUrl(link.getAttribute("href") || link.getAttribute("data-href") || "");
      if (page > 0 && hit > 0) hitsByPage.set(page, hit);
    });

    const pages = [...hitsByPage.keys()].sort((left, right) => left - right);
    for (let i = 1; i < pages.length; i += 1) {
      const diff = hitsByPage.get(pages[i]) - hitsByPage.get(pages[i - 1]);
      if (diff > 0) return diff;
    }

    const range = getElementText(doc.querySelector(".Pagination, .OverviewActions") || doc.body)
      .match(/\b(\d+)\s*[-–]\s*(\d+)\s+von\b/i);
    if (range) {
      const size = Number(range[2]) - Number(range[1]) + 1;
      if (size > 0) return size;
    }

    return 0;
  }

  function getPaginationPageNumber(doc, baseUrl) {
    // The URL of the document being analysed is the most reliable current-page
    // source: pager links always carry their page ("...;Page=3"). The visible
    // "Seite: 1 2 3 4 5 >>" text is NOT usable for this - it always starts at
    // the first page of the block, even while a later page is displayed.
    const fromUrl = getPageNumberFromUrl(baseUrl);
    if (fromUrl > 0) return fromUrl;

    const pager = doc.querySelector(".Pagination, .OverviewActions");
    return Number((getElementText(pager || doc.body)).match(/(?:Seite|Page):\s*(\d+)/i)?.[1] || 0);
  }

  function setUrlPageNumber(url, page) {
    const decoded = String(url || "").replace(/%3B/gi, ";").replace(/%3D/gi, "=");
    if (/[?;&]Page=\d+/i.test(decoded)) {
      return decoded.replace(/([?;&])Page=\d+/i, `$1Page=${page}`);
    }

    const [beforeHash, hash = ""] = decoded.split("#");
    const separator = beforeHash.includes("?") ? ";" : "?";
    return `${beforeHash}${separator}Page=${page}${hash ? `#${hash}` : ""}`;
  }

  function hasMoreTicketListPages(doc = document) {
    const pager = doc.querySelector(".Pagination, .OverviewActions");
    if (!pager) return false;

    const text = getElementText(pager);
    if (/>>|›|»|weiter|next/i.test(text)) return true;

    const currentPage = getPaginationPageNumber(doc, window.location.href) || 1;
    return [...text.matchAll(/\b(\d+)\b/g)].some((match) => Number(match[1]) > currentPage);
  }

  function extractPaginationTarget(link, baseUrl) {
    const rawHref = link.getAttribute("href") || "";
    if (rawHref && !/^\s*(#|javascript:)/i.test(rawHref)) {
      const url = normalizeListUrl(rawHref, baseUrl);
      if (url) return url;
    }

    // JS pagers keep the target in onclick / data attributes instead of href.
    const source = [
      link.getAttribute("onclick") || "",
      link.getAttribute("data-href") || "",
      link.getAttribute("data-url") || "",
      link.getAttribute("data-target") || ""
    ].join(" ");
    const candidate = source.match(/['"]\s*([^'"]*?(?:Action=|index\.pl)[^'"]*?)\s*['"]/i)?.[1];
    if (candidate) {
      const url = normalizeListUrl(candidate, baseUrl);
      if (url) return url;
    }

    return "";
  }

  function findNextTicketListUrl(doc = document, baseUrl = window.location.href, currentPageOverride = 0) {
    // Prefer the pager container so unrelated toolbar links are ignored. The
    // search results and the regular list both render their pager inside
    // ".OverviewActions" / ".Pagination".
    const pagerContainers = [...doc.querySelectorAll(".Pagination, .OverviewActions")];
    const scoped = pagerContainers.length > 0;
    const scope = scoped ? pagerContainers : [doc];

    const links = [];
    scope.forEach((container) => {
      container.querySelectorAll("a").forEach((link) => {
        const href = extractPaginationTarget(link, baseUrl);
        if (!href) return;

        // Never follow a pager link that leaves the ticket list actions.
        if (!LIST_PAGER_ACTION_PATTERN.test(decodeUrlSeparators(href))) return;

        // Outside a real pager container every link of the page is a candidate,
        // including toolbar actions. Accept one only if it stays on the current
        // action and carries an actual page/offset parameter.
        if (!scoped && !isTrustedNextPageUrl(baseUrl, href, true)) return;

        links.push({
          href,
          text: normalizeText(link.innerText || link.textContent || ""),
          title: normalizeText(link.getAttribute("title") || link.getAttribute("aria-label") || ""),
          rel: (link.getAttribute("rel") || "").toLowerCase()
        });
      });
    });

    const explicitNext = links.find((item) =>
      item.rel.includes("next") ||
      /^(>|›|»|≫|>>)$/.test(item.text) ||
      /^(weiter|next|nächste|naechste|nächster|vor)$/i.test(item.text) ||
      /^(weiter|next|nächste|naechste)/i.test(item.title)
    );

    const currentPage = currentPageOverride > 0 ? currentPageOverride : getPaginationPageNumber(doc, baseUrl);

    const numericLinks = links
      .map((item) => {
        const pageFromText = Number(item.text.match(/^\d+$/)?.[0] || 0);
        return { ...item, page: pageFromText || getPageNumberFromUrl(item.href) };
      })
      .filter((item) => item.page > 0)
      .sort((left, right) => left.page - right.page);

    if (currentPage > 0) {
      const target = numericLinks.find((item) => item.page === currentPage + 1);
      if (target) return target.href;

      if (explicitNext) return explicitNext.href;

      return numericLinks.find((item) => item.page > currentPage)?.href || "";
    }

    if (explicitNext) return explicitNext.href;

    return numericLinks[0]?.href || "";
  }

  function resolveNextTicketListUrl(currentUrl = normalizeListUrl(window.location.href), currentPage = 0) {
    const nextUrl = findNextTicketListUrl(document, currentUrl, currentPage);
    // A pager control can point back at the current page (e.g. a JS pager);
    // that is not a next page.
    return nextUrl && normalizeListUrl(nextUrl) !== currentUrl ? nextUrl : "";
  }

  function getExistingTicketIds(table, indexes) {
    const ids = new Set();

    table.querySelectorAll("tbody tr").forEach((row) => {
      const ticketId = getTicketId(row, indexes);
      if (ticketId) ids.add(ticketId);
    });

    return ids;
  }

  function ensureInfiniteScrollStatus(table) {
    let status = document.getElementById("zh-infinite-scroll-status");
    if (status) return status;

    status = document.createElement("div");
    status.id = "zh-infinite-scroll-status";
    status.textContent = "";

    const resolvedTable = table || findTicketTable();
    resolvedTable?.parentElement?.appendChild(status);
    return status;
  }

  function addInfiniteScrollStyles() {
    addStyle("zh-infinite-scroll-style", `
      #zh-infinite-scroll-status { padding: 10px 12px; color: #555; font-size: 12px; text-align: center; background: #f4f4f4; border-top: 1px solid #ddd; }
      #zh-infinite-scroll-status:empty { display: none; }
    `);
  }

  function setInfiniteScrollStatus(text, table) {
    if (!text) {
      document.getElementById("zh-infinite-scroll-status")?.remove();
      return;
    }

    const status = ensureInfiniteScrollStatus(table);
    status.textContent = text;
  }

  const INFINITE_SCROLL_MAX_FAILURES = 3;
  const INFINITE_SCROLL_RETRY_DELAY_MS = 4000;
  const INFINITE_SCROLL_FETCH_TIMEOUT_MS = 20000;
  const INFINITE_SCROLL_MAX_PAGES = 800;
  const INFINITE_SCROLL_MAX_ROWS = 20000;
  const INFINITE_SCROLL_POLL_MS = 1000;

  function pageFingerprint(table) {
    if (!table) return "";
    const indexes = getIndexes(table);
    const rows = [...table.querySelectorAll("tbody tr")];
    const sample = rows
      .slice(0, 6)
      .map((row) => getTicketId(row, indexes) || normalizeText(getElementText(row)).slice(0, 120));
    return `${rows.length}#${sample.join("|")}`;
  }

  // Column layout of a table, used to verify that a fetched page really is the
  // same list. Labels are stripped down to letters/digits so that sort indicators
  // or icons inside the header cells cannot cause a false mismatch.
  function tableColumnSignature(table) {
    if (!table) return "";

    const labels = [...table.querySelectorAll("th")]
      .map((cell) => normalizeText(getElementText(cell)).toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim())
      .filter(Boolean);
    if (labels.length) return labels.join("|");

    const firstRow = table.querySelector("tbody tr");
    return firstRow ? `${firstRow.children.length} Spalten` : "";
  }

  // Widest row in the table = the real column count. Group separators ("Heute")
  // use a single colspan cell, so the maximum is the reliable value.
  function getTicketRowCellCount(table) {
    const counts = [...table.querySelectorAll("tbody tr")].map((row) => row.children.length);
    return counts.length ? Math.max(...counts) : 0;
  }

  async function fetchTicketListPage(url) {
    if (typeof AbortController === "undefined") {
      return fetch(url, { credentials: "include", cache: "no-store" });
    }

    const controller = new AbortController();
    const timer = window.setTimeout(() => controller.abort(), INFINITE_SCROLL_FETCH_TIMEOUT_MS);
    try {
      return await fetch(url, { credentials: "include", cache: "no-store", signal: controller.signal });
    } finally {
      window.clearTimeout(timer);
    }
  }

  async function loadNextTicketListPage() {
    if (infiniteScrollState.loading || infiniteScrollState.done || !infiniteScrollState.nextUrl) return;

    const table = findTicketTable();
    const tbody = table?.querySelector("tbody");
    if (!table || !tbody) return;

    // Absolute safety valve: never request more than a sane number of pages or
    // append an unbounded number of rows.
    if (infiniteScrollState.loadedPages.size >= INFINITE_SCROLL_MAX_PAGES ||
        infiniteScrollState.appendedTotal >= INFINITE_SCROLL_MAX_ROWS) {
      infiniteScrollState.done = true;
      infiniteScrollState.nextUrl = "";
      setInfiniteScrollStatus("Alle Tickets geladen.", table);
      return;
    }

    const loadUrl = infiniteScrollState.nextUrl;
    // nextUrl always points at the page after the one currently displayed. Some
    // lists (StartHit-based) have no page number in the URL, so fall back to the
    // logical counter instead of parsing it out of the URL.
    const expectedPage = (infiniteScrollState.currentPage || 1) + 1;
    const loadingPage = getPageNumberFromUrl(loadUrl) || expectedPage;

    // Final safety check before touching the network: only ever request a ticket
    // list action, never a ticket page or an unrelated action.
    if (!LIST_PAGER_ACTION_PATTERN.test(decodeUrlSeparators(loadUrl))) {
      infiniteScrollState.done = true;
      infiniteScrollState.nextUrl = "";
      setInfiniteScrollStatus("", table);
      return;
    }

    // Requesting a page we already loaded means the server is ignoring the page
    // parameter and would keep serving the same content - stop instead of looping.
    if (loadingPage && infiniteScrollState.loadedPages.has(loadingPage)) {
      infiniteScrollState.done = true;
      infiniteScrollState.nextUrl = "";
      setInfiniteScrollStatus("Alle Tickets geladen.", table);
      return;
    }

    infiniteScrollState.loading = true;
    setInfiniteScrollStatus(loadingPage ? `Weitere Tickets werden geladen … (Seite ${loadingPage})` : "Weitere Tickets werden geladen …", table);

    try {
      const response = await fetchTicketListPage(loadUrl);

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      const html = await response.text();
      const nextDoc = new DOMParser().parseFromString(html, "text/html");
      const nextTable = findTicketTable(nextDoc);
      const nextBody = nextTable?.querySelector("tbody");

      if (!nextTable || !nextBody) {
        infiniteScrollState.done = true;
        infiniteScrollState.nextUrl = "";
        setInfiniteScrollStatus("Weitere Tickets konnten nicht automatisch geladen werden.", table);
        return;
      }

      const fingerprint = pageFingerprint(nextTable);
      const fingerprintSeen = Boolean(fingerprint) && infiniteScrollState.seenFingerprints.has(fingerprint);
      if (fingerprint) infiniteScrollState.seenFingerprints.add(fingerprint);

      // The fetched page must still be the same list: same columns, same column
      // count. Otherwise the rows would be appended into a table they do not
      // belong to - exactly how unrelated rows ended up in widget tables.
      if (tableColumnSignature(table) !== tableColumnSignature(nextTable)) {
        infiniteScrollState.done = true;
        infiniteScrollState.nextUrl = "";
        setInfiniteScrollStatus("Weitere Tickets konnten nicht automatisch geladen werden.", table);
        return;
      }

      const indexes = getIndexes(table);
      const nextIndexes = getIndexes(nextTable);
      const expectedCellCount = getTicketRowCellCount(table);
      const seenIds = infiniteScrollState.seenIds;
      getExistingTicketIds(table, indexes).forEach((ticketId) => seenIds.add(ticketId));

      let addedCount = 0;

      if (!fingerprintSeen) {
        [...nextBody.querySelectorAll("tr")].forEach((row) => {
          // Rows must have the column count of the live list; anything else
          // (partially rendered or foreign rows) is skipped.
          if (expectedCellCount && row.children.length !== expectedCellCount) return;

          const ticketId = getTicketId(row, nextIndexes);
          // Only append rows with a stable, unique ticket id. Rows without an id
          // cannot be de-duplicated reliably and would be appended over and over.
          if (!ticketId || seenIds.has(ticketId)) return;

          const clone = document.importNode(row, true);
          tbody.appendChild(clone);
          seenIds.add(ticketId);
          addedCount += 1;
        });
      }

      const loadedUrl = loadUrl;
      const loadedPage = getPageNumberFromUrl(loadedUrl) || expectedPage;
      infiniteScrollState.loadedPages.add(loadedPage);
      infiniteScrollState.appendedTotal += addedCount;

      // No new tickets on this page means we have reached the end (or the
      // server keeps returning an already-seen page). Stop instead of looping.
      if (addedCount === 0) {
        infiniteScrollState.nextUrl = "";
        infiniteScrollState.done = true;
        setInfiniteScrollStatus("Alle Tickets geladen.", table);
        return;
      }

      if (!infiniteScrollState.startHitStep) {
        const inferredStep = inferStartHitStep(nextDoc, loadedUrl);
        if (inferredStep > 0) infiniteScrollState.startHitStep = inferredStep;
      }

      // Follow the real pager link first. Only derive the next page when the list
      // actually uses a matching pagination parameter, so we never invent one for
      // a view that does not support it and would keep returning the same page.
      const nextPage = loadedPage + 1;
      let followingUrl = findNextTicketListUrl(nextDoc, loadedUrl, loadedPage);
      if (followingUrl && normalizeListUrl(followingUrl) === normalizeListUrl(loadedUrl)) followingUrl = "";
      if (!followingUrl && infiniteScrollState.pageParamSupported && urlSupportsPageParam(loadedUrl)) {
        const derived = setUrlPageNumber(loadedUrl, nextPage);
        if (normalizeListUrl(derived) !== normalizeListUrl(loadedUrl)) followingUrl = derived;
      }
      if (!followingUrl && infiniteScrollState.startHitStep) {
        const startHit = getStartHitFromUrl(loadedUrl);
        if (startHit > 0) {
          const derived = replaceStartHit(loadedUrl, startHit + infiniteScrollState.startHitStep);
          if (normalizeListUrl(derived) !== normalizeListUrl(loadedUrl)) followingUrl = derived;
        }
      }

      infiniteScrollState.currentPage = loadedPage;
      if (followingUrl && urlSupportsPageParam(followingUrl)) infiniteScrollState.pageParamSupported = true;
      infiniteScrollState.nextUrl = followingUrl;
      infiniteScrollState.done = !followingUrl;
      infiniteScrollState.hasLoadedPage = true;
      infiniteScrollState.failCount = 0;
      infiniteScrollState.nextRetryAt = 0;

      if (settings.ticketCategories && isCategoryTicketListPage()) {
        applyTicketCategories();
      }

      setInfiniteScrollStatus(infiniteScrollState.done ? "Alle Tickets geladen." : "", table);
    } catch (error) {
      console.warn("Znuny Helper infinite scroll failed:", error);
      infiniteScrollState.failCount += 1;

      if (infiniteScrollState.failCount >= INFINITE_SCROLL_MAX_FAILURES) {
        infiniteScrollState.done = true;
        infiniteScrollState.nextUrl = "";
        setInfiniteScrollStatus("Weitere Tickets konnten nicht geladen werden. Bitte Seite neu laden.", table);
      } else {
        infiniteScrollState.nextRetryAt = Date.now() + INFINITE_SCROLL_RETRY_DELAY_MS;
        setInfiniteScrollStatus("Weitere Tickets konnten nicht geladen werden, wird erneut versucht …", table);
      }
    } finally {
      infiniteScrollState.loading = false;
      const delay = Math.max(80, infiniteScrollState.nextRetryAt - Date.now());
      window.setTimeout(maybeLoadNextTicketListPage, delay);
    }
  }

  function maybeLoadNextTicketListPage() {
    if (!settings.ticketListInfiniteScroll) return;
    if (infiniteScrollState.loading || infiniteScrollState.done) return;
    if (!infiniteScrollState.nextUrl) return;
    if (Date.now() < infiniteScrollState.nextRetryAt) return;

    const distanceToBottom = document.documentElement.scrollHeight - (window.scrollY + window.innerHeight);
    if (distanceToBottom < 650) {
      loadNextTicketListPage();
    }
  }

  function enableTicketListInfiniteScroll() {
    if (!isTicketListPage()) {
      disableTicketListInfiniteScroll();
      return;
    }

    const currentUrl = normalizeListUrl(window.location.href);

    addInfiniteScrollStyles();

    if (infiniteScrollState.enabledUrl !== currentUrl) {
      const startHitStep = inferStartHitStep(document, currentUrl);
      const startPage = getPageNumberFromUrl(currentUrl) ||
        getPageNumberFromStartHit(getStartHitFromUrl(currentUrl), startHitStep) || 1;
      let nextUrl = resolveNextTicketListUrl(currentUrl, startPage);
      if (!nextUrl && hasMoreTicketListPages(document)) {
        if (urlSupportsPageParam(currentUrl)) {
          nextUrl = setUrlPageNumber(currentUrl, startPage + 1);
        } else if (startHitStep && getStartHitFromUrl(currentUrl) > 0) {
          nextUrl = replaceStartHit(currentUrl, getStartHitFromUrl(currentUrl) + startHitStep);
        }
      }
      if (nextUrl && !isTrustedNextPageUrl(currentUrl, nextUrl)) nextUrl = "";
      if (infiniteScrollState.pollTimer) window.clearInterval(infiniteScrollState.pollTimer);
      infiniteScrollState = {
        enabledUrl: currentUrl,
        nextUrl,
        loading: false,
        done: !nextUrl,
        bound: infiniteScrollState.bound,
        hasLoadedPage: false,
        currentPage: startPage,
        failCount: 0,
        nextRetryAt: 0,
        seenIds: new Set(),
        loadedPages: new Set([startPage]),
        seenFingerprints: new Set(),
        appendedTotal: 0,
        pageParamSupported: urlSupportsPageParam(currentUrl) || urlSupportsPageParam(nextUrl),
        startHitStep,
        pollTimer: 0
      };
      setInfiniteScrollStatus("");
    } else if (!infiniteScrollState.nextUrl && !infiniteScrollState.hasLoadedPage && !infiniteScrollState.loading && !infiniteScrollState.done) {
      // Only recover nextUrl from the live DOM before any page has loaded (pagination
      // can render late). Afterward the live pager is stale and re-checking it here
      // would keep resetting an already-exhausted or in-flight state.
      const startPage = infiniteScrollState.currentPage || getPageNumberFromUrl(currentUrl) || 1;
      let nextUrl = resolveNextTicketListUrl(currentUrl, startPage);
      if (!nextUrl && hasMoreTicketListPages(document)) {
        if (urlSupportsPageParam(currentUrl)) {
          nextUrl = setUrlPageNumber(currentUrl, startPage + 1);
        } else if (infiniteScrollState.startHitStep && getStartHitFromUrl(currentUrl) > 0) {
          nextUrl = replaceStartHit(currentUrl, getStartHitFromUrl(currentUrl) + infiniteScrollState.startHitStep);
        }
      }
      if (nextUrl && !isTrustedNextPageUrl(currentUrl, nextUrl)) nextUrl = "";
      if (nextUrl) {
        infiniteScrollState.currentPage = startPage;
        infiniteScrollState.nextUrl = nextUrl;
        infiniteScrollState.done = false;
        if (urlSupportsPageParam(nextUrl)) infiniteScrollState.pageParamSupported = true;
      }
    }

    if (!infiniteScrollState.bound) {
      infiniteScrollState.bound = true;
      window.addEventListener("scroll", maybeLoadNextTicketListPage, { passive: true });
      // Some views scroll an inner container rather than the window; scroll
      // events don't bubble but can be observed during the capture phase.
      document.addEventListener("scroll", maybeLoadNextTicketListPage, { passive: true, capture: true });
      window.addEventListener("resize", maybeLoadNextTicketListPage);
    }

    // Keep loading as long as the user stays near the bottom. A plain scroll
    // listener can miss the moment a short page grows, so poll as a fallback.
    if (!infiniteScrollState.pollTimer) {
      infiniteScrollState.pollTimer = window.setInterval(() => {
        if (!settings.ticketListInfiniteScroll || infiniteScrollState.done) return;
        maybeLoadNextTicketListPage();
      }, INFINITE_SCROLL_POLL_MS);
    }

    window.setTimeout(maybeLoadNextTicketListPage, 120);
  }

  function disableTicketListInfiniteScroll() {
    document.getElementById("zh-infinite-scroll-status")?.remove();
    removeStyle("zh-infinite-scroll-style");
    if (infiniteScrollState.pollTimer) window.clearInterval(infiniteScrollState.pollTimer);
    // Reset the complete loading state. Leaving "enabledUrl" behind made the
    // re-enable path skip its initialisation, and a leftover "done" flag kept the
    // feature stuck on "Alle Tickets geladen." after off/on without a reload.
    infiniteScrollState.enabledUrl = "";
    infiniteScrollState.nextUrl = "";
    infiniteScrollState.done = false;
    infiniteScrollState.hasLoadedPage = false;
    infiniteScrollState.currentPage = 0;
    infiniteScrollState.failCount = 0;
    infiniteScrollState.nextRetryAt = 0;
    infiniteScrollState.pollTimer = 0;
    infiniteScrollState.seenIds = new Set();
    infiniteScrollState.loadedPages = new Set();
    infiniteScrollState.seenFingerprints = new Set();
    infiniteScrollState.appendedTotal = 0;
    infiniteScrollState.pageParamSupported = false;
    infiniteScrollState.startHitStep = 0;
  }

  function autoDetectCategory(row, indexes) {
    const text = getSearchText(row, indexes);

    const priority = getCategoryGroups()
      .filter((group) => group.id)
      .sort((a, b) => a.order - b.order)
      .map((group) => group.id);
    const keywords = getCategoryKeywords();

    for (const groupId of priority) {
      const words = keywords[groupId] || [];
      if (words.some((word) => text.includes(word.toLowerCase()))) return groupId;
    }

    return "";
  }

  function getEffectiveCategory(row, indexes) {
    const ticketId = getTicketId(row, indexes);
    const manual = getManualCategory(ticketId);
    return manual !== null ? manual : autoDetectCategory(row, indexes);
  }

  function isStarred(row, indexes) {
    const cells = [...row.querySelectorAll("td")];
    const beforeCase = cells.slice(0, indexes.case);

    return beforeCase.some((cell) => {
      const text = cell.innerText.trim();
      if (text.includes("*") || text.includes("\u2605") || text.includes("\u2606")) return true;

      // Only concrete markers count. Matching the bare word "priority" in the HTML
      // used to mark every row of a list that happens to have a priority column.
      return [...cell.querySelectorAll("img, i, span, a, div")].some((element) => {
        const marker = [
          typeof element.className === "string" ? element.className : "",
          element.getAttribute("title"),
          element.getAttribute("alt"),
          element.getAttribute("aria-label"),
          element.dataset?.icon
        ].filter((value) => typeof value === "string").join(" ").toLowerCase();

        return /\bstar(?:red)?\b|\bimportant\b|\bflag(?:ged)?\b|\bwichtig\b|\bmarkiert\b/.test(marker);
      });
    });
  }

  function addTicketCategoryStyles() {
    addStyle("zh-ticket-category-style", `
      .zh-cat-ui { display: inline-block; width: 104px; height: 19px; margin-left: 6px; vertical-align: middle; position: relative; }
      .zh-badge, .zh-category-select { width: 100px; box-sizing: border-box; position: absolute; left: 0; top: 0; }
      .zh-badge { font-size: 10px; padding: 1px 5px; border-radius: 3px; border: 1px solid rgba(0,0,0,.22); color: #111; text-align: center; height: 19px; line-height: 15px; overflow: hidden; display: inline-block; font-weight: 400; }
      .zh-badge-auto { font-style: italic; border-style: dashed; border-color: rgba(0,0,0,.35); }
      .zh-category-select { visibility: hidden; opacity: 0; font-size: 11px; height: 20px; border: 1px solid #999; border-radius: 3px; background: white; color: black; z-index: 10000; }
      .zh-cat-ui:hover .zh-category-select, .zh-cat-ui:focus-within .zh-category-select { visibility: visible; opacity: 1; }
      .zh-cat-ui:hover .zh-badge, .zh-cat-ui:focus-within .zh-badge { visibility: hidden; opacity: 0; }
      .zh-note-wrap { display: inline-block; position: relative; margin-left: 4px; vertical-align: middle; }
      .zh-note-btn { cursor: pointer; border: none; background: transparent; font-size: 13px; padding: 0 2px; opacity: .45; }
      .zh-note-btn:hover, .zh-note-btn.has-note { opacity: 1; background: #ffeb99; border-radius: 4px; }
      .zh-note-popup { position: fixed; width: 240px; background: #fffef5; border: 1px solid #c9b458; border-radius: 6px; box-shadow: 0 4px 14px rgba(0,0,0,.24); padding: 8px; z-index: 999999; }
      .zh-note-popup-title { font-size: 11px; font-weight: bold; margin-bottom: 5px; color: #333; }
      .zh-note-popup textarea { width: 100%; height: 75px; resize: vertical; box-sizing: border-box; font-size: 12px; border: 1px solid #aaa; border-radius: 4px; padding: 5px; }
      .zh-note-actions { display: flex; justify-content: flex-end; gap: 5px; margin-top: 5px; }
      .zh-note-actions button { font-size: 11px; padding: 3px 7px; border: 1px solid #999; border-radius: 4px; background: #eee; cursor: pointer; }
      .zh-auto-marker { font-size: 10px; opacity: .6; margin-left: 3px; }
      .zh-category-tools { margin: 7px 0; }
      .zh-category-manage-btn { font-size: 11px; padding: 3px 8px; border: 1px solid #aaa; border-radius: 3px; background: #f5f5f5; color: #222; cursor: pointer; }
      .zh-category-manage-btn:hover { background: #fff; }
      .zh-row-starred td:first-child { box-shadow: inset 3px 0 0 #ff9900; }
      .zh-age-warn { color: #b26a00 !important; font-weight: bold; }
      .zh-age-hot { color: #b00000 !important; font-weight: bold; }
      .zh-age-old { color: #6f2dbd !important; font-weight: bold; }
      .zh-category-modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,.35); z-index: 999998; display: flex; align-items: center; justify-content: center; }
      .zh-category-modal { width: min(920px, 94vw); max-height: 88vh; overflow: auto; background: #fff; border: 1px solid #777; border-radius: 4px; box-shadow: 0 8px 30px rgba(0,0,0,.35); color: #111; }
      .zh-category-modal header { display: flex; justify-content: space-between; align-items: center; padding: 9px 12px; border-bottom: 1px solid #ddd; background: #f1f1f1; }
      .zh-category-modal h2 { margin: 0; font-size: 15px; }
      .zh-category-modal-body { padding: 10px; }
      .zh-category-editor-hint { font-size: 11px; color: #555; margin-bottom: 8px; padding: 6px 8px; background: #eef4ff; border: 1px solid #cfe0ff; border-radius: 4px; }
      .zh-category-editor-row { display: grid; grid-template-columns: 26px minmax(150px, 1.4fr) 96px 56px auto; grid-template-areas: "order title short color actions" "keywords keywords keywords keywords keywords"; gap: 6px 8px; align-items: center; margin-bottom: 6px; padding: 7px 9px; border: 1px solid #e4e4e4; border-radius: 6px; background: #fff; }
      .zh-category-editor-order { grid-area: order; text-align: center; color: #888; font-size: 12px; }
      .zh-category-editor-row input, .zh-category-editor-row textarea { width: 100%; box-sizing: border-box; font-size: 12px; }
      .zh-category-editor-row [name="title"] { grid-area: title; }
      .zh-category-editor-row [name="short"] { grid-area: short; }
      .zh-category-editor-row [name="color"] { grid-area: color; height: 30px; padding: 2px; }
      .zh-category-editor-row [name="keywords"] { grid-area: keywords; min-height: 30px; max-height: 140px; resize: vertical; }
      .zh-category-editor-actions { grid-area: actions; display: flex; gap: 4px; flex-wrap: nowrap; }
      .zh-category-modal button { font-size: 11px; padding: 3px 7px; border: 1px solid #999; border-radius: 3px; background: #eee; cursor: pointer; }
      .zh-category-modal footer { display: flex; justify-content: space-between; gap: 8px; padding: 10px 12px; border-top: 1px solid #ddd; background: #f7f7f7; }
    `);
  }

  function blockTicketNavigation(element) {
    ["click", "mousedown", "mouseup", "pointerdown", "pointerup", "dblclick"].forEach((eventName) => {
      element.addEventListener(eventName, (event) => event.stopPropagation());
    });
  }

  function closeAllNotePopups() {
    document.querySelectorAll(".zh-note-popup").forEach((popup) => popup.remove());
    openNoteTicketId = null;
  }

  function openNotePopup(button, ticketId) {
    closeAllNotePopups();
    openNoteTicketId = ticketId;

    const rect = button.getBoundingClientRect();
    const popup = document.createElement("div");
    popup.className = "zh-note-popup";
    popup.style.left = `${Math.min(rect.left, window.innerWidth - 260)}px`;
    popup.style.top = `${rect.bottom + 6}px`;

    const title = document.createElement("div");
    title.className = "zh-note-popup-title";
    title.textContent = `Notiz für Ticket ${ticketId}`;

    const textarea = document.createElement("textarea");
    textarea.placeholder = "Lokale Notiz...";
    textarea.value = ticketState.notes[ticketId] || "";

    const actions = document.createElement("div");
    actions.className = "zh-note-actions";

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.textContent = "Loeschen";

    const cancelButton = document.createElement("button");
    cancelButton.type = "button";
    cancelButton.textContent = "Abbrechen";

    const saveButton = document.createElement("button");
    saveButton.type = "button";
    saveButton.textContent = "Speichern";

    actions.append(deleteButton, cancelButton, saveButton);
    popup.append(title, textarea, actions);

    [popup, textarea, deleteButton, cancelButton, saveButton].forEach(blockTicketNavigation);

    saveButton.addEventListener("click", (event) => {
      stopEvent(event);
      const value = textarea.value.trim();

      if (value) {
        ticketState.notes[ticketId] = value;
      } else {
        delete ticketState.notes[ticketId];
      }

      saveTicketState();
      closeAllNotePopups();
      applyTicketCategories();
    });

    deleteButton.addEventListener("click", (event) => {
      stopEvent(event);
      delete ticketState.notes[ticketId];
      saveTicketState();
      closeAllNotePopups();
      applyTicketCategories();
    });

    cancelButton.addEventListener("click", (event) => {
      stopEvent(event);
      closeAllNotePopups();
    });

    document.body.appendChild(popup);
    window.setTimeout(() => textarea.focus(), 30);
  }

  document.addEventListener("click", (event) => {
    if (!event.target.closest(".zh-note-popup") && !event.target.closest(".zh-note-btn")) {
      closeAllNotePopups();
    }
  });

  function decorateCaseCell(row, indexes) {
    const cell = row.querySelectorAll("td")[indexes.case];
    const ticketId = getTicketId(row, indexes);

    if (!cell || !ticketId || cell.querySelector(".zh-cat-ui")) return;

    if (!cell.dataset.zhOriginalBackground) {
      cell.dataset.zhOriginalBackground = cell.style.background || "";
      cell.dataset.zhOriginalFontWeight = cell.style.fontWeight || "";
    }

    const ui = document.createElement("span");
    ui.className = "zh-cat-ui";

    const badge = document.createElement("span");
    badge.className = "zh-badge";

    const select = document.createElement("select");
    select.className = "zh-category-select";

    const autoOption = document.createElement("option");
    autoOption.value = "__auto";
    autoOption.textContent = "Auto (Vorschlag)";
    select.appendChild(autoOption);

    getCategoryGroups().forEach((group) => {
      const option = document.createElement("option");
      option.value = group.id;
      option.textContent = group.title;
      select.appendChild(option);
    });

    blockTicketNavigation(ui);
    blockTicketNavigation(select);

    select.addEventListener("change", (event) => {
      stopEvent(event);
      setManualCategory(ticketId, select.value);
      window.setTimeout(applyTicketCategories, 50);
    });

    ui.append(badge, select);
    cell.appendChild(ui);

    const noteWrap = document.createElement("span");
    noteWrap.className = "zh-note-wrap";

    const noteButton = document.createElement("button");
    noteButton.type = "button";
    noteButton.className = "zh-note-btn";
    noteButton.textContent = "N";
    noteButton.title = "Lokale Notiz";

    blockTicketNavigation(noteWrap);
    blockTicketNavigation(noteButton);

    noteButton.addEventListener("click", (event) => {
      stopEvent(event);
      if (openNoteTicketId === ticketId) {
        closeAllNotePopups();
      } else {
        openNotePopup(noteButton, ticketId);
      }
    });

    noteWrap.appendChild(noteButton);
    cell.appendChild(noteWrap);
  }

  function decorateAgeCell(row, indexes) {
    const ageCell = row.querySelectorAll("td")[indexes.age];
    if (!ageCell) return;

    ageCell.classList.remove("zh-age-warn", "zh-age-hot", "zh-age-old");

    const age = getAgeMinutes(row, indexes);

    if (age >= 100 * 1440) ageCell.classList.add("zh-age-old");
    else if (age >= 30 * 1440) ageCell.classList.add("zh-age-hot");
    else if (age >= 7 * 1440) ageCell.classList.add("zh-age-warn");
  }

  function removeGroupHeaders(tbody) {
    tbody.querySelectorAll(".zh-group-header").forEach((row) => row.remove());
  }

  function ensureCategoryManageButton(table) {
    if (document.getElementById("zh-category-manage-btn")) return;

    const wrap = document.createElement("div");
    wrap.className = "zh-category-tools";

    const button = document.createElement("button");
    button.id = "zh-category-manage-btn";
    button.type = "button";
    button.className = "zh-category-manage-btn";
    button.textContent = "Kategorien bearbeiten";
    button.addEventListener("click", (event) => {
      stopEvent(event);
      openCategoryManager();
    });

    wrap.appendChild(button);
    table.parentElement.insertBefore(wrap, table);
  }

  // Escape schliesst die Verwaltung - wie Vorschau und Notizfenster. Der
  // Handler haengt an document und wird beim Schliessen wieder entfernt, sonst
  // bliebe er nach dem ersten Oeffnen dauerhaft aktiv.
  let categoryManagerEscHandler = null;

  function closeCategoryManager() {
    if (categoryManagerEscHandler) {
      document.removeEventListener("keydown", categoryManagerEscHandler, true);
      categoryManagerEscHandler = null;
    }
    document.querySelectorAll(".zh-category-modal-backdrop").forEach((element) => element.remove());
  }

  function autoSizeCategoryKeywords(textarea) {
    if (!textarea) return;
    textarea.style.height = "auto";
    textarea.style.height = `${Math.min(Math.max(textarea.scrollHeight, 30), 140)}px`;
  }

  function createCategoryEditorRow(group, keywords) {
    const row = document.createElement("div");
    row.className = "zh-category-editor-row";
    row.dataset.categoryId = group.id;

    const order = document.createElement("div");
    order.className = "zh-category-editor-order";
    order.textContent = String(group.order);

    const title = document.createElement("input");
    title.name = "title";
    title.value = group.title;
    title.placeholder = "Titel";

    const short = document.createElement("input");
    short.name = "short";
    short.value = group.short;
    short.placeholder = "Kurz";

    const color = document.createElement("input");
    color.name = "color";
    color.type = "color";
    color.value = /^#[0-9a-f]{6}$/i.test(group.color) ? group.color : "#eeeeee";
    color.disabled = group.id === "";

    const keywordBox = document.createElement("textarea");
    keywordBox.name = "keywords";
    keywordBox.value = (keywords[group.id] || []).join(", ");
    keywordBox.placeholder = "Keywords, getrennt mit Komma oder Zeile";
    keywordBox.disabled = group.id === "";
    keywordBox.addEventListener("input", () => autoSizeCategoryKeywords(keywordBox));

    const actions = document.createElement("div");
    actions.className = "zh-category-editor-actions";

    const up = document.createElement("button");
    up.type = "button";
    up.textContent = "Hoch";
    up.dataset.action = "up";
    up.disabled = group.id === "";
    up.title = "Höhere Priorität bei der automatischen Erkennung";

    const down = document.createElement("button");
    down.type = "button";
    down.textContent = "Runter";
    down.dataset.action = "down";
    down.disabled = group.id === "";
    down.title = "Niedrigere Priorität bei der automatischen Erkennung";

    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "Loeschen";
    remove.dataset.action = "remove";
    remove.disabled = group.id === "";

    actions.append(up, down, remove);
    row.append(order, title, short, color, keywordBox, actions);
    return row;
  }

  function readCategoryManagerRows(container) {
    const groups = [];
    const keywords = {};

    [...container.querySelectorAll(".zh-category-editor-row[data-category-id]")].forEach((row, index) => {
      const oldId = row.dataset.categoryId;
      const title = row.querySelector('[name="title"]').value.trim() || "Kategorie";
      const short = row.querySelector('[name="short"]').value.trim() || title;
      const id = oldId === "" ? "" : normalizeCategoryId(oldId || short || title);
      const color = oldId === "" ? "" : row.querySelector('[name="color"]').value;
      const words = row.querySelector('[name="keywords"]').value
        .split(/[\n,]+/)
        .map((word) => word.trim())
        .filter(Boolean);

      groups.push({
        id,
        title,
        short,
        color,
        order: index + 1
      });
      keywords[id] = words;
    });

    return normalizeCategoryConfig({ groups, keywords });
  }

  function renderCategoryManagerRows(list) {
    list.innerHTML = "";

    const hint = document.createElement("div");
    hint.className = "zh-category-editor-hint";
    hint.textContent = "Die Reihenfolge (Hoch/Runter) bestimmt auch die Priorität bei der automatischen Erkennung: Passt der Text auf mehrere Kategorien, gewinnt die weiter oben stehende.";
    list.appendChild(hint);

    const groups = getCategoryGroups();
    const keywords = getCategoryKeywords();
    groups.forEach((group) => {
      const row = createCategoryEditorRow(group, keywords);
      list.appendChild(row);
      autoSizeCategoryKeywords(row.querySelector('[name="keywords"]'));
    });
  }

  function openCategoryManager() {
    closeCategoryManager();

    const backdrop = document.createElement("div");
    backdrop.className = "zh-category-modal-backdrop";

    const modal = document.createElement("div");
    modal.className = "zh-category-modal";

    const header = document.createElement("header");
    const title = document.createElement("h2");
    title.textContent = "Ticket-Kategorien bearbeiten";
    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.textContent = "Schließen";
    closeButton.addEventListener("click", closeCategoryManager);
    header.append(title, closeButton);

    const body = document.createElement("div");
    body.className = "zh-category-modal-body";
    const list = document.createElement("div");
    body.appendChild(list);

    const footer = document.createElement("footer");
    const leftActions = document.createElement("div");
    const rightActions = document.createElement("div");

    const addButton = document.createElement("button");
    addButton.type = "button";
    addButton.textContent = "Kategorie hinzufügen";
    addButton.addEventListener("click", () => {
      const current = readCategoryManagerRows(list);
      const nextId = `kategorie-${Date.now()}`;
      current.groups.push({
        id: nextId,
        title: "Neue Kategorie",
        short: "Neu",
        color: "#eeeeee",
        order: current.groups.length + 1
      });
      categoryConfig = normalizeCategoryConfig(current);
      saveCategoryConfig();
      renderCategoryManagerRows(list);
    });

    const resetButton = document.createElement("button");
    resetButton.type = "button";
    resetButton.textContent = "Standard wiederherstellen";
    resetButton.addEventListener("click", () => {
      categoryConfig = normalizeCategoryConfig({ groups: DEFAULT_GROUPS, keywords: DEFAULT_KEYWORDS });
      saveCategoryConfig();
      renderCategoryManagerRows(list);
    });

    const exportButton = document.createElement("button");
    exportButton.type = "button";
    exportButton.textContent = "Exportieren";
    exportButton.title = "Kategorien als Datei speichern, um sie zu teilen";
    exportButton.addEventListener("click", () => {
      categoryConfig = readCategoryManagerRows(list);
      downloadJsonFile("znuny-helper-kategorien.json", categoryConfig);
    });

    const importButton = document.createElement("button");
    importButton.type = "button";
    importButton.textContent = "Importieren";
    importButton.title = "Kategorien aus einer Datei laden";
    importButton.addEventListener("click", () => {
      importJsonFile((data) => {
        if (!data || !Array.isArray(data.groups)) {
          window.alert("Diese Datei enthält keine gültigen Ticket-Kategorien.");
          return;
        }

        categoryConfig = normalizeCategoryConfig(data);
        renderCategoryManagerRows(list);
      });
    });

    const saveButton = document.createElement("button");
    saveButton.type = "button";
    saveButton.textContent = "Speichern";
    saveButton.addEventListener("click", () => {
      categoryConfig = readCategoryManagerRows(list);
      saveCategoryConfig();
      closeCategoryManager();
      disableTicketCategories();
      applyTicketCategories();
    });

    leftActions.append(addButton, resetButton, exportButton, importButton);
    rightActions.append(saveButton);
    footer.append(leftActions, rightActions);

    list.addEventListener("click", (event) => {
      const button = event.target.closest("button[data-action]");
      if (!button) return;

      stopEvent(event);
      categoryConfig = readCategoryManagerRows(list);
      const row = button.closest(".zh-category-editor-row");
      const id = row?.dataset.categoryId;
      const index = categoryConfig.groups.findIndex((group) => group.id === id);

      if (index < 0) return;

      if (button.dataset.action === "remove") {
        categoryConfig.groups.splice(index, 1);
        delete categoryConfig.keywords[id];
      } else if (button.dataset.action === "up" && index > 1) {
        [categoryConfig.groups[index - 1], categoryConfig.groups[index]] = [categoryConfig.groups[index], categoryConfig.groups[index - 1]];
      } else if (button.dataset.action === "down" && index < categoryConfig.groups.length - 1) {
        [categoryConfig.groups[index + 1], categoryConfig.groups[index]] = [categoryConfig.groups[index], categoryConfig.groups[index + 1]];
      }

      categoryConfig.groups.forEach((group, groupIndex) => {
        group.order = groupIndex + 1;
      });
      saveCategoryConfig();
      renderCategoryManagerRows(list);
    });

    // Field edits (name, short name, colour, keywords) are persisted right away,
    // so closing the editor can no longer discard them.
    list.addEventListener("change", () => {
      categoryConfig = readCategoryManagerRows(list);
      saveCategoryConfig();
    });

    modal.append(header, body, footer);
    backdrop.appendChild(modal);
    backdrop.addEventListener("click", (event) => {
      if (event.target === backdrop) closeCategoryManager();
    });
    document.body.appendChild(backdrop);
    renderCategoryManagerRows(list);

    categoryManagerEscHandler = (event) => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      event.stopPropagation();
      closeCategoryManager();
    };
    document.addEventListener("keydown", categoryManagerEscHandler, true);
  }

  function applyTicketCategories() {
    if (!isCategoryTicketListPage()) {
      disableTicketCategories();
      return;
    }

    const table = findCategoryTable();
    if (!table) return;

    addTicketCategoryStyles();
    ensureCategoryManageButton(table);

    const indexes = getIndexes(table);
    indexes.case = resolveTicketColumnIndex(table, indexes);
    const tbody = table.querySelector("tbody");
    if (!tbody || indexes.case < 0) return;

    removeGroupHeaders(tbody);

    const rows = [...tbody.querySelectorAll("tr")]
      .filter((row) => !row.classList.contains("zh-group-header"));

    rows.forEach((row, index) => {
      if (!row.dataset.zhOriginalIndex) row.dataset.zhOriginalIndex = String(index);
    });

    const groups = getCategoryGroups();

    rows.forEach((row) => {
      decorateCaseCell(row, indexes);
      decorateAgeCell(row, indexes);

      const ticketId = getTicketId(row, indexes);
      const caseCell = row.querySelectorAll("td")[indexes.case];
      const effectiveCategory = getEffectiveCategory(row, indexes);
      const manualCategory = getManualCategory(ticketId);
      const group = groups.find((item) => item.id === effectiveCategory) || groups[0];

      const textColor = group.color ? getReadableTextColor(group.color) : "";
      setProtectedFill(caseCell, group.color);
      caseCell.style.fontWeight = "";
      caseCell.style.color = textColor;

      const badge = caseCell.querySelector(".zh-badge");
      const select = caseCell.querySelector(".zh-category-select");
      const noteButton = caseCell.querySelector(".zh-note-btn");
      const isAuto = manualCategory === null;

      if (badge) {
        const marker = isAuto && group.id ? " (Vorschlag)" : "";
        badge.textContent = (group.id ? group.short : "Keine") + marker;
        setProtectedFill(badge, group.color || "#eeeeee");
        badge.style.color = group.color ? getReadableTextColor(group.color) : "#111";
        badge.classList.toggle("zh-badge-auto", isAuto && Boolean(group.id));
        badge.title = isAuto
          ? "Automatisch erkannt - ungeprüfter Vorschlag. Zum Bestätigen/Ändern die Auswahl nutzen."
          : "Manuell gesetzt";
      }

      if (select) {
        select.value = isAuto ? "__auto" : manualCategory;
        select.title = isAuto ? "Auto-Erkennung aktiv (Vorschlag)" : "Manuell gesetzt";
      }

      if (noteButton) {
        const note = ticketState.notes[ticketId] || "";
        noteButton.classList.toggle("has-note", Boolean(note));
        noteButton.title = note ? `Notiz: ${note}` : "Lokale Notiz";
      }

      row.classList.toggle("zh-row-starred", isStarred(row, indexes));

      row.style.display = "";
    });

    rows.forEach((row) => tbody.appendChild(row));
  }

  function disableTicketCategories() {
    closeAllNotePopups();
    closeCategoryManager();
    removeStyle("zh-ticket-category-style");
    document.getElementById("zh-toolbar")?.remove();
    document.querySelectorAll(".zh-category-tools").forEach((element) => element.remove());

    const table = findCategoryTable();
    const tbody = table?.querySelector("tbody");
    if (!tbody) return;

    removeGroupHeaders(tbody);

    [...tbody.querySelectorAll("tr")]
      .sort((a, b) => Number(a.dataset.zhOriginalIndex || 0) - Number(b.dataset.zhOriginalIndex || 0))
      .forEach((row) => {
        row.style.display = "";
        row.classList.remove("zh-row-starred");

        row.querySelectorAll(".zh-age-warn, .zh-age-hot, .zh-age-old").forEach((cell) => {
          cell.classList.remove("zh-age-warn", "zh-age-hot", "zh-age-old");
        });

        row.querySelectorAll(".zh-cat-ui, .zh-note-wrap").forEach((element) => element.remove());

        row.querySelectorAll("[data-zh-original-background]").forEach((cell) => {
          cell.style.background = cell.dataset.zhOriginalBackground || "";
          cell.style.backgroundImage = "";
          cell.style.fontWeight = cell.dataset.zhOriginalFontWeight || "";
          cell.style.color = "";
        });

        tbody.appendChild(row);
      });
  }

  function quickReplyDraftKey(url) {
    const decoded = decodeUrlSeparators(url);
    const action = decoded.match(/[?;&]Action=([A-Za-z0-9_]+)/i)?.[1] || "";
    const ticket = decoded.match(/[?;&](?:TicketID|TicketNumber)=(\d+)/i)?.[1] || "";
    return action && ticket ? `${action}|${ticket}` : "";
  }

  function normalizeQuickReplyDrafts(value, limit = QUICK_REPLY_DRAFT_LIMIT) {
    const entries = Object.entries(value && typeof value === "object" ? value : {})
      .filter(([, draft]) => draft && typeof draft.text === "string" && draft.text.trim())
      .map(([key, draft]) => {
        const html = typeof draft.html === "string" ? draft.html.trim().slice(0, 20000) : "";
        const entry = { text: String(draft.text), savedAt: Number(draft.savedAt) || 0 };
        if (html) entry.html = html;
        return [key, entry];
      })
      .sort((left, right) => right[1].savedAt - left[1].savedAt)
      .slice(0, limit);

    return Object.fromEntries(entries);
  }

  async function loadQuickReplyDrafts() {
    const stored = await syncGet("local", { [QUICK_REPLY_DRAFT_KEY]: null });
    quickReplyDrafts = normalizeQuickReplyDrafts(stored[QUICK_REPLY_DRAFT_KEY]);
  }

  function persistQuickReplyDrafts() {
    quickReplyDrafts = normalizeQuickReplyDrafts(quickReplyDrafts);
    syncSet("local", { [QUICK_REPLY_DRAFT_KEY]: quickReplyDrafts });
  }

  function getQuickReplyDraft(url) {
    const key = quickReplyDraftKey(url);
    return key ? quickReplyDrafts[key] || null : null;
  }

  function dropQuickReplyDraft(url) {
    const key = quickReplyDraftKey(url);
    if (!key || !quickReplyDrafts[key]) return;
    delete quickReplyDrafts[key];
    persistQuickReplyDrafts();
  }

  function findQuickReplyEditor(doc) {
    const row = findPriorityFieldSection(["Text"], doc);
    const textarea = [...(row?.querySelectorAll("textarea") || [])].find((control) => {
      const signature = `${control.name || ""} ${control.id || ""}`.toLowerCase();
      return /richtext|body|article|text/.test(signature);
    });

    const editable = row?.querySelector?.("[contenteditable='true']") ||
      doc.querySelector(".cke_editable[contenteditable='true'], [contenteditable='true']");

    let body = null;
    try {
      const iframe = row?.querySelector?.("iframe") || doc.querySelector(".cke_wysiwyg_frame, iframe");
      body = iframe?.contentDocument?.body || null;
    } catch (error) {
      body = null;
    }

    return { textarea: textarea || null, editable: editable || null, body };
  }

  // A draft is stored in two shapes: the editor's own HTML (keeps paragraphs, lists,
  // bold and the signature) and the plain text (used to tell "empty" from "written" and
  // as the fallback for drafts from older versions).
  function readQuickReplyHtml(doc) {
    const editor = findQuickReplyEditor(doc);
    const rich = [editor.editable, editor.body].filter(Boolean);

    for (const element of rich) {
      const html = String(element.innerHTML || "").trim();
      if (html) return html;
    }

    return "";
  }

  // The stored HTML comes from the agent's own editor, but it is written back into the
  // page - so scripts, inline handlers and javascript: URLs are removed first.
  function sanitizeDraftHtml(html) {
    return String(html || "")
      .replace(/<\s*(script|style|iframe|object|embed)\b[\s\S]*?<\s*\/\s*\1\s*>/gi, "")
      .replace(/<\s*(script|style|iframe|object|embed)\b[^>]*>/gi, "")
      .replace(/\son[a-z]+\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi, "")
      .replace(/(href|src)\s*=\s*(["'])\s*javascript:[^"']*\2/gi, "$1=\"#\"");
  }

  function insertQuickReplyHtml(doc, html) {
    const editor = findQuickReplyEditor(doc);
    const target = editor.editable || editor.body;
    if (!target || !html) return false;

    target.innerHTML = sanitizeDraftHtml(html);
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function readQuickReplyText(doc) {
    const editor = findQuickReplyEditor(doc);

    // The visible editor is authoritative: CKEditor only syncs its textarea on submit,
    // so that textarea can still hold the original (usually empty) text and must not
    // win over what the agent actually typed. Both rich variants are checked, because
    // which one carries the text differs between browsers and editor modes.
    const rich = [editor.editable, editor.body].filter(Boolean);

    if (rich.length) {
      const filled = rich
        .map((element) => String(element.innerText || ""))
        .find((text) => text.trim());

      return String(filled || "").replace(/\r\n?/g, "\n");
    }

    return String(editor.textarea?.value || "").replace(/\r\n?/g, "\n");
  }

  // Drafts are kept as plain text: the editor formatting is not preserved, but what
  // was written survives closing the drawer (and leaving the page).
  function writeQuickReplyText(doc, text) {
    const editor = findQuickReplyEditor(doc);

    if (editor.editable) {
      insertPlainTextAsParagraphs(editor.editable, text);
      return true;
    }

    if (editor.body) {
      insertPlainTextAsParagraphs(editor.body, text);
      return true;
    }

    if (editor.textarea) {
      editor.textarea.value = text;
      editor.textarea.dispatchEvent(new Event("input", { bubbles: true }));
      editor.textarea.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }

    return false;
  }

  // Puts plain text back as real paragraphs instead of loose text with <br> in between:
  // the rich text editors Znuny uses keep their structure then, and line breaks or
  // paragraphs are not squeezed together by the editor's own clean-up. Used for restored
  // drafts and for template text.
  function insertPlainTextAsParagraphs(target, text) {
    const doc = target.ownerDocument || document;
    const lines = String(text || "").replace(/\r\n?/g, "\n").split("\n");
    const fragment = doc.createDocumentFragment();
    let paragraph = doc.createElement("p");

    lines.forEach((line) => {
      if (!line.trim()) {
        // An empty line separates two paragraphs.
        paragraph.appendChild(doc.createElement("br"));
        fragment.appendChild(paragraph);
        paragraph = doc.createElement("p");
        return;
      }

      if (paragraph.childNodes.length) paragraph.appendChild(doc.createElement("br"));
      paragraph.appendChild(doc.createTextNode(line));
    });

    fragment.appendChild(paragraph);
    target.replaceChildren(fragment);
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("change", { bubbles: true }));
  }

  // Editor "source" (HTML) that ended up in a draft - from an older version or from a
  // source-mode editor - must never be reinserted as literal markup. It is converted to
  // readable plain text instead.
  function looksLikeEditorMarkup(text) {
    return /<(?:br|p|div|span|a|b|i|u|strong|em|ul|ol|li|table|tr|td|h[1-6])\b[^>]*>/i.test(text) ||
      /&nbsp;/i.test(text);
  }

  function toPlainDraftText(text) {
    // Line endings are normalised for every draft: Firefox editors report \r\n, and a
    // stray \r makes the editor collapse the line breaks when the draft comes back.
    const raw = String(text || "").replace(/\r\n?/g, "\n");
    if (!looksLikeEditorMarkup(raw)) return raw;

    try {
      const prepared = raw
        .replace(/<br\s*\/?>/gi, "\n")
        .replace(/<\/(?:p|div|li|tr|h[1-6])>/gi, "\n");
      const parsed = new DOMParser().parseFromString(prepared, "text/html");
      const plain = parsed.body?.textContent || "";

      return plain
        .replace(/\u00a0/g, " ")
        .replace(/[ \t]+\n/g, "\n")
        .replace(/\n{3,}/g, "\n\n")
        .trim();
    } catch (error) {
      return raw.trim();
    }
  }

  function logQuickReplyDraft(message, detail) {
    // Deliberately visible: drafts are hard to verify without looking into the editor
    // inside the drawer, so the reason is logged for support cases.
    console.info(`Znuny Helper: ${message}`, detail);
  }

  function getQuickReplyDocument(drawer) {
    try {
      return drawer?.querySelector(".zh-quick-reply-frame")?.contentDocument || null;
    } catch (error) {
      return null;
    }
  }

  function saveQuickReplyDraftFromDrawer(drawer) {
    const url = drawer?.dataset.zhQuickReplyUrl || "";
    const key = quickReplyDraftKey(url);
    if (!key) return;

    const doc = getQuickReplyDocument(drawer);
    if (!doc) {
      logQuickReplyDraft("Entwurf nicht gespeichert: Formular nicht lesbar", { key });
      return;
    }

    const text = toPlainDraftText(readQuickReplyText(doc)).trim();
    const html = readQuickReplyHtml(doc);
    const stored = quickReplyDrafts[key];

    if (!text) {
      if (stored) {
        dropQuickReplyDraft(url);
        logQuickReplyDraft("Entwurf verworfen: Editor ist leer", { key });
      }
      return;
    }

    // The editor's own markup is kept as well, so paragraphs, lists, bold text and the
    // signature survive the round trip. Without markup the plain text is enough.
    const keepHtml = looksLikeEditorMarkup(html) ? html : "";

    if (stored?.text === text && String(stored?.html || "") === keepHtml) return;

    quickReplyDrafts[key] = keepHtml
      ? { text, html: keepHtml, savedAt: Date.now() }
      : { text, savedAt: Date.now() };

    persistQuickReplyDrafts();
    logQuickReplyDraft("Entwurf gespeichert", {
      key,
      zeichen: text.length,
      formatierung: keepHtml ? "mit" : "ohne"
    });
  }

  const QUICK_REPLY_RESIZE_DIRECTIONS = ["n", "s", "e", "w", "ne", "nw", "se", "sw"];

  // Eight handles along the edges and corners, so the window can be resized like a
  // real window instead of only through the small native corner grip.
  function bindQuickReplyResizers(drawer) {
    QUICK_REPLY_RESIZE_DIRECTIONS.forEach((direction) => {
      const handle = document.createElement("div");
      handle.className = `zh-quick-reply-resizer zh-quick-reply-resizer-${direction}`;

      handle.addEventListener("pointerdown", (event) => {
        if (event.button > 0 || quickReplyLayout.maximized) return;
        if (drawer.classList.contains("zh-quick-reply-minimized")) return;

        const rect = drawer.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;

        handle.setPointerCapture?.(event.pointerId);

        const onMove = (moveEvent) => {
          const dx = moveEvent.clientX - startX;
          const dy = moveEvent.clientY - startY;

          let left = rect.left;
          let top = rect.top;
          let width = rect.width;
          let height = rect.height;

          if (direction.includes("e")) width = rect.width + dx;
          if (direction.includes("s")) height = rect.height + dy;
          if (direction.includes("w")) {
            width = rect.width - dx;
            left = rect.left + dx;
          }
          if (direction.includes("n")) {
            height = rect.height - dy;
            top = rect.top + dy;
          }

          if (width < QUICK_REPLY_MIN_WIDTH) {
            if (direction.includes("w")) left -= QUICK_REPLY_MIN_WIDTH - width;
            width = QUICK_REPLY_MIN_WIDTH;
          }
          if (height < QUICK_REPLY_MIN_HEIGHT) {
            if (direction.includes("n")) top -= QUICK_REPLY_MIN_HEIGHT - height;
            height = QUICK_REPLY_MIN_HEIGHT;
          }

          if (left < 0) {
            width += left;
            left = 0;
          }
          if (top < 0) {
            height += top;
            top = 0;
          }

          width = Math.min(width, window.innerWidth - left);
          height = Math.min(height, window.innerHeight - top);

          drawer.style.left = `${Math.round(left)}px`;
          drawer.style.top = `${Math.round(top)}px`;
          drawer.style.width = `${Math.round(width)}px`;
          drawer.style.height = `${Math.round(height)}px`;
          drawer.dataset.zhResized = "1";
          if (direction.includes("w") || direction.includes("n")) drawer.dataset.zhMoved = "1";
        };

        const onUp = () => {
          handle.removeEventListener("pointermove", onMove);
          handle.removeEventListener("pointerup", onUp);
          handle.removeEventListener("pointercancel", onUp);
          drawer.classList.remove("zh-quick-reply-resizing");
          persistQuickReplyGeometry(drawer);
        };

        drawer.classList.add("zh-quick-reply-resizing");
        handle.addEventListener("pointermove", onMove);
        handle.addEventListener("pointerup", onUp);
        handle.addEventListener("pointercancel", onUp);
        event.preventDefault();
      });

      drawer.appendChild(handle);
    });
  }

  let quickReplyPollTimer = null;
  let quickReplyLayoutSaveTimer = 0;

  const QUICK_REPLY_MIN_WIDTH = 420;
  const QUICK_REPLY_MIN_HEIGHT = 300;

  function normalizeQuickReplyLayout(layout) {
    const width = Math.round(Number(layout?.width) || 0);
    const height = Math.round(Number(layout?.height) || 0);
    const rawLeft = layout?.left;
    const rawTop = layout?.top;
    const left = rawLeft === null || rawLeft === undefined ? null : Math.round(Number(rawLeft));
    const top = rawTop === null || rawTop === undefined ? null : Math.round(Number(rawTop));

    return {
      width: width >= QUICK_REPLY_MIN_WIDTH ? width : 0,
      height: height >= QUICK_REPLY_MIN_HEIGHT ? height : 0,
      left: Number.isFinite(left) ? left : null,
      top: Number.isFinite(top) ? top : null,
      maximized: Boolean(layout?.maximized)
    };
  }

  function saveQuickReplyLayout() {
    if (quickReplyLayoutSaveTimer) window.clearTimeout(quickReplyLayoutSaveTimer);
    quickReplyLayoutSaveTimer = window.setTimeout(() => {
      quickReplyLayoutSaveTimer = 0;
      syncSet("local", { [QUICK_REPLY_LAYOUT_KEY]: quickReplyLayout });
    }, 400);
  }

  function clampNumber(value, min, max) {
    return Math.min(Math.max(value, min), Math.max(min, max));
  }

  function isEditableQuickReplyTarget(target) {
    const tag = String(target?.tagName || "").toUpperCase();
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return true;
    return Boolean(target?.isContentEditable);
  }

  // Zero width/height and null coordinates mean "use the default position"
  // (bottom right), so a stored layout only takes over once the user has actually
  // resized or moved the window.
  function applyQuickReplyLayout(drawer) {
    const availableWidth = Math.max(QUICK_REPLY_MIN_WIDTH, window.innerWidth - 16);
    const availableHeight = Math.max(QUICK_REPLY_MIN_HEIGHT, window.innerHeight - 16);

    drawer.style.right = "auto";
    drawer.style.bottom = "auto";

    if (quickReplyLayout.maximized) {
      drawer.classList.add("zh-quick-reply-maximized");
      drawer.style.left = "8px";
      drawer.style.top = "8px";
      drawer.style.width = `${availableWidth - 8}px`;
      drawer.style.height = `${availableHeight - 8}px`;
      return;
    }

    drawer.classList.remove("zh-quick-reply-maximized");

    const width = Math.min(quickReplyLayout.width || Math.min(960, availableWidth), availableWidth);
    const height = Math.min(quickReplyLayout.height || Math.min(720, availableHeight), availableHeight);
    const left = quickReplyLayout.left === null
      ? Math.max(8, window.innerWidth - width - 16)
      : clampNumber(quickReplyLayout.left, 0, window.innerWidth - 80);
    const top = quickReplyLayout.top === null
      ? Math.max(8, window.innerHeight - height - 12)
      : clampNumber(quickReplyLayout.top, 0, window.innerHeight - 60);

    drawer.style.left = `${left}px`;
    drawer.style.top = `${top}px`;
    drawer.style.width = `${width}px`;
    drawer.style.height = `${height}px`;
  }

  function persistQuickReplyGeometry(drawer) {
    if (!drawer || quickReplyLayout.maximized) return;
    // While minimised the element is only a title bar - that size must not be stored.
    if (drawer.classList.contains("zh-quick-reply-minimized")) return;

    const rect = drawer.getBoundingClientRect();
    if (rect.width < QUICK_REPLY_MIN_WIDTH || rect.height < QUICK_REPLY_MIN_HEIGHT) return;

    let changed = false;

    if (drawer.dataset.zhResized === "1") {
      quickReplyLayout.width = Math.round(rect.width);
      quickReplyLayout.height = Math.round(rect.height);
      changed = true;
    }

    if (drawer.dataset.zhMoved === "1") {
      quickReplyLayout.left = Math.round(rect.left);
      quickReplyLayout.top = Math.round(rect.top);
      changed = true;
    }

    if (changed) saveQuickReplyLayout();
  }

  function resetQuickReplyLayout(drawer) {
    quickReplyLayout = { width: 0, height: 0, left: null, top: null, maximized: false };

    if (quickReplyLayoutSaveTimer) {
      window.clearTimeout(quickReplyLayoutSaveTimer);
      quickReplyLayoutSaveTimer = 0;
    }
    syncSet("local", { [QUICK_REPLY_LAYOUT_KEY]: quickReplyLayout });

    delete drawer.dataset.zhMoved;
    delete drawer.dataset.zhResized;
    applyQuickReplyLayout(drawer);
  }

  // Move by dragging the header, resize through the native resize grip, toggle
  // full size by double clicking the header. Size and position are remembered.
  function bindQuickReplyLayout(drawer, header) {
    applyQuickReplyLayout(drawer);

    header.addEventListener("pointerdown", (event) => {
      if (quickReplyLayout.maximized) return;
      if (event.button > 0 || event.target?.closest?.("button")) return;

      const rect = drawer.getBoundingClientRect();
      const startX = event.clientX;
      const startY = event.clientY;
      const startLeft = rect.left;
      const startTop = rect.top;

      const onMove = (moveEvent) => {
        // Moving switches from the default bottom-right anchor to fixed coordinates.
        drawer.style.left = `${clampNumber(startLeft + moveEvent.clientX - startX, 0, window.innerWidth - 80)}px`;
        drawer.style.top = `${clampNumber(startTop + moveEvent.clientY - startY, 0, window.innerHeight - 60)}px`;
        drawer.dataset.zhMoved = "1";
      };

      const onUp = () => {
        header.removeEventListener("pointermove", onMove);
        header.removeEventListener("pointerup", onUp);
        header.removeEventListener("pointercancel", onUp);
        header.classList.remove("zh-quick-reply-dragging");
        persistQuickReplyGeometry(drawer);
      };

      header.classList.add("zh-quick-reply-dragging");
      header.addEventListener("pointermove", onMove);
      header.addEventListener("pointerup", onUp);
      header.addEventListener("pointercancel", onUp);
      event.preventDefault();
    });

    header.addEventListener("dblclick", (event) => {
      if (event.target?.closest?.("button")) return;
      quickReplyLayout.maximized = !quickReplyLayout.maximized;
      applyQuickReplyLayout(drawer);
      saveQuickReplyLayout();
    });

    if (typeof ResizeObserver !== "undefined") {
      let initialObservation = true;
      const observer = new ResizeObserver(() => {
        // The first callback reports the initial size; that is not a user resize.
        if (initialObservation) {
          initialObservation = false;
          return;
        }
        drawer.dataset.zhResized = "1";
        persistQuickReplyGeometry(drawer);
      });
      observer.observe(drawer);
      drawer.__zhResizeObserver = observer;
    }

    const onWindowResize = () => applyQuickReplyLayout(drawer);
    window.addEventListener("resize", onWindowResize);
    drawer.__zhWindowResizeHandler = onWindowResize;
  }

  function handleQuickReplyEscape(event) {
    if (event.key !== "Escape") return;
    // Do not steal Escape from a field the agent is editing.
    if (isEditableQuickReplyTarget(event.target)) return;
    closeQuickReplyDrawer();
  }

  function closeQuickReplyDrawer(options = {}) {
    const { saveDraft = true } = options;

    if (quickReplyPollTimer) {
      window.clearInterval(quickReplyPollTimer);
      quickReplyPollTimer = null;
    }

    const drawer = document.getElementById("zh-quick-reply-drawer");

    if (drawer) {
      // Keep an unfinished reply so it can be restored the next time this action is
      // opened for the same ticket.
      if (saveDraft) saveQuickReplyDraftFromDrawer(drawer);

      persistQuickReplyGeometry(drawer);
      drawer.__zhResizeObserver?.disconnect();
      if (drawer.__zhWindowResizeHandler) {
        window.removeEventListener("resize", drawer.__zhWindowResizeHandler);
      }
      if (drawer.__zhPagehideHandler) {
        window.removeEventListener("pagehide", drawer.__zhPagehideHandler);
      }
      drawer.remove();
    }

    document.removeEventListener("keydown", handleQuickReplyEscape, true);
  }

  function getQuickReplyIframeHref(iframe) {
    try {
      return iframe.contentWindow?.location?.href || "";
    } catch (error) {
      return "";
    }
  }

  function addQuickReplyStyles() {
    addStyle("zh-quick-reply-style", `
      #zh-quick-reply-drawer {
        position: fixed;
        right: 16px;
        bottom: 0;
        width: min(960px, 94vw);
        height: min(720px, 88vh);
        min-width: 420px;
        min-height: 300px;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 10px 40px rgba(0,0,0,.35);
        z-index: 999998;
        display: flex;
        flex-direction: column;
        overflow: hidden;
        border: 1px solid rgba(0,0,0,.15);
      }
      #zh-quick-reply-drawer.zh-quick-reply-resizing,
      #zh-quick-reply-drawer.zh-quick-reply-resizing * { user-select: none; }
      .zh-quick-reply-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 8px 12px;
        background: #f2f2f2;
        border-bottom: 1px solid rgba(0,0,0,.1);
        font-size: 13px;
        color: #222;
        cursor: move;
        user-select: none;
        touch-action: none;
      }
      .zh-quick-reply-header.zh-quick-reply-dragging { cursor: grabbing; }
      .zh-quick-reply-title { white-space: nowrap; }
      .zh-quick-reply-hint {
        flex: 1;
        text-align: right;
        font-size: 11px;
        color: #6b6b6b;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .zh-quick-reply-actions { display: flex; align-items: center; gap: 6px; }
      .zh-quick-reply-reset,
      .zh-quick-reply-close {
        font-size: 12px;
        font-weight: 700;
        padding: 4px 10px;
        border: 1px solid #999;
        border-radius: 999px;
        background: #eee;
        color: #111;
        cursor: pointer;
        white-space: nowrap;
      }
      .zh-quick-reply-reset { font-weight: 400; padding: 4px 9px; }
      .zh-quick-reply-reset:hover,
      .zh-quick-reply-close:hover { background: #fff; }
      .zh-quick-reply-frame {
        flex: 1;
        width: 100%;
        border: 0;
        background: #fff;
      }
      @media (max-width: 760px) {
        .zh-quick-reply-hint { display: none; }
      }
      .zh-quick-reply-resizer { position: absolute; z-index: 6; }
      .zh-quick-reply-resizer-n { top: 0; left: 12px; right: 12px; height: 6px; cursor: ns-resize; }
      .zh-quick-reply-resizer-s { bottom: 0; left: 12px; right: 12px; height: 6px; cursor: ns-resize; }
      .zh-quick-reply-resizer-w { left: 0; top: 12px; bottom: 12px; width: 6px; cursor: ew-resize; }
      .zh-quick-reply-resizer-e { right: 0; top: 12px; bottom: 12px; width: 6px; cursor: ew-resize; }
      .zh-quick-reply-resizer-nw { top: 0; left: 0; width: 14px; height: 14px; cursor: nwse-resize; }
      .zh-quick-reply-resizer-ne { top: 0; right: 0; width: 14px; height: 14px; cursor: nesw-resize; }
      .zh-quick-reply-resizer-sw { bottom: 0; left: 0; width: 14px; height: 14px; cursor: nesw-resize; }
      .zh-quick-reply-resizer-se { bottom: 0; right: 0; width: 14px; height: 14px; cursor: nwse-resize; }
      .zh-quick-reply-draft-note {
        font-size: 11px;
        color: #7a4b00;
        background: #fff3cd;
        border: 1px solid #ffe08a;
        border-radius: 999px;
        padding: 2px 8px;
        white-space: nowrap;
      }
      #zh-quick-reply-drawer.zh-quick-reply-minimized { height: 40px !important; min-height: 40px; }
      #zh-quick-reply-drawer.zh-quick-reply-minimized .zh-quick-reply-frame,
      #zh-quick-reply-drawer.zh-quick-reply-minimized .zh-quick-reply-resizer,
      #zh-quick-reply-drawer.zh-quick-reply-minimized .zh-quick-reply-hint,
      #zh-quick-reply-drawer.zh-quick-reply-minimized .zh-quick-reply-draft-note { display: none; }
    `);
  }

  function isRealQuickReplyHref(href) {
    return Boolean(href) && href !== "about:blank";
  }

  function bindQuickReplyKeyboardShortcut(doc) {
    // Ctrl+Enter is handled by the shared submit shortcut, which is bound to this
    // document here as well - the frame has no content script of its own.
    bindSubmitShortcutToDocument(doc);

    if (!doc || quickReplyShortcutBoundDocuments.has(doc)) return;

    try {
      quickReplyShortcutBoundDocuments.add(doc);
      doc.addEventListener("keydown", (event) => {
        // Escape closes the drawer, but not while a field is being edited.
        if (event.key !== "Escape") return;
        if (isEditableQuickReplyTarget(event.target)) return;

        event.preventDefault();
        closeQuickReplyDrawer();
      }, true);

      doc.querySelectorAll("iframe").forEach((nestedFrame) => {
        try {
          if (nestedFrame.contentDocument) bindQuickReplyKeyboardShortcut(nestedFrame.contentDocument);
        } catch (error) {
          // Cross-origin nested frame; nothing to bind there.
        }
      });
    } catch (error) {
      // Cross-origin document access can fail; nothing to bind in that case.
    }
  }

  function bindQuickReplyCancelLink(doc) {
    doc.querySelectorAll(".CancelClosePopup").forEach((link) => {
      if (link.dataset.zhQuickReplyCancelBound === "1") return;
      link.dataset.zhQuickReplyCancelBound = "1";
      link.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        // Znuny's "Abbrechen und Schließen" means discard, so no draft is kept.
        closeQuickReplyDrawer({ saveDraft: false });
      });
    });
  }

  function getQuickReplyTitle(url) {
    if (/Action=AgentTicketOwner\b/i.test(url)) return "Besitzer ändern";
    if (/Action=AgentTicketPriority\b/i.test(url)) return "Priorisierung";
    if (/Action=AgentTicketForward\b/i.test(url)) return "Weiterleiten";
    if (/Action=AgentTicketNote\b/i.test(url)) return "Notiz hinzufügen";
    if (/Action=AgentTicketClose\b/i.test(url)) return "Ticket schließen";
    if (/Action=AgentTicketMerge\b/i.test(url)) return "Tickets zusammenfassen";
    if (/Action=AgentLinkObject\b/i.test(url)) return "Verknüpfen";
    return "Schnellantwort";
  }

  function openQuickReplyDrawer(url) {
    if (window.top !== window.self) return;

    closeQuickReplyDrawer();
    addQuickReplyStyles();

    const drawer = document.createElement("div");
    drawer.id = "zh-quick-reply-drawer";
    drawer.dataset.zhQuickReplyUrl = url;

    const header = document.createElement("div");
    header.className = "zh-quick-reply-header";
    header.title = "Ziehen zum Verschieben, Doppelklick für Vollbild";

    const title = document.createElement("strong");
    title.className = "zh-quick-reply-title";
    title.textContent = getQuickReplyTitle(url);
    header.appendChild(title);

    const hint = document.createElement("span");
    hint.className = "zh-quick-reply-hint";
    hint.textContent = "Ziehen: verschieben · Ränder: Größe · Doppelklick: Vollbild · Esc: schließen";
    header.appendChild(hint);

    const draftNote = document.createElement("span");
    draftNote.className = "zh-quick-reply-draft-note";
    draftNote.hidden = true;
    header.appendChild(draftNote);

    const actions = document.createElement("div");
    actions.className = "zh-quick-reply-actions";

    const resetButton = document.createElement("button");
    resetButton.type = "button";
    resetButton.className = "zh-quick-reply-reset";
    resetButton.textContent = "Ansicht zurücksetzen";
    resetButton.title = "Gespeicherte Größe und Position verwerfen";
    resetButton.addEventListener("click", () => resetQuickReplyLayout(drawer));
    actions.appendChild(resetButton);

    const minimizeButton = document.createElement("button");
    minimizeButton.type = "button";
    minimizeButton.className = "zh-quick-reply-reset";
    minimizeButton.textContent = "\u2013";
    minimizeButton.title = "Minimieren – der Entwurf bleibt erhalten";
    minimizeButton.addEventListener("click", () => {
      const minimized = drawer.classList.toggle("zh-quick-reply-minimized");
      minimizeButton.textContent = minimized ? "\u25b2" : "\u2013";
      minimizeButton.title = minimized ? "Wieder öffnen" : "Minimieren – der Entwurf bleibt erhalten";

      if (minimized) {
        drawer.style.height = "40px";
      } else {
        applyQuickReplyLayout(drawer);
      }
    });
    actions.appendChild(minimizeButton);

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.className = "zh-quick-reply-close";
    closeButton.textContent = "Schließen";
    closeButton.title = "Fenster schließen – der Entwurf wird gespeichert";
    closeButton.addEventListener("click", closeQuickReplyDrawer);
    actions.appendChild(closeButton);

    header.appendChild(actions);

    drawer.appendChild(header);

    const iframe = document.createElement("iframe");
    iframe.className = "zh-quick-reply-frame";
    drawer.appendChild(iframe);

    document.body.appendChild(drawer);

    bindQuickReplyLayout(drawer, header);
    bindQuickReplyResizers(drawer);
    document.addEventListener("keydown", handleQuickReplyEscape, true);

    // Closing the tab or navigating away with the drawer open must keep the draft too.
    const saveDraftBeforeLeaving = () => {
      if (!document.getElementById("zh-quick-reply-drawer")) return;
      saveQuickReplyDraftFromDrawer(drawer);
    };
    window.addEventListener("pagehide", saveDraftBeforeLeaving);
    drawer.__zhPagehideHandler = saveDraftBeforeLeaving;

    let draftRestored = false;

    const restoreQuickReplyDraft = (doc) => {
      if (draftRestored) return;

      const draft = getQuickReplyDraft(url);
      if (!draft?.text) return;

      // Repairs drafts that an earlier version stored as editor markup.
      const text = toPlainDraftText(draft.text);
      const draftKey = quickReplyDraftKey(url);

      if (text && text !== draft.text) {
        quickReplyDrafts[draftKey] = { text, savedAt: draft.savedAt };
        persistQuickReplyDrafts();
      }

      // Drafts saved by this version keep the editor markup, so formatting ("bold",
      // lists, signature) comes back as it was. Older drafts only have plain text.
      const restored = draft.html
        ? insertQuickReplyHtml(doc, draft.html)
        : false;

      if (!restored && !writeQuickReplyText(doc, text)) {
        logQuickReplyDraft("Entwurf gefunden, aber kein Editor zum Einsetzen", { draftKey });
        return;
      }

      draftRestored = true;
      logQuickReplyDraft("Entwurf wiederhergestellt", {
        draftKey,
        zeichen: text.length,
        formatierung: restored ? "mit" : "ohne"
      });
      const savedAt = new Date(draft.savedAt);
      draftNote.textContent = `Entwurf wiederhergestellt (${savedAt.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" })})`;
      draftNote.hidden = false;

      const discardButton = document.createElement("button");
      discardButton.type = "button";
      discardButton.className = "zh-quick-reply-reset";
      discardButton.textContent = "Entwurf verwerfen";
      discardButton.title = "Gespeicherten Entwurf löschen";
      discardButton.addEventListener("click", () => {
        writeQuickReplyText(doc, "");
        dropQuickReplyDraft(url);
        draftRestored = false;
        draftNote.hidden = true;
        discardButton.remove();
      });
      actions.insertBefore(discardButton, actions.firstChild);
    };

    let actionPageSeen = false;

    const applyQuickReplyDocumentFeatures = () => {
      let doc = null;
      try {
        doc = iframe.contentDocument;
      } catch (error) {
        return;
      }
      if (!doc) return;

      bindQuickReplyKeyboardShortcut(doc);
      if (settings.pendingDateButtons) enablePendingDateQuickButtons(doc);
      if (settings.priorityTemplates) enablePriorityTemplates(doc);
      bindQuickReplyCancelLink(doc);
      expandArticleWidget(doc);
      restoreQuickReplyDraft(doc);
    };

    const refreshQuickReplyPendingDates = () => {
      if (!settings.pendingDateButtons) return;

      let doc = null;
      try {
        doc = iframe.contentDocument;
      } catch (error) {
        return;
      }
      if (!doc) return;

      bindQuickReplyKeyboardShortcut(doc);
      enablePendingDateQuickButtons(doc);
    };

    const retryDocumentFeatures = () => {
      applyQuickReplyDocumentFeatures();
      [150, 600, 1400].forEach((delay) => window.setTimeout(applyQuickReplyDocumentFeatures, delay));

      try {
        const doc = iframe.contentDocument;
        if (doc && !quickReplyChangeBoundDocuments.has(doc)) {
          quickReplyChangeBoundDocuments.add(doc);
          // Reacts when the agent switches "Nächster Status" to a pending
          // state after the form has already loaded (e.g. the date fields
          // only appear once "warten auf ..." is selected).
          doc.addEventListener("change", applyQuickReplyDocumentFeatures, true);
        }
      } catch (error) {
        // Cross-origin document access can fail; nothing to bind in that case.
      }
    };

    const finishQuickReply = () => {
      // The reply was submitted, so there is nothing left to restore.
      dropQuickReplyDraft(url);
      closeQuickReplyDrawer({ saveDraft: false });
      window.location.reload();
    };

    // Both a "load" listener and a poll watch for the iframe leaving the
    // tracked action (successful submit or a redirect back to the ticket);
    // the poll is a fallback in case a JS-driven redirect skips a "load" event.
    iframe.addEventListener("load", () => {
      const href = getQuickReplyIframeHref(iframe);
      if (!isRealQuickReplyHref(href)) return;

      if (QUICK_REPLY_ACTION_PATTERN.test(href)) {
        actionPageSeen = true;
        retryDocumentFeatures();
        return;
      }

      // Zwischenseite desselben Vorgangs (z. B. die Trefferliste der
      // Verknuepfen-Suche): Fenster offen lassen und die eigenen Funktionen
      // auch dort anbieten.
      if (!QUICK_REPLY_FINISHED_PATTERN.test(href)) {
        retryDocumentFeatures();
        return;
      }

      if (actionPageSeen) finishQuickReply();
    });

    quickReplyPollTimer = window.setInterval(() => {
      if (!actionPageSeen) return;

      const href = getQuickReplyIframeHref(iframe);
      if (!isRealQuickReplyHref(href)) return;
      if (QUICK_REPLY_ACTION_PATTERN.test(href)) {
        refreshQuickReplyPendingDates();
        return;
      }

      if (!QUICK_REPLY_FINISHED_PATTERN.test(href)) {
        refreshQuickReplyPendingDates();
        return;
      }

      finishQuickReply();
    }, 700);

    iframe.src = url;
  }

  function handleOpenQuickReplyEvent(event) {
    if (!settings.quickReply) return;

    // Same as with the article actions: the attribute is the transport that always
    // survives the boundary between the page and the content script.
    const url = event.detail?.url || document.documentElement.dataset.zhQuickReplyUrl || "";
    delete document.documentElement.dataset.zhQuickReplyUrl;
    if (!url) return;

    openQuickReplyDrawer(url);
  }

  function enableQuickReply() {
    if (window.top !== window.self) return;
    if (window.__znunyHelperQuickReplyBound === "1") return;
    window.__znunyHelperQuickReplyBound = "1";
    window.addEventListener("znuny-helper-open-quick-reply", handleOpenQuickReplyEvent);
  }

  function disableQuickReply() {
    closeQuickReplyDrawer();
    if (window.__znunyHelperQuickReplyBound === "1") {
      window.removeEventListener("znuny-helper-open-quick-reply", handleOpenQuickReplyEvent);
      delete window.__znunyHelperQuickReplyBound;
    }
    removeStyle("zh-quick-reply-style");
  }

  // The customer portal only gets the local ticket categories: every other feature is
  // built around the agent interface (agent action URLs, priority pages, queue views).
  // Switching the setting off therefore has to clean up here as well.
  function runCustomerPortalFeatures() {
    if (settings.ticketCategories) applyTicketCategories();
    else disableTicketCategories();
  }

  // ---- Weihnachtsmodus ---------------------------------------------------
  // Rein dekorativ und vollstaendig lokal: Schnee (Canvas), Lichterkette,
  // Tannenzweige, Kugeln, Schlitten mit Rentieren und Glitzer als Inline-SVG.
  // Alles liegt in EINEM Overlay mit pointer-events:none - es kann also nichts
  // bedient werden, Klicks gehen immer an Znuny. Bei "prefers-reduced-motion"
  // liegt der Schnee still und die Animationen entfallen.
  const CHRISTMAS_OVERLAY_ID = "zh-christmas";
  const CHRISTMAS_BACK_ID = "zh-christmas-back";
  let christmasCleanupFns = [];

  // Farbverlaeufe und Filter einmal zentral. Alle Teile referenzieren sie
  // ueber url(#...), damit Kugeln, Laempchen und Figuren Plastik bekommen
  // statt flach zu wirken.
  const CHRISTMAS_DEFS = `
    <svg class="zh-xmas-defs" width="0" height="0" aria-hidden="true" focusable="false">
      <defs>
        <radialGradient id="zhXmasBulbWarm" cx="35%" cy="28%" r="75%">
          <stop offset="0%" stop-color="#fffbe8"/><stop offset="45%" stop-color="#ffd479"/><stop offset="100%" stop-color="#e8892b"/>
        </radialGradient>
        <radialGradient id="zhXmasBulbRed" cx="35%" cy="28%" r="75%">
          <stop offset="0%" stop-color="#ffe0da"/><stop offset="45%" stop-color="#ff8a7a"/><stop offset="100%" stop-color="#b3261e"/>
        </radialGradient>
        <radialGradient id="zhXmasBulbGreen" cx="35%" cy="28%" r="75%">
          <stop offset="0%" stop-color="#e6fff2"/><stop offset="45%" stop-color="#7fe0b0"/><stop offset="100%" stop-color="#1f7a4d"/>
        </radialGradient>
        <radialGradient id="zhXmasBaubleRed" cx="32%" cy="26%" r="78%">
          <stop offset="0%" stop-color="#ffb3a8"/><stop offset="40%" stop-color="#d23a2c"/><stop offset="100%" stop-color="#6f1712"/>
        </radialGradient>
        <radialGradient id="zhXmasBaubleGold" cx="32%" cy="26%" r="78%">
          <stop offset="0%" stop-color="#fff6d0"/><stop offset="42%" stop-color="#e8b34b"/><stop offset="100%" stop-color="#8a5c0e"/>
        </radialGradient>
        <linearGradient id="zhXmasTree" x1="0" y1="0" x2="0.7" y2="1">
          <stop offset="0%" stop-color="#4aa173"/><stop offset="55%" stop-color="#236b45"/><stop offset="100%" stop-color="#0f3d24"/>
        </linearGradient>
        <linearGradient id="zhXmasSleigh" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#ef6a5c"/><stop offset="55%" stop-color="#c02f24"/><stop offset="100%" stop-color="#7d160f"/>
        </linearGradient>
        <linearGradient id="zhXmasDeer" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#a06a3c"/><stop offset="60%" stop-color="#7a4a2b"/><stop offset="100%" stop-color="#4d2e1a"/>
        </linearGradient>
        <linearGradient id="zhXmasBeard" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#ffffff"/><stop offset="100%" stop-color="#ded7c8"/>
        </linearGradient>
        <linearGradient id="zhXmasCoat" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#d9433a"/><stop offset="100%" stop-color="#8d1d16"/>
        </linearGradient>
        <filter id="zhXmasGlow" x="-70%" y="-70%" width="240%" height="240%">
          <feGaussianBlur stdDeviation="2.6" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>
    </svg>`;

  // Girlande: wird fuer die AKTUELLE Fensterbreite in Pixeln gebaut (viewBox
  // = Breite), damit nichts gestreckt wird - Kugeln bleiben rund, die
  // Abstaende gleich. Bei Breitenaenderung wird sie neu gezeichnet.
  function christmasGarlandSvg(breite) {
    const spanne = 340;
    const hoehe = 120;
    const wire = [];
    const bulben = [];
    const kugeln = [];
    const zweige = [];

    const aufBogen = (x0, t) => {
      const u = 1 - t;
      return {
        x: u * u * x0 + 2 * u * t * (x0 + spanne / 2) + t * t * (x0 + spanne),
        y: u * u * 10 + 2 * u * t * 62 + t * t * 10
      };
    };

    for (let x0 = -spanne; x0 < breite + spanne; x0 += spanne) {
      const spanIndex = Math.round(x0 / spanne);
      wire.push(
        `<path class="zh-xmas-wire-shadow" d="M${x0},10 Q${x0 + spanne / 2},62 ${x0 + spanne},10" fill="none"/>` +
          `<path class="zh-xmas-wire" d="M${x0},10 Q${x0 + spanne / 2},62 ${x0 + spanne},10" fill="none"/>`
      );

      [0.18, 0.5, 0.82].forEach((t2, i) => {
        const p = aufBogen(x0, t2);
        const farbe = ["Warm", "Red", "Green"][Math.abs(spanIndex * 3 + i) % 3];
        bulben.push(
          `<circle class="zh-xmas-bulb-glow" cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="9"/>` +
            `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4" fill="url(#zhXmasBulb${farbe})"/>`
        );
      });

      [0.34, 0.66].forEach((t2, i) => {
        if (Math.abs(spanIndex * 2 + i) % 3 !== 0) return;
        const p = aufBogen(x0, t2);
        const gold = Math.abs(spanIndex + i) % 2 === 0;
        const name = gold ? "Gold" : "Red";
        const radius = gold ? 10 : 10.5;
        kugeln.push(
          `<line x1="${p.x.toFixed(1)}" y1="${p.y.toFixed(1)}" x2="${p.x.toFixed(1)}" y2="${(p.y + 22).toFixed(1)}" class="zh-xmas-thread"/>` +
            `<rect x="${(p.x - 4).toFixed(1)}" y="${(p.y + 20).toFixed(1)}" width="8" height="5" rx="1.5" class="zh-xmas-cap"/>` +
            `<circle cx="${p.x.toFixed(1)}" cy="${(p.y + 36).toFixed(1)}" r="${radius}" fill="url(#zhXmasBauble${name})"/>` +
            `<ellipse cx="${(p.x - 3.5).toFixed(1)}" cy="${(p.y + 32).toFixed(1)}" rx="3.2" ry="2.3" class="zh-xmas-shine"/>`
        );
      });

      [0.1, 0.44, 0.78].forEach((t2, i) => {
        const p = aufBogen(x0, t2);
        const drehung = ((spanIndex + i) % 2 === 0 ? -7 : 8) + p.y * 0.05;
        zweige.push(
          `<g class="zh-xmas-sprig" transform="translate(${p.x.toFixed(1)},${(p.y + 3).toFixed(1)}) rotate(${drehung.toFixed(1)})">` +
            `<path d="M0,0 C-3,10 -8,19 -15,27 M0,0 C1,12 1,23 -1,33 M0,0 C7,9 14,15 22,19 M0,0 C-9,6 -16,12 -23,15"/>` +
          `</g>`
        );
      });
    }

    return `
      <svg class="zh-xmas-lights" viewBox="0 0 ${Math.round(breite)} ${hoehe}" width="100%" height="${hoehe}" preserveAspectRatio="xMinYMin meet" aria-hidden="true">
        ${wire.join("")}
        ${zweige.join("")}
        <g class="zh-xmas-bulbs">${bulben.join("")}</g>
        <g class="zh-xmas-baubles">${kugeln.join("")}</g>
      </svg>`;
  }

  function renderChristmasGarland(overlay) {
    if (!overlay) return;
    const breite = Math.max(320, window.innerWidth);
    const halter = document.createElement("div");
    halter.innerHTML = christmasGarlandSvg(breite);
    const neu = halter.firstElementChild;
    if (!neu) return;

    const alt = overlay.querySelector(".zh-xmas-lights");
    if (alt) alt.replaceWith(neu);
    else overlay.insertBefore(neu, overlay.firstChild);
  }

  // Mistelzweig im klassischen Motiv: drei gelappte Stechpalmen-Blaetter mit
  // Mistelzweig: gebogener Stiel, fuenf Stechpalmen-Blaetter mit sichtbarer
  // Mittelrippe in Blattrichtung und eine Traube roter Beeren.
  const CHRISTMAS_MISTLETOE = `
    <svg class="zh-xmas-mistletoe" viewBox="0 0 240 210" aria-hidden="true">
      <defs>
        <g id="zhHollyLeaf">
          <path class="zh-xmas-holly-fill" d="M2,-32
            C24,-32 40,-22 48,-6 C52,2 52,8 48,12
            C40,28 24,32 2,32
            C-16,32 -28,22 -34,8 C-38,0 -38,-8 -34,-14
            C-28,-26 -16,-32 2,-32 Z"/>
          <path class="zh-xmas-holly-vein" d="M-6,0 C4,0 18,-2 30,-2"/>
          <path class="zh-xmas-holly-vein" d="M14,-1 C18,-9 22,-16 26,-22"/>
          <path class="zh-xmas-holly-vein" d="M14,1 C18,9 22,16 26,22"/>
          <path class="zh-xmas-holly-vein" d="M-2,-1 C-4,-7 -6,-12 -8,-17"/>
          <path class="zh-xmas-holly-vein" d="M-2,1 C-4,7 -6,12 -8,17"/>
        </g>
      </defs>

      <g class="zh-xmas-mistlestem">
        <path d="M4,10 C42,42 84,70 124,96 C144,108 162,120 180,134"/>
      </g>

      <g class="zh-xmas-holly">
        <use href="#zhHollyLeaf" transform="translate(66,78) rotate(28)"/>
        <use href="#zhHollyLeaf" transform="translate(122,112) rotate(-14)"/>
        <use href="#zhHollyLeaf" transform="translate(170,146) rotate(24) scale(.92)"/>
        <use href="#zhHollyLeaf" transform="translate(94,124) rotate(152) scale(.78)"/>
        <use href="#zhHollyLeaf" transform="translate(150,158) rotate(176) scale(.72)"/>
      </g>

      <g class="zh-xmas-holly-berries">
        <circle cx="152" cy="98" r="12"/>
        <circle cx="172" cy="108" r="10.5"/>
        <circle cx="158" cy="122" r="9"/>
        <circle cx="136" cy="114" r="8"/>
      </g>
      <g class="zh-xmas-holly-shines">
        <circle cx="148" cy="94" r="3.2"/>
        <circle cx="168.5" cy="104" r="2.8"/>
        <circle cx="155" cy="118.5" r="2.4"/>
        <circle cx="133.5" cy="111" r="2"/>
      </g>
    </svg>`;

  // Tannenbaum-Silhouette: gezaehnter Nadelrand (Astspitzen und Kerben) statt
  // gestapelter Dreiecke. Der Pfad wird berechnet, damit die Zacken gleich-
  // maessig sitzen; Lichter, Kugeln, Stern und Geschenke liegen darueber.
  function christmasTreeSvg() {
    const cx = 85;
    const oben = 14;
    const unten = 186;
    const halb = 62;
    const stufen = 6;
    const schritt = (unten - oben) / stufen;
    const links = [];
    const rechts = [];
    const spitzen = [];

    for (let i = 1; i <= stufen; i += 1) {
      const t2 = i / stufen;
      const y = oben + (unten - oben) * Math.pow(t2, 0.92);
      const x = halb * Math.pow(t2, 1.12);
      const kerbeY = Math.min(unten - 3, y + schritt * 0.46);
      links.push(`L${(cx - x).toFixed(1)},${y.toFixed(1)}`);
      links.push(`L${(cx - x * 0.68).toFixed(1)},${kerbeY.toFixed(1)}`);
      rechts.push(`L${(cx + x).toFixed(1)},${y.toFixed(1)}`);
      rechts.push(`L${(cx + x * 0.68).toFixed(1)},${kerbeY.toFixed(1)}`);
      if (i >= 2 && i <= 4) spitzen.push({ x: cx - x * 0.92, y: y + 2 }, { x: cx + x * 0.92, y: y + 2 });
    }

    const boden = [];
    const segmente = 5;
    for (let k = 0; k <= segmente; k += 1) {
      const x = cx - halb + (2 * halb * k) / segmente;
      boden.push(`L${x.toFixed(1)},${k % 2 === 0 ? unten : unten - 7}`);
    }

    const schnee = spitzen
      .slice(0, 6)
      .map((s2) => `<ellipse class="zh-xmas-tree-snow" cx="${s2.x.toFixed(1)}" cy="${s2.y.toFixed(1)}" rx="7.5" ry="3.1"/>`)
      .join("");

    return `
    <svg class="zh-xmas-tree" viewBox="0 0 170 220" aria-hidden="true">
      <rect class="zh-xmas-tree-trunk" x="76" y="176" width="18" height="34" rx="4"/>
      <path class="zh-xmas-tree-green" d="M${cx},${oben} ${links.join(" ")} ${boden.join(" ")} ${rechts.reverse().join(" ")} Z"/>
      ${schnee}
      <path class="zh-xmas-tree-star" d="M85,0 L88.6,9.4 L98,10 L90.8,16 L93.4,26 L85,20.4 L76.6,26 L79.2,16 L72,10 L81.4,9.4 Z"/>
      <circle class="zh-xmas-tree-light" cx="66" cy="60" r="3.1"/>
      <circle class="zh-xmas-tree-light" cx="106" cy="76" r="3.1"/>
      <circle class="zh-xmas-tree-light" cx="54" cy="108" r="3.1"/>
      <circle class="zh-xmas-tree-light" cx="118" cy="120" r="3.1"/>
      <circle class="zh-xmas-tree-light" cx="44" cy="156" r="3.1"/>
      <circle class="zh-xmas-tree-light" cx="126" cy="164" r="3.1"/>
      <circle class="zh-xmas-bauble" cx="92" cy="98" r="6" fill="url(#zhXmasBaubleRed)"/>
      <circle class="zh-xmas-bauble" cx="60" cy="134" r="5.4" fill="url(#zhXmasBaubleGold)"/>
      <circle class="zh-xmas-bauble" cx="112" cy="172" r="5.6" fill="url(#zhXmasBaubleRed)"/>
      <circle class="zh-xmas-bauble" cx="80" cy="158" r="5" fill="url(#zhXmasBaubleGold)"/>
      <g class="zh-xmas-tree-gifts">
        <rect x="34" y="194" width="34" height="22" rx="3" fill="#b3261e"/>
        <rect x="34" y="194" width="34" height="7" rx="3" fill="#8f1d16"/>
        <rect x="49" y="194" width="4" height="22" fill="#f6e3b4"/>
        <path d="M51,194 C46,187 40,188 42,192 C44,196 49,196 51,194 Z" fill="#e8b34b"/>
        <rect x="96" y="198" width="28" height="18" rx="2.5" fill="#1f6b4a"/>
        <rect x="96" y="198" width="28" height="6" rx="2.5" fill="#17573a"/>
        <rect x="108" y="198" width="4" height="18" fill="#f6e3b4"/>
        <rect x="66" y="204" width="26" height="16" rx="2.5" fill="#3976bb"/>
        <rect x="76" y="204" width="4" height="16" fill="#f6e3b4"/>
        <path d="M79,204 C74,199 68,200 70,203 C72,206 77,205 79,204 Z" fill="#e8b34b"/>
      </g>
    </svg>`;
  }

  // Rentiere, Schlitten und Weihnachtsmann als Vektorgrafik. Alles in lokalen
  // Koordinaten, damit dieselbe Szene im Vorbeiflug passt.
  function christmasReindeer() {
    return `
      <g class="zh-xmas-deer">
        <path class="zh-xmas-deer-body" d="M2,62 C2,44 15,35 34,35 C52,35 63,44 67,57 L69,68 C69,76 63,80 54,80 L10,80 C4,80 2,74 2,68 Z"/>
        <path class="zh-xmas-deer-body" d="M58,48 C64,33 73,21 84,14 L94,21 C87,31 79,45 73,60 Z"/>
        <path class="zh-xmas-deer-body" d="M80,10 C89,3 101,5 107,13 C110,19 106,26 98,27 L82,22 C78,19 77,13 80,10 Z"/>
        <path class="zh-xmas-deer-muzzle" d="M98,14 C104,15 107,19 107,23"/>
        <circle class="zh-xmas-deer-eye" cx="96" cy="12" r="2"/>
        <path class="zh-xmas-deer-antler" d="M86,6 C81,-4 74,-10 65,-13 M86,6 C91,-4 93,-13 91,-21 M86,6 C77,-1 70,-2 63,-3 M93,4 C95,-4 100,-10 107,-13"/>
        <path class="zh-xmas-deer-line" d="M11,78 L11,122 M24,78 L24,122 M52,78 L52,122 M65,78 L65,122"/>
        <path class="zh-xmas-deer-line" d="M2,54 C-7,57 -13,64 -15,71"/>
        <path class="zh-xmas-deer-collar" d="M64,54 C59,61 52,65 45,67"/>
        <circle class="zh-xmas-deer-bell" cx="52" cy="66" r="3.2"/>
      </g>`;
  }

  // Die ganze Szene: Schlitten, Weihnachtsmann, Geschenksack, zwei Rentiere.
  // Zeichenreihenfolge: Geschirr, Rentiere, Sack, Weihnachtsmann, Schlitten -
  // so verschwindet der Unterkoerper hinter der Seitenwand und er sitzt IM
  // Schlitten statt davor.
  function christmasSleighScene() {
    return `
      <svg class="zh-xmas-scene" viewBox="0 0 760 300" aria-hidden="true">
        <g class="zh-xmas-harness">
          <path d="M250,190 C302,180 366,176 442,182"/>
          <path d="M250,212 C306,220 372,220 442,212"/>
        </g>
        <g transform="translate(430,128) scale(1.05)">${christmasReindeer()}</g>
        <g transform="translate(590,120) scale(1.05)">${christmasReindeer()}</g>

        <g class="zh-xmas-sack">
          <path d="M74,176 C66,158 72,140 88,133 C104,126 120,134 124,150 C128,166 120,180 108,188 L82,188 Z"/>
          <path class="zh-xmas-sack-tie" d="M84,136 C90,130 99,128 107,132"/>
        </g>

        <g class="zh-xmas-santa">
          <path class="zh-xmas-santa-arm" d="M176,150 C198,153 216,158 232,164"/>
          <path class="zh-xmas-santa-coat" d="M112,176 L186,176 L186,132 C186,122 172,116 149,116 C126,116 112,122 112,132 Z"/>
          <path class="zh-xmas-santa-belt" d="M112,158 L186,158 L186,169 L112,169 Z"/>
          <rect class="zh-xmas-santa-buckle" x="143" y="157" width="12" height="12" rx="2"/>
          <path class="zh-xmas-santa-trim" d="M112,170 L186,170 L186,177 L112,177 Z"/>
          <circle class="zh-xmas-santa-face" cx="149" cy="104" r="16"/>
          <path class="zh-xmas-santa-beard" d="M133,104 C133,128 140,140 149,140 C158,140 165,128 165,104 C159,112 139,112 133,104 Z"/>
          <circle class="zh-xmas-santa-eye" cx="143" cy="99" r="1.9"/>
          <circle class="zh-xmas-santa-eye" cx="155" cy="99" r="1.9"/>
          <circle class="zh-xmas-santa-cheek" cx="136" cy="104" r="3"/>
          <circle class="zh-xmas-santa-cheek" cx="162" cy="104" r="3"/>
          <path class="zh-xmas-santa-smile" d="M143,113 C146,118 152,118 155,113"/>
          <path class="zh-xmas-santa-hat" d="M129,94 C132,72 141,60 152,56 C163,60 169,76 169,94 Z"/>
          <path class="zh-xmas-santa-trim" d="M126,91 L172,91 L172,101 L126,101 Z"/>
          <circle class="zh-xmas-santa-trim" cx="159" cy="54" r="7"/>
          <circle class="zh-xmas-santa-glove" cx="236" cy="165" r="6.5"/>
        </g>

        <g class="zh-xmas-sleigh-box">
          <path class="zh-xmas-sleigh-back" d="M60,196 C42,172 46,146 62,136 C74,128 86,136 86,149 C86,164 74,178 64,186"/>
          <path class="zh-xmas-sleigh-body" d="M58,192 C58,182 66,176 78,176 L216,176 C232,176 244,184 250,198 L250,216 C250,226 242,232 232,232 L76,232 C66,232 58,226 58,216 Z"/>
          <path class="zh-xmas-sleigh-trim" d="M58,186 L250,186"/>
          <path class="zh-xmas-sleigh-runner" d="M54,248 L206,248 C238,248 254,232 254,210 C254,200 250,192 244,186"/>
          <path class="zh-xmas-sleigh-ground" d="M42,278 L268,278"/>
        </g>
      </svg>`;
  }

  const CHRISTMAS_SPARKS = [
    [6, 18, 0], [14, 62, 1.4], [31, 8, 0.6], [47, 26, 2.1], [63, 6, 1.1],
    [76, 20, 2.6], [88, 48, 0.3], [95, 12, 1.8], [22, 84, 2.3], [71, 74, 0.9],
    [38, 44, 3.2], [55, 66, 0.2], [67, 38, 2.9], [82, 84, 1.6], [10, 34, 3.6],
    [92, 70, 2.0], [26, 12, 4.1], [50, 90, 1.2]
  ].map(([links, oben, verzoegerung]) => `
    <svg class="zh-xmas-spark" style="left:${links}%;top:${oben}%;animation-delay:${verzoegerung}s" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 0 L13.6 9.2 L24 12 L13.6 14.8 L12 24 L10.4 14.8 L0 12 L10.4 9.2 Z"/>
    </svg>`).join("");

  function addEasmStyles() {
    addStyle("zh-easm-style", `
      .zh-easm-btn {
        margin-left: 10px;
        padding: 4px 10px;
        border: 1px solid #c9d6e2;
        border-radius: 999px;
        background: #fff;
        color: #1f5f9f;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
      }
      .zh-easm-btn:hover { background: #eef4fa; }
      .zh-easm-btn:disabled { opacity: .6; cursor: default; }
      .zh-easm-badge {
        display: inline-block;
        margin-left: 6px;
        padding: 3px 9px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 700;
        border: 1px solid transparent;
        vertical-align: middle;
      }
      .zh-easm-badge--critical { background: #fde8e6; border-color: #b3261e; color: #8c1c14; }
      .zh-easm-badge--high { background: #fff0dd; border-color: #d98200; color: #8a5200; }
      .zh-easm-badge--medium { background: #fff8d6; border-color: #d4a800; color: #6f5800; }
      .zh-easm-badge--low { background: #e8f6ea; border-color: #2e7d32; color: #1d5220; }
      .zh-easm-badge--none { background: #eef1f4; border-color: #c3ccd6; color: #5b6672; }
    `);
  }

  function addChristmasStyles() {
    addStyle("zh-christmas-style", `
      .zh-xmas-layer {
        position: fixed;
        inset: 0;
        pointer-events: none;
        overflow: hidden;
        contain: strict;
      }
      /* Deko (Baum, Girlande, Zweig) liegt UNTER Znunys Dialogen. */
      .zh-xmas-layer--back { z-index: 500; }
      /* Schnee und Schlitten duerfen obenauf liegen. */
      .zh-xmas-layer--front { z-index: 2147483000; }
      .zh-xmas-layer canvas.zh-xmas-snow { position: absolute; inset: 0; width: 100%; height: 100%; }
      .zh-xmas-layer .zh-xmas-glow {
        position: absolute; left: 0; right: 0; top: 0; height: 220px;
        background: radial-gradient(120% 100% at 50% 0%, rgba(255, 196, 120, .22), rgba(255, 196, 120, 0) 70%);
      }
      .zh-xmas-layer svg { display: block; }
      .zh-xmas-layer .zh-xmas-lights {
        position: absolute; left: 0; right: 0; top: 0; width: 100%; height: 92px;
        filter: drop-shadow(0 2px 4px rgba(0,0,0,.25));
      }
      .zh-xmas-layer .zh-xmas-defs { position: absolute; width: 0; height: 0; }
      /* Zweifarbig: dunkle Kante plus helle Schnur - sichtbar auf hellem
         Inhalt und auf der dunklen Kopfleiste. */
      .zh-xmas-layer .zh-xmas-wire-shadow { stroke: #4a3517; stroke-width: 3.6; opacity: .85; }
      .zh-xmas-layer .zh-xmas-wire { stroke: #d3a862; stroke-width: 2; }
      .zh-xmas-layer .zh-xmas-sprig path { fill: none; stroke: #1b5a38; stroke-width: 2.2; stroke-linecap: round; opacity: .95; }
      .zh-xmas-layer .zh-xmas-bulb-glow { fill: #ffd479; opacity: .28; filter: url(#zhXmasGlow); }
      .zh-xmas-layer .zh-xmas-cap { fill: #c9a227; }
      .zh-xmas-layer .zh-xmas-shine { fill: rgba(255,255,255,.75); }
      .zh-xmas-layer .zh-xmas-tree-green { fill: url(#zhXmasTree); stroke: #0d3520; stroke-width: 1.2; stroke-linejoin: round; }
      .zh-xmas-layer .zh-xmas-treesnow { fill: #f4f8fb; opacity: .92; }
      .zh-xmas-layer .zh-xmas-tree-light { fill: #ffe9a8; filter: url(#zhXmasGlow); }
      .zh-xmas-layer .zh-xmas-tree-star { fill: #ffe9a8; filter: url(#zhXmasGlow); }
      .zh-xmas-layer .zh-xmas-holly-fill { fill: #2f6b46; stroke: #1c4a2f; stroke-width: 1.4; stroke-linejoin: round; }
      .zh-xmas-layer .zh-xmas-holly-vein { fill: none; stroke: #1c4a2f; stroke-width: 1.2; opacity: .6; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-mistlestem { fill: none; stroke: #2f6b46; stroke-width: 3.2; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-holly-berries circle { fill: url(#zhXmasBaubleRed); stroke: #6f1712; stroke-width: 1.2; }
      .zh-xmas-layer .zh-xmas-holly-shines circle { fill: rgba(255,255,255,.85); }
      .zh-xmas-layer .zh-xmas-thread { stroke: #d9c48a; stroke-width: 1.2; }
      .zh-xmas-layer .zh-xmas-fly {
        position: absolute; top: 7%; left: 0; width: 700px; height: 276px;
        will-change: transform;
        filter: drop-shadow(0 12px 18px rgba(0,0,0,.16));
      }
      .zh-xmas-layer .zh-xmas-fly--go { animation: zh-xmas-fly-across 7s linear forwards; }
      @keyframes zh-xmas-fly-across {
        0%   { transform: translate(-660px, 0) rotate(-2deg); }
        20%  { transform: translate(12vw, -28px) rotate(1deg); }
        45%  { transform: translate(42vw, 16px) rotate(-1deg); }
        70%  { transform: translate(70vw, -18px) rotate(1.5deg); }
        100% { transform: translate(116vw, 4px) rotate(-1deg); }
      }
      .zh-xmas-layer .zh-xmas-mistletoe {
        position: absolute; top: -8px; right: -4px; width: 132px; height: 111px;
        transform: scaleX(-1);
        filter: drop-shadow(0 5px 8px rgba(0,0,0,.2));
      }
      .zh-xmas-layer .zh-xmas-mistlestem { fill: none; stroke: #3f6b3a; stroke-width: 3.4; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-holly use { fill: #2f7b4a; stroke: #1b4a2c; stroke-width: 1.6; stroke-linejoin: round; }
      .zh-xmas-layer .zh-xmas-holly-veins path { fill: none; stroke: #1b4a2c; stroke-width: 1.4; opacity: .55; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-holly-berries circle { fill: url(#zhXmasBaubleRed); stroke: #6f1712; stroke-width: 1.2; }
      .zh-xmas-layer .zh-xmas-holly-shines circle { fill: rgba(255,255,255,.8); }
      .zh-xmas-layer .zh-xmas-mistleberry-shine,\n      .zh-xmas-layer .zh-xmas-mistleberry-shines circle { fill: rgba(255,255,255,.85); }
      .zh-xmas-layer .zh-xmas-thread { stroke: #d9c48a; stroke-width: 1.2; }
      .zh-xmas-layer .zh-xmas-fly {
        position: absolute; top: 7%; left: 0; width: 700px; height: 276px;
        will-change: transform;
        filter: drop-shadow(0 12px 18px rgba(0,0,0,.16));
      }
      .zh-xmas-layer .zh-xmas-fly--go { animation: zh-xmas-fly-across 7s linear forwards; }
      @keyframes zh-xmas-fly-across {
        0%   { transform: translate(-660px, 0) rotate(-2deg); }
        20%  { transform: translate(12vw, -28px) rotate(1deg); }
        45%  { transform: translate(42vw, 16px) rotate(-1deg); }
        70%  { transform: translate(70vw, -18px) rotate(1.5deg); }
        100% { transform: translate(116vw, 4px) rotate(-1deg); }
      }
      .zh-xmas-layer .zh-xmas-mistletoe {
        position: absolute; top: -8px; right: -4px; width: 132px; height: 111px;
        transform: scaleX(-1);
        filter: drop-shadow(0 5px 8px rgba(0,0,0,.2));
      }
      .zh-xmas-layer .zh-xmas-mistlestem { fill: none; stroke: #2f6b46; stroke-width: 3; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-mistleaf { fill: #2f6b46; stroke: #1c4a2f; stroke-width: 1.1; }
      .zh-xmas-layer .zh-xmas-tree {
        position: absolute; right: 8px; bottom: 12px; width: 132px; height: 176px;
        outline: none !important; -webkit-tap-highlight-color: transparent;
        filter: drop-shadow(0 6px 10px rgba(0,0,0,.2));
        /* Der Baum ist der einzige Teil der Deko, der Klicks annimmt (Pinball). */
        pointer-events: auto; cursor: pointer;
      }
      .zh-xmas-layer .zh-xmas-tree-trunk { fill: #6b4226; }
      .zh-xmas-layer .zh-xmas-tree-green { fill: #1c5c3a; stroke: #14432a; stroke-width: 1.5; }
      .zh-xmas-layer .zh-xmas-tree-star { fill: #e8b34b; }
      .zh-xmas-layer .zh-xmas-tree-snow { fill: #f2f7fb; opacity: .92; }
      /* Damit sich Kugeln und Laempchen verschieben lassen: Bezug auf die eigene Flaeche. */
      .zh-xmas-layer .zh-xmas-bauble,
      .zh-xmas-layer .zh-xmas-bulb-glow,
      .zh-xmas-layer .zh-xmas-tree-light { transform-box: fill-box; transform-origin: center; }
      .zh-xmas-layer .zh-xmas-deer-body { fill: url(#zhXmasDeer); }
      .zh-xmas-layer .zh-xmas-deer-muzzle { fill: none; stroke: #5b3620; stroke-width: 2; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-deer-eye { fill: #f6e3b4; }
      .zh-xmas-layer .zh-xmas-deer-collar { fill: none; stroke: #b3261e; stroke-width: 3; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-deer-bell { fill: #e8b34b; }
      .zh-xmas-layer .zh-xmas-deer-line { fill: none; stroke: #7a4a2b; stroke-width: 6; stroke-linecap: round; stroke-linejoin: round; }
      .zh-xmas-layer .zh-xmas-deer-antler { fill: none; stroke: #e8b34b; stroke-width: 2.6; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-harness path { stroke: #e8b34b; stroke-width: 1.8; fill: none; opacity: .9; }
      .zh-xmas-layer .zh-xmas-sleigh-body { fill: url(#zhXmasSleigh); stroke: #6f1712; stroke-width: 2; }
      .zh-xmas-layer .zh-xmas-sleigh-back { fill: url(#zhXmasSleigh); stroke: #6f1712; stroke-width: 2; }
      .zh-xmas-layer .zh-xmas-sleigh-trim { fill: none; stroke: #e8b34b; stroke-width: 3; }
      .zh-xmas-layer .zh-xmas-sleigh-runner { fill: none; stroke: #e8b34b; stroke-width: 3.5; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-sleigh-ground { fill: none; stroke: #e8b34b; stroke-width: 2; opacity: .6; }
      .zh-xmas-layer .zh-xmas-sack > path:first-child { fill: #8a5a2b; stroke: #5b3620; stroke-width: 2; }
      .zh-xmas-layer .zh-xmas-sack-tie { fill: none; stroke: #e8b34b; stroke-width: 2; }
      .zh-xmas-layer .zh-xmas-santa-coat { fill: url(#zhXmasCoat); stroke: #7d160f; stroke-width: 1.6; }
      .zh-xmas-layer .zh-xmas-santa-hat { fill: url(#zhXmasCoat); stroke: #7d160f; stroke-width: 1.6; }
      .zh-xmas-layer .zh-xmas-santa-arm { fill: none; stroke: #b3261e; stroke-width: 10; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-santa-belt { fill: #2b2b2b; }
      .zh-xmas-layer .zh-xmas-santa-buckle { fill: #e8b34b; }
      .zh-xmas-layer .zh-xmas-santa-trim { fill: #f7f4ee; }
      .zh-xmas-layer .zh-xmas-santa-face { fill: #f2c9a0; }
      .zh-xmas-layer .zh-xmas-santa-beard { fill: url(#zhXmasBeard); stroke: #d8d1c2; stroke-width: .8; }
      .zh-xmas-layer .zh-xmas-santa-glove { fill: #2b2b2b; }
      .zh-xmas-layer .zh-xmas-santa-eye { fill: #2b2b2b; }
      .zh-xmas-layer .zh-xmas-santa-cheek { fill: #e8928a; opacity: .85; }
      .zh-xmas-layer .zh-xmas-santa-smile { fill: none; stroke: #8c4a42; stroke-width: 1.6; stroke-linecap: round; }
      .zh-xmas-layer .zh-xmas-gift {
        position: absolute; width: 30px; height: 30px;
        animation: zh-xmas-gift-fall 2.4s cubic-bezier(.35,.05,.75,.6) forwards;
      }
      @keyframes zh-xmas-gift-fall {
        0% { transform: translate(0, 0) rotate(0deg); opacity: 1; }
        100% { transform: translate(var(--zh-gift-dx, 30px), 52vh) rotate(var(--zh-gift-rot, 220deg)); opacity: 0; }
      }
      .zh-xmas-layer .zh-xmas-spark {
        position: absolute; width: 18px; height: 18px; fill: #fff6d8;
        opacity: 0; animation: zh-xmas-spark 4.8s ease-in-out infinite;
        filter: drop-shadow(0 0 4px rgba(255, 236, 179, .9));
      }
      @keyframes zh-xmas-twinkle { 0%, 100% { opacity: .35; } 50% { opacity: 1; } }
      @keyframes zh-xmas-sway { 0%, 100% { transform: rotate(-2.5deg); } 50% { transform: rotate(2.5deg); } }
      @keyframes zh-xmas-bob { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
      @keyframes zh-xmas-spark {
        0%, 100% { opacity: 0; transform: scale(.4) rotate(0deg); }
        40% { opacity: 1; transform: scale(1) rotate(35deg); }
        70% { opacity: .15; transform: scale(.7) rotate(70deg); }
      }
      @media (prefers-reduced-motion: reduce) {
        .zh-xmas-layer .zh-xmas-bulb,
        .zh-xmas-layer .zh-xmas-bauble,
        .zh-xmas-layer .zh-xmas-sleigh,
        .zh-xmas-layer .zh-xmas-spark { animation: none; }
        .zh-xmas-layer .zh-xmas-spark { opacity: .65; }
      }
      /* Kein Platz heisst: keine Deko ueber dem Inhalt. Die Seite meldet per
         Klasse, wenn sie scrollt; zusaetzlich greifen die Breitenschwellen. */
      /* Bei wenig Platz nicht verschwinden, sondern zur Seite rutschen -
         sichtbar bleiben, aber die Zeilen nicht mehr verdecken. */
      .zh-xmas-layer .zh-xmas-tree,
      .zh-xmas-layer .zh-xmas-mistletoe { transition: transform .45s ease, opacity .45s ease; }
      /* Bei wenig Platz nur zart verkleinern - der Baum bleibt vollstaendig
         im Bild und nimmt den unteren Rand als Anker (kein Rausrutschen). */
      .zh-xmas-layer.zh-xmas-knapp .zh-xmas-tree { transform: translateY(6%) scale(.9); transform-origin: bottom right; opacity: .9; }
      .zh-xmas-layer.zh-xmas-knapp .zh-xmas-mistletoe { transform: scale(.9); transform-origin: top right; opacity: .9; }
      @media (max-width: 1100px) {
        .zh-xmas-layer .zh-xmas-tree,
        .zh-xmas-layer .zh-xmas-mistletoe { display: none; }
      }
      @media (max-width: 760px) {
        .zh-xmas-layer .zh-xmas-lights { display: none; }
      }
      @media (max-width: 700px) {
        .zh-xmas-layer .zh-xmas-sleigh { width: 230px; height: 92px; bottom: 10px; }
      }
    `);
  }

  // Schneeflocken-Sprites: einmal vorgerendert, dann nur noch als Bild
  // gezeichnet. Das ist deutlich guenstiger als pro Flocke Pfade zu malen.
  // Drei Groessen mit Aestchen - die kleinen bleiben schlichte Sternchen.
  function zeichneSchneeflocke(groesse, mitAesten) {
    const sprite = document.createElement("canvas");
    sprite.width = groesse * 2;
    sprite.height = groesse * 2;
    const g = sprite.getContext("2d");

    g.translate(groesse, groesse);
    g.strokeStyle = "rgba(146, 174, 205, 0.95)";
    g.fillStyle = "rgba(255, 255, 255, 0.95)";
    g.lineWidth = Math.max(0.7, groesse / 16);
    g.lineCap = "round";

    for (let arm = 0; arm < 6; arm += 1) {
      g.save();
      g.rotate((Math.PI / 3) * arm);
      g.beginPath();
      g.moveTo(0, 0);
      g.lineTo(0, -groesse * 0.86);
      if (mitAesten) {
        [0.42, 0.66].forEach((anteil) => {
          const y = -groesse * 0.86 * anteil;
          const laenge = groesse * 0.26 * (1 - anteil * 0.45);
          g.moveTo(0, y);
          g.lineTo(laenge, y + laenge * 0.85);
          g.moveTo(0, y);
          g.lineTo(-laenge, y + laenge * 0.85);
        });
      }
      g.stroke();
      g.restore();
    }

    g.beginPath();
    g.arc(0, 0, Math.max(0.8, groesse * 0.09), 0, Math.PI * 2);
    g.fill();
    return sprite;
  }

  function startChristmasSnow(canvas) {
    if (!canvas || !canvas.getContext) return () => {};

    const ctx = canvas.getContext("2d");
    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches === true;
    let breite = 0;
    let hoehe = 0;
    let flocken = [];
    let frame = 0;
    let letzteZeit = 0;
    let laeuft = false;

    // Antimagnetisch: Flocken weichen dem Mauszeiger aus. Die Position lebt
    // nur so lange wie die letzte Bewegung - steht die Maus, hoert der Effekt
    // nach kurzer Zeit auf.
    const maus = { x: -999, y: -999, aktiv: false, zeit: 0 };
    const aufZeiger = (event) => {
      maus.x = event.clientX;
      maus.y = event.clientY;
      maus.aktiv = true;
      maus.zeit = performance.now();
    };
    const zeigerWeg = () => {
      maus.aktiv = false;
    };

    // Drei Tiefen: weit (klein, blass, langsam), mittel, nah (gross, schnell,
    // drehend). Das erzeugt den Eindruck von Raum statt einer flachen Wand.
    const EBENEN = [
      { groesse: 7, mitAesten: false, alpha: 0.26, tempo: 0.16, anteil: 0.4, dreht: false },
      { groesse: 11, mitAesten: true, alpha: 0.42, tempo: 0.32, anteil: 0.36, dreht: false },
      { groesse: 16, mitAesten: true, alpha: 0.68, tempo: 0.58, anteil: 0.24, dreht: true }
    ];
    const sprites = EBENEN.map((ebene) => zeichneSchneeflocke(ebene.groesse * 2, ebene.mitAesten));

    const messen = () => {
      // Schnee braucht keine Retina-Aufloesung: bei 1.25 statt 2 spart die
      // Leinwand rund zwei Drittel Speicher pro Tab - bei vielen offenen
      // Znuny-Tabs der eigentliche Unterschied.
      const dpr = Math.min(window.devicePixelRatio || 1, 1.25);
      breite = window.innerWidth;
      hoehe = window.innerHeight;
      canvas.width = Math.max(1, Math.round(breite * dpr));
      canvas.height = Math.max(1, Math.round(hoehe * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const anlegen = () => {
      const gesamt = Math.max(18, Math.min(58, Math.round(breite / 27)));
      flocken = [];
      EBENEN.forEach((ebene, index) => {
        const anzahl = Math.round(gesamt * ebene.anteil);
        for (let i = 0; i < anzahl; i += 1) {
          flocken.push({
            x: Math.random() * breite,
            y: Math.random() * hoehe,
            ebene: index,
            r: ebene.groesse * (0.55 + Math.random() * 0.5),
            tempo: ebene.tempo * (0.7 + Math.random() * 0.6),
            drift: -0.25 + Math.random() * 0.5,
            phase: Math.random() * Math.PI * 2,
            winkel: Math.random() * Math.PI * 2,
            drehTempo: (Math.random() - 0.5) * 0.03,
            alpha: ebene.alpha * (0.45 + Math.random() * 0.6)
          });
        }
      });
    };

    const zeichnen = (zeit) => {
      const schritt = letzteZeit ? Math.min(60, zeit - letzteZeit) / 16.67 : 1;
      letzteZeit = zeit;

      // Windböen: mal sanft nach rechts, mal fast still.
      const wind = Math.sin(zeit / 5200) * 0.55 + Math.sin(zeit / 1700) * 0.18;

      ctx.clearRect(0, 0, breite, hoehe);
      const wirbel = christmasWake.aktiv ? christmasWake : null;
      const mausAktiv = maus.aktiv && zeit - maus.zeit < 1400;
      for (const flocke of flocken) {
        const ebene = EBENEN[flocke.ebene];
        flocke.y += flocke.tempo * schritt;

        // Der Mauszeiger wirkt abstossend: je naeher die Flocke, desto
        // staerker wird sie weggeschoben (plus leichter Drall).
        if (mausAktiv) {
          const dx = flocke.x - maus.x;
          const dy = flocke.y - maus.y;
          const quadrat = dx * dx + dy * dy;
          if (quadrat < 150 * 150) {
            const abstand = Math.sqrt(quadrat) || 1;
            const naehe = 1 - abstand / 150;
            const kraft = naehe * naehe * 5.2 * schritt;
            flocke.x += (dx / abstand) * kraft - (dy / abstand) * kraft * 0.35;
            flocke.y += (dy / abstand) * kraft + (dx / abstand) * kraft * 0.35;
          }
        }

        // Wirbelt der Schlitten vorbei, werden Flocken in seiner Naehe nach
        // aussen gedrueckt und mitgerissen - wie eine Schleppe.
        if (wirbel) {
          const dx = flocke.x - wirbel.x;
          const dy = flocke.y - wirbel.y;
          const abstand = Math.sqrt(dx * dx + dy * dy) || 1;
          if (abstand < wirbel.radius) {
            const naehe = 1 - abstand / wirbel.radius;
            const kraft = naehe * naehe * 3.4 * schritt;
            const nx = dx / abstand;
            const ny = dy / abstand;
            flocke.x += (nx * 0.8 - ny * 1.4) * kraft;
            flocke.y += (ny * 0.8 + nx * 1.4 - 0.6) * kraft;
          }
        }
        flocke.x += (flocke.drift + wind + Math.sin(zeit / 1500 + flocke.phase) * 0.45) * schritt;

        if (ebene.dreht) flocke.winkel += flocke.drehTempo * schritt;

        if (flocke.y > hoehe + 12) {
          flocke.y = -12;
          flocke.x = Math.random() * breite;
        }
        if (flocke.x < -16) flocke.x = breite + 16;
        else if (flocke.x > breite + 16) flocke.x = -16;

        const sprite = sprites[flocke.ebene];
        const durchmesser = flocke.r * 2;
        ctx.globalAlpha = flocke.alpha;
        if (ebene.dreht) {
          ctx.save();
          ctx.translate(flocke.x, flocke.y);
          ctx.rotate(flocke.winkel);
          ctx.drawImage(sprite, -durchmesser / 2, -durchmesser / 2, durchmesser, durchmesser);
          ctx.restore();
        } else {
          ctx.drawImage(sprite, flocke.x - durchmesser / 2, flocke.y - durchmesser / 2, durchmesser, durchmesser);
        }
      }
      ctx.globalAlpha = 1;

      frame = window.requestAnimationFrame(zeichnen);
    };

    // Ohne Bewegung: ein ruhiges Flockenbild, kein Dauerlauf.
    const stillZeichnen = () => {
      ctx.clearRect(0, 0, breite, hoehe);
      for (const flocke of flocken) {
        const sprite = sprites[flocke.ebene];
        const durchmesser = flocke.r * 2;
        ctx.globalAlpha = flocke.alpha;
        ctx.drawImage(sprite, flocke.x - durchmesser / 2, flocke.y - durchmesser / 2, durchmesser, durchmesser);
      }
      ctx.globalAlpha = 1;
    };

    const starten = () => {
      if (laeuft) return;
      laeuft = true;
      letzteZeit = 0;
      frame = window.requestAnimationFrame(zeichnen);
    };

    const anhalten = () => {
      laeuft = false;
      window.cancelAnimationFrame(frame);
    };

    const neuMessen = () => {
      messen();
      anlegen();
      if (reducedMotion) stillZeichnen();
    };

    // Erst messen, dann verteilen: anlegen() braucht die Fenstergroesse.
    messen();
    anlegen();

    if (document.hidden) {
      // Beim Laden im Hintergrund gar nicht erst Speicher belegen: die
      // Leinwand wird erst beim Sichtbarwerden aufgebaut.
      canvas.width = 0;
      canvas.height = 0;
    } else if (reducedMotion) {
      stillZeichnen();
    } else {
      starten();
    }

    const onResize = () => neuMessen();
    const onVisibility = () => {
      if (document.hidden) {
        anhalten();
        // Hintergrund-Tab: Leinwand freigeben. Eine 0-grosse Flaeche belegt
        // keinen Grafikspeicher - bei vielen offenen Tabs der groesste Effekt.
        canvas.width = 0;
        canvas.height = 0;
      } else {
        neuMessen();
        if (!reducedMotion) starten();
      }
    };

    window.addEventListener("resize", onResize);
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pointermove", aufZeiger, { passive: true });
    window.addEventListener("pointerleave", zeigerWeg);
    document.addEventListener("mouseleave", zeigerWeg);

    return () => {
      anhalten();
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pointermove", aufZeiger);
      window.removeEventListener("pointerleave", zeigerWeg);
      document.removeEventListener("mouseleave", zeigerWeg);
    };
  }

  // Der Weihnachtsmann fliegt regelmaessig durchs Bild und verliert dabei ein
  // paar Geschenke. 15 Minuten Abstand, der erste Flug nach 90 s - sonst sieht
  // die Deko am Anfang niemand. Ausloesbar ueber das Event
  // "znuny-helper-christmas-fly" (Tests, Vorfuehrung).
  const CHRISTMAS_FLY_FIRST_MS = 3 * 60 * 1000;
  const CHRISTMAS_FLY_EVERY_MS = 30 * 60 * 1000;
  const CHRISTMAS_FLY_DURATION_MS = 7000;
  const CHRISTMAS_GIFT_COLORS = ["#b3261e", "#1f6b4a", "#e8b34b", "#3976bb"];
  // Gemeinsamer Zustand von Flug und Schnee: Wo ist der Schlitten gerade, und
  // wirbelt er? Der Schnee liest das in seiner Zeichenschleife.
  const christmasWake = { aktiv: false, x: 0, y: 0, radius: 260 };
  let christmasGiftCounter = 0;

  function christmasGiftSvg() {
    const farbe = CHRISTMAS_GIFT_COLORS[christmasGiftCounter % CHRISTMAS_GIFT_COLORS.length];
    christmasGiftCounter += 1;
    return `
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <rect x="3" y="7" width="18" height="14" rx="2.4" fill="${farbe}"/>
        <rect x="3" y="7" width="18" height="4.6" rx="2.2" fill="${farbe}" opacity=".85"/>
        <rect x="10.4" y="7" width="3.2" height="14" fill="#f6e3b4"/>
        <rect x="3" y="12.2" width="18" height="2.2" fill="#f6e3b4"/>
        <path d="M12 7 C8.4 7 6.2 4.6 7.6 2.8 C9 1 11.4 3.2 12 7 C12.6 3.2 15 1 16.4 2.8 C17.8 4.6 15.6 7 12 7 Z" fill="#e8b34b"/>
      </svg>`;
  }

  function dropChristmasGift(overlay, fly) {
    const rect = fly.getBoundingClientRect();
    if (!rect.width) return;

    const gift = document.createElement("div");
    gift.className = "zh-xmas-gift";
    gift.setAttribute("aria-hidden", "true");
    gift.style.left = `${Math.round(rect.left + rect.width * (0.18 + Math.random() * 0.14))}px`;
    gift.style.top = `${Math.round(rect.top + rect.height * 0.64)}px`;
    gift.style.setProperty("--zh-gift-dx", `${Math.round(Math.random() * 90 - 30)}px`);
    gift.style.setProperty("--zh-gift-rot", `${Math.round(140 + Math.random() * 260)}deg`);
    gift.innerHTML = christmasGiftSvg();

    const entfernen = () => gift.remove();
    gift.addEventListener("animationend", entfernen, { once: true });
    window.setTimeout(entfernen, 6000);

    overlay.appendChild(gift);
  }

  function startChristmasFlyover(overlay) {
    const fly = overlay.querySelector(".zh-xmas-fly");
    if (!fly) return () => {};
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches) {
      // Ohne Bewegung kein Vorbeiflug - die Deko bleibt ruhig.
      return () => {};
    }

    const timers = new Set();
    const merken = (id) => {
      timers.add(id);
      return id;
    };

    const fliegen = () => {
      if (fly.dataset.flying === "1") return;
      fly.dataset.flying = "1";
      fly.hidden = false;
      fly.classList.remove("zh-xmas-fly--go");
      void fly.offsetWidth;
      fly.classList.add("zh-xmas-fly--go");

      // Wirbel: Position des Schlittens waehrend des Flugs verfolgen, damit
      // der Schnee um ihn herum aufgewirbelt wird.
      christmasWake.aktiv = true;
      const wirbelTakt = window.setInterval(() => {
        const rect = fly.getBoundingClientRect();
        christmasWake.x = rect.left + rect.width * 0.32;
        christmasWake.y = rect.top + rect.height * 0.45;
      }, 60);
      merken(wirbelTakt);

      // Sechs Geschenke waehrend des Flugs, leicht versetzt.
      [900, 1900, 2900, 3900, 4900, 5900].forEach((zeit) => {
        merken(window.setTimeout(() => dropChristmasGift(overlay, fly), zeit));
      });

      merken(window.setTimeout(() => {
        fly.classList.remove("zh-xmas-fly--go");
        fly.hidden = true;
        delete fly.dataset.flying;
        christmasWake.aktiv = false;
        window.clearInterval(wirbelTakt);
      }, CHRISTMAS_FLY_DURATION_MS + 800));
    };

    // Manuell ausloesbar: window.__zhChristmasFly() oder das Event.
    window.__zhChristmasFly = fliegen;
    window.addEventListener("znuny-helper-christmas-fly", fliegen);

    merken(window.setTimeout(fliegen, CHRISTMAS_FLY_FIRST_MS));
    merken(window.setInterval(fliegen, CHRISTMAS_FLY_EVERY_MS));

    return () => {
      timers.forEach((id) => {
        window.clearTimeout(id);
        window.clearInterval(id);
      });
      timers.clear();
      window.removeEventListener("znuny-helper-christmas-fly", fliegen);
      christmasWake.aktiv = false;
      if (window.__zhChristmasFly === fliegen) delete window.__zhChristmasFly;
    };
  }

  // ---- Pinball-Minigame (HSRW-Thema) ---------------------------------
  // Eigenes Overlay ueber der Seite, per Escape oder Knopf beendbar. Rein
  // lokal, kein Zugriff auf Znuny-Daten.

  function pinballStyle() {
    addStyle("zh-pinball-style", `
      #zh-pinball {
        position: fixed; inset: 0; z-index: 2147483600;
        background: radial-gradient(120% 90% at 50% 0%, #1b1a3d 0%, #12142c 48%, #08080f 100%);
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        font-family: system-ui, Segoe UI, sans-serif; color: #eaf1fb; gap: 10px;
      }
      #zh-pinball .zh-pin-top { display: flex; align-items: center; gap: 14px; padding: 0 12px; }
      #zh-pinball .zh-pin-brand { display: flex; align-items: center; gap: 9px; }
      #zh-pinball .zh-pin-mark { height: 30px; width: auto; display: block; }
      #zh-pinball .zh-pin-word { font-size: 19px; font-weight: 800; letter-spacing: .6px; color: #eef4ff; }
      #zh-pinball .zh-pin-title { font-size: 20px; font-weight: 800; letter-spacing: .5px; }
      #zh-pinball .zh-pin-level { font-size: 13px; color: #a8c4ea; font-weight: 600; }
      #zh-pinball .zh-pin-score {
        font-size: 24px; font-weight: 800; color: #ffd479; min-width: 84px; text-align: right;
        text-shadow: 0 0 16px rgba(255,212,121,.45);
      }
      #zh-pinball canvas { display: block; border-radius: 16px; touch-action: none; }
      #zh-pinball .zh-pin-hint {
        font-size: 13px; color: #cfe0f7; background: rgba(12,20,40,.85);
        border: 1px solid rgba(127,179,255,.25); border-radius: 999px;
        padding: 7px 16px; line-height: 1.4; text-align: center;
      }
      #zh-pinball .zh-pin-hint b { color: #ffd479; }
      #zh-pinball .zh-pin-close {
        position: absolute; top: 14px; right: 18px; width: 42px; height: 42px;
        border: 1px solid rgba(127,179,255,.35); border-radius: 50%;
        background: rgba(18,26,48,.9); color: #eaf1fb; font-size: 22px; line-height: 1;
        cursor: pointer; transition: background .15s ease, transform .15s ease;
      }
      #zh-pinball .zh-pin-close:hover { background: #2a2f52; transform: scale(1.06); }
      #zh-pinball .zh-pin-intro {
        position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
        background: rgba(4, 6, 16, .74); backdrop-filter: blur(3px);
      }
      #zh-pinball .zh-pin-intro.zh-weg { display: none; }
      #zh-pinball .zh-pin-card {
        width: min(560px, 88vw); background: linear-gradient(180deg, #221f45, #14162e);
        border: 1px solid rgba(127,179,255,.3); border-radius: 20px; padding: 26px 28px 22px;
        box-shadow: 0 24px 60px rgba(0,0,0,.6); text-align: center;
      }
      #zh-pinball .zh-pin-card h2 { margin: 0 0 6px; font-size: 21px; color: #ffd479; }
      #zh-pinball .zh-pin-card p { margin: 10px 0 0; font-size: 15px; line-height: 1.55; color: #dbe8fa; }
      #zh-pinball .zh-pin-card button {
        margin-top: 20px; padding: 11px 26px; border-radius: 999px; border: 0;
        background: linear-gradient(180deg, #ffd479, #e0a92e); color: #2a1b00;
        font-size: 15px; font-weight: 800; cursor: pointer;
      }
      #zh-pinball .zh-pin-card button:hover { filter: brightness(1.07); }
      #zh-pinball svg.zh-pin-elf { width: 116px; height: 116px; margin-bottom: 4px; }
    `);
  }

  // HSRW-Marke, exakt nach Logo: links ein runder Strich, der schraeg nach
  // unten rechts laeuft und dann senkrecht wird; rechts ein Balken, dessen
  // Oberkante schraeg abgeschnitten ist (Fahne) und der unten rund endet.
  // Farben: #2a2250 (violett-navy) und #3c7fd1 (blau), dazwischen Weiss.
  function hswrMarkSvg(klasse) {
    return `
      <svg class="${klasse}" viewBox="0 0 200 220" aria-hidden="true">
        <path d="M62,44 L104,92 L104,170"
              fill="none" stroke="#2a2250" stroke-width="38"
              stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M126,72 L162,28 L162,162 A19,19 0 0 1 124,162 Z" fill="#3c7fd1"/>
      </svg>`;
  }

  function pinballBrand() {
    return `<span class="zh-pin-brand">${hswrMarkSvg("zh-pin-mark")}<span class="zh-pin-word">HSRW</span></span>`;
  }

  function pinballElf() {
    return `
      <svg class="zh-pin-elf" viewBox="0 0 120 120" aria-hidden="true">
        <path d="M60,104 C40,104 30,92 30,78 L90,78 C90,92 80,104 60,104 Z" fill="#b3261e"/>
        <path d="M30,78 L90,78 L84,68 L36,68 Z" fill="#f7f4ee"/>
        <circle cx="60" cy="54" r="22" fill="#f2c9a0"/>
        <path d="M38,50 C38,32 48,22 60,22 C72,22 82,32 82,50 Z" fill="#1f6b4a"/>
        <path d="M60,22 C74,22 84,30 88,44 L74,44 C72,34 66,28 60,28 Z" fill="#17573a"/>
        <circle cx="88" cy="44" r="6" fill="#f7f4ee"/>
        <path d="M38,44 L26,36 L36,58 Z" fill="#f2c9a0"/>
        <path d="M82,44 L94,36 L84,58 Z" fill="#f2c9a0"/>
        <circle cx="52" cy="52" r="3" fill="#2b2b2b"/>
        <circle cx="68" cy="52" r="3" fill="#2b2b2b"/>
        <path d="M52,62 C56,67 64,67 68,62" stroke="#b3261e" stroke-width="2.6" fill="none" stroke-linecap="round"/>
        <circle cx="46" cy="60" r="4" fill="#e8928a" opacity=".8"/>
        <circle cx="74" cy="60" r="4" fill="#e8928a" opacity=".8"/>
      </svg>`;
  }

  function startPinball() {
    if (document.getElementById("zh-pinball")) return;
    pinballStyle();

    const breite = Math.max(380, Math.min(720, window.innerWidth - 80));
    const hoehe = Math.max(440, Math.min(580, window.innerHeight - 220));

    const host = document.createElement("div");
    host.id = "zh-pinball";
    host.innerHTML = `
      <div class="zh-pin-top">
        ${pinballBrand()}
        <div class="zh-pin-title">Pinball</div>
        <div class="zh-pin-level" id="zh-pin-level">Level 1</div>
        <div class="zh-pin-score" id="zh-pin-score">0</div>
      </div>
      <canvas id="zh-pin-board" width="${breite}" height="${hoehe}"></canvas>
      <div class="zh-pin-hint">
        <b>Leertaste</b> bringt die Kugel ins Spiel &middot;
        <b>Pfeiltasten</b> oder <b>A</b>/<b>D</b> f&uuml;r die Flipper &middot; <b>Esc</b> beendet
      </div>
      <button class="zh-pin-close" id="zh-pin-close" title="Schlie\u00dfen">\u00d7</button>
      <div class="zh-pin-intro" id="zh-pin-intro">
        <div class="zh-pin-card">
          ${pinballElf()}
          <h2>Oh, du hast eine kleine Auszeit verdient.</h2>
          <p>Weihnachten ist eine sch\u00f6ne, aber oft stressige Zeit.
             Wie w\u00e4re es mit ein paar Minuten Pinball? Vier Level, jeden Durchlauf neu gemischt.</p>
          <button id="zh-pin-start">Bisschen Pinball</button>
        </div>
      </div>
    `;
    document.body.appendChild(host);

    const canvas = host.querySelector("#zh-pin-board");
    const ctx = canvas.getContext("2d");
    const punkteAnzeige = host.querySelector("#zh-pin-score");
    const levelAnzeige = host.querySelector("#zh-pin-level");
    const intro = host.querySelector("#zh-pin-intro");

    const W = canvas.width;
    const H = canvas.height;
    const NAVY = "#2a2250";
    const BLAU = "#3c7fd1";
    const GOLD = "#ffd479";
    const ROT = "#e0492f";

    // ---------------- Zustand ----------------
    let punkte = 0;
    let levelPunkte = 0;
    let stufe = 0;
    let ziel = 0;
    let laeuft = true;
    let spielLaeuft = false;
    let letzterFrame = 0;
    let akkumulator = 0;
    let flipperL = 0;
    let flipperR = 0;
    let schuetteln = 0;
    let stillZeit = 0;
    let banner = null;
    let linksGedrueckt = false;
    let rechtsGedrueckt = false;

    // Feste Schrittweite: 240 Hz. Damit ist die Bewegung unabhaengig von der
    // Bildrate und die Kugel springt nicht durch duenne Hindernisse.
    const SCHRITT = 1 / 240;
    const GRAVITATION = 900;
    const DAEMPFUNG = 0.3;

    // Die Kugel kommt oben rechts ins Feld - ohne Abschussrampe.
    const kugel = { x: W * 0.6, y: 44, vx: 0, vy: 0, r: 7, imStart: true };
    const spur = [];
    const popups = [];
    const blitze = [];

    // Aussenbahn-Rampen: schliessen das Loch neben den Flippern und leiten
    // die Kugel auf den Flipper, ohne eine Tasche zu bilden.
    const aussenbahnen = [
      { x1: 22, y1: H - 200, x2: W * 0.335 - 8, y2: H - 86 },
      { x1: W - 22, y1: H - 200, x2: W * 0.665 + 8, y2: H - 86 }
    ];

    const wandLinks = 20;
    const wandRechts = W - 20;

    // ---------------- Level ----------------
    // Jede Karte hat wenige, grosse Hindernisse und wird pro Durchlauf leicht
    // verschoben und gedreht - dadurch spielt sich kein Level wie das andere.
    const KARTEN = [
      {
        name: "Y-Kreuz",
        ziel: 200,
        bauen: (add) => {
          add(W * 0.42, H * 0.3, -1.05, 118, 13, NAVY, 50);
          add(W * 0.58, H * 0.3, -1.95, 118, 13, BLAU, 50);
          add(W * 0.5, H * 0.2, 0.1, 52, 9, GOLD, 40);
          add(W * 0.22, H * 0.42, 0.9, 44, 8, BLAU, 25);
          add(W * 0.78, H * 0.42, -0.9, 44, 8, NAVY, 25);
        }
      },
      {
        name: "Stern",
        ziel: 260,
        bauen: (add) => {
          const n = 6;
          const radius = Math.min(W, H) * 0.17;
          for (let i = 0; i < n; i += 1) {
            const winkel = -Math.PI / 2 + (i * 2 * Math.PI) / n;
            add(
              W * 0.5 + Math.cos(winkel) * radius,
              H * 0.4 + Math.sin(winkel) * radius,
              winkel + Math.PI / 2,
              58,
              10,
              i % 2 === 0 ? BLAU : NAVY,
              35
            );
          }
        }
      },
      {
        name: "Zickzack",
        ziel: 320,
        bauen: (add) => {
          for (let reihe = 0; reihe < 3; reihe += 1) {
            for (let i = 0; i < 3; i += 1) {
              add(
                W * (0.24 + i * 0.26) + (reihe % 2 === 0 ? -W * 0.04 : W * 0.04),
                H * (0.26 + reihe * 0.17),
                reihe % 2 === 0 ? 0.6 : -0.6,
                52,
                9,
                reihe % 2 === 0 ? NAVY : BLAU,
                30
              );
            }
          }
        }
      },
      {
        name: "Tannenbaum",
        ziel: 400,
        bauen: (add) => {
          const stufen = 4;
          for (let i = 0; i < stufen; i += 1) {
            const breite = W * (0.1 + i * 0.05);
            add(W * 0.5 - breite, H * (0.26 + i * 0.13), 0.35, 46, 8, BLAU, 25);
            add(W * 0.5 + breite, H * (0.26 + i * 0.13), -0.35, 46, 8, NAVY, 25);
          }
          add(W * 0.5, H * 0.72, Math.PI / 2, 44, 9, GOLD, 45);
        }
      }
    ];

    const pins = [];
    const zufall = (() => {
      let saat = (Date.now() ^ Math.floor(Math.random() * 0xffff)) >>> 0;
      return () => {
        saat ^= saat << 13;
        saat >>>= 0;
        saat ^= saat >> 17;
        saat ^= saat << 5;
        saat >>>= 0;
        return saat / 0xffffffff;
      };
    })();



    const levelAufbau = () => {
      const karte = KARTEN[stufe % KARTEN.length];
      pins.length = 0;
      const jitterX = W * 0.03;
      const jitterY = H * 0.02;
      karte.bauen((x, y, a, len, r, farbe, wert) => {
        // Nichts im Bereich der Flipper und der Auslaeufe platzieren.
        const sicherY = Math.min(y + (zufall() - 0.5) * jitterY * 2, H - 250);
        pins.push({
          x: x + (zufall() - 0.5) * jitterX * 2,
          y: sicherY,
          a: a + (zufall() - 0.5) * 0.26,
          len,
          r,
          farbe,
          wert
        });
      });
      ziel = karte.ziel;
      levelPunkte = 0;
      levelAnzeige.textContent = `Level ${stufe + 1}/${KARTEN.length} · ${karte.name}`;
      banner = { text: `Level ${stufe + 1}: ${karte.name}`, leben: 1 };
      kugel.imStart = true;
      kugel.x = W * 0.6;
      kugel.y = 44;
      kugel.vx = 0;
      kugel.vy = 0;
    };

    // ---------------- Kollision ----------------
    const naechsterPunkt = (px, py, x1, y1, x2, y2) => {
      const dx = x2 - x1;
      const dy = y2 - y1;
      const laenge2 = dx * dx + dy * dy || 1;
      let t2 = ((px - x1) * dx + (py - y1) * dy) / laenge2;
      t2 = Math.max(0, Math.min(1, t2));
      return { x: x1 + t2 * dx, y: y1 + t2 * dy };
    };

    const treffer = (wert, x, y) => {
      punkte += wert;
      levelPunkte += wert;
      popups.push({ x, y, text: `+${wert}`, leben: 1 });
      blitze.push({ x, y, leben: 1 });
      schuetteln = Math.min(5, schuetteln + 1.2);
    };

    const kapsel = (x1, y1, x2, y2, radius, elastisch, wert) => {
      const cp = naechsterPunkt(kugel.x, kugel.y, x1, y1, x2, y2);
      const dx = kugel.x - cp.x;
      const dy = kugel.y - cp.y;
      const ab = Math.sqrt(dx * dx + dy * dy) || 0.0001;
      const grenze = radius + kugel.r;
      if (ab >= grenze) return false;

      const nx = dx / ab;
      const ny = dy / ab;
      kugel.x = cp.x + nx * grenze;
      kugel.y = cp.y + ny * grenze;
      const dot = kugel.vx * nx + kugel.vy * ny;
      if (dot < 0) {
        kugel.vx -= (1 + elastisch) * dot * nx;
        kugel.vy -= (1 + elastisch) * dot * ny;
      }
      if (wert) treffer(wert, cp.x, cp.y);
      return true;
    };

    // ---------------- Physik ----------------
    const bewege = (dt) => {
      const zielL = linksGedrueckt ? 1 : 0;
      const zielR = rechtsGedrueckt ? 1 : 0;
      flipperL += (zielL - flipperL) * Math.min(1, dt * 26);
      flipperR += (zielR - flipperR) * Math.min(1, dt * 26);

      if (kugel.imStart) return;

      kugel.vy += GRAVITATION * dt;
      const daempfung = Math.max(0, 1 - DAEMPFUNG * dt);
      kugel.vx *= daempfung;
      kugel.vy *= daempfung;
      kugel.x += kugel.vx * dt;
      kugel.y += kugel.vy * dt;

      // Waende
      if (kugel.x - kugel.r < wandLinks) {
        kugel.x = wandLinks + kugel.r;
        kugel.vx = Math.abs(kugel.vx) * 0.92;
      }
      if (kugel.x + kugel.r > wandRechts) {
        kugel.x = wandRechts - kugel.r;
        kugel.vx = -Math.abs(kugel.vx) * 0.92;
      }
      if (kugel.y - kugel.r < 24) {
        kugel.y = 24 + kugel.r;
        kugel.vy = Math.abs(kugel.vy) * 0.9;
      }

      // Pins
      for (const p of pins) {
        const dx = Math.cos(p.a) * p.len / 2;
        const dy = Math.sin(p.a) * p.len / 2;
        kapsel(p.x - dx, p.y - dy, p.x + dx, p.y + dy, p.r, 0.88, p.wert);
      }


      // Aussenbahnen
      for (const b of aussenbahnen) kapsel(b.x1, b.y1, b.x2, b.y2, 4, 0.15, 0);

      // Flipper
      const flipper = (px, py, len, radius, ruhe, aktiv, stellung) => {
        const winkel = ruhe + (aktiv - ruhe) * stellung;
        const x2 = px + Math.cos(winkel) * len;
        const y2 = py + Math.sin(winkel) * len;
        const getroffen = kapsel(px, py, x2, y2, radius, 0.25, 0);
        if (!getroffen) return;

        const nx = kugel.x - px;
        const ny = kugel.y - py;
        const ab = Math.sqrt(nx * nx + ny * ny) || 1;
        const schlag = 300 + stellung * 620;
        kugel.vx += (nx / ab) * schlag * 0.55 - Math.sin(winkel) * schlag * 0.5;
        kugel.vy += (ny / ab) * schlag * 0.55 + Math.cos(winkel) * schlag * 0.5 - 120;
      };
      // Drehpunkt an der Seitenwand, Spitzen treffen sich in der Mitte -
      // so bleibt neben dem Flipper kein Loch, durch das die Kugel faellt.
      const len = Math.min(W * 0.17, 122);
      flipper(W * 0.335, H - 78, len, 9.5, 0.34, -0.46, flipperL);
      flipper(W * 0.665, H - 78, len, 9.5, Math.PI - 0.34, Math.PI + 0.46, flipperR);

      // Haenger-Schutz: bleibt die Kugel zu lange liegen, bekommt sie einen
      // leichten Anstoss, damit das Spiel nicht stillsteht.
      const tempo = Math.sqrt(kugel.vx * kugel.vx + kugel.vy * kugel.vy);
      if (tempo < 45) {
        stillZeit += dt;
        if (stillZeit > 1.6) {
          kugel.vx += (zufall() - 0.5) * 320;
          kugel.vy -= 260;
          stillZeit = 0;
        }
      } else {
        stillZeit = 0;
      }

      // Aus
      if (kugel.y > H + 30) {
        kugel.imStart = true;
        kugel.x = W * 0.6;
        kugel.y = 44;
        kugel.vx = 0;
        kugel.vy = 0;
        punkte = Math.max(0, punkte - 20);
        levelPunkte = Math.max(0, levelPunkte - 20);
      }
    };

    const abschiessen = () => {
      if (!kugel.imStart) return;
      kugel.imStart = false;
      kugel.x = W * 0.6;
      kugel.y = 44;
      kugel.vx = -170;
      kugel.vy = 90;
      schuetteln = 2;
    };

    // ---------------- Zeichnen ----------------
    const zeichne = () => {
      ctx.save();
      ctx.translate((zufall() - 0.5) * schuetteln, (zufall() - 0.5) * schuetteln);

      const grund = ctx.createLinearGradient(0, 0, 0, H);
      grund.addColorStop(0, "#1b1a3d");
      grund.addColorStop(0.55, "#11132a");
      grund.addColorStop(1, "#08080f");
      ctx.fillStyle = grund;
      ctx.fillRect(-10, -10, W + 20, H + 20);

      // Wasserzeichen
      ctx.save();
      ctx.globalAlpha = 0.05;
      const sk = Math.min(W, H) / 220 * 0.62;
      ctx.translate(W * 0.5, H * 0.42);
      ctx.scale(sk, sk);
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.strokeStyle = NAVY;
      ctx.lineWidth = 38;
      ctx.beginPath();
      ctx.moveTo(-56, -50);
      ctx.lineTo(-14, -2);
      ctx.lineTo(-14, 60);
      ctx.stroke();
      ctx.fillStyle = BLAU;
      ctx.beginPath();
      ctx.moveTo(8, -22);
      ctx.lineTo(44, -66);
      ctx.lineTo(44, 52);
      ctx.arc(26, 52, 18, 0, Math.PI);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      // Schnee
      for (const f of flocken) {
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(240,246,255,${f.a})`;
        ctx.fill();
      }

      // Girlande
      ctx.strokeStyle = "#d3a862";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(wandLinks, 18);
      ctx.quadraticCurveTo(W / 2, 58, wandRechts, 18);
      ctx.stroke();
      for (let i = 0; i < 9; i += 1) {
        const t2 = i / 8;
        ctx.beginPath();
        ctx.arc(wandLinks + (wandRechts - wandLinks) * t2, 18 + Math.sin(Math.PI * t2) * 33 + 5, 3.4, 0, Math.PI * 2);
        ctx.fillStyle = i % 3 === 0 ? GOLD : i % 3 === 1 ? "#ff8f7a" : "#8fd3a8";
        ctx.shadowColor = ctx.fillStyle;
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // Levelanzeige
      ctx.textAlign = "left";
      ctx.fillStyle = "rgba(233,240,252,.85)";
      ctx.font = "700 14px system-ui, Segoe UI";
      const karte = KARTEN[stufe % KARTEN.length];
      ctx.fillText(`Level ${stufe + 1}/${KARTEN.length} · ${karte.name}`, 26, 84);
      ctx.fillText(`${levelPunkte} / ${ziel}`, 26, 102);
      const balken = Math.min(1, ziel ? levelPunkte / ziel : 0);
      ctx.fillStyle = "rgba(255,255,255,.14)";
      ctx.fillRect(26, 108, W * 0.36, 5);
      ctx.fillStyle = GOLD;
      ctx.fillRect(26, 108, W * 0.36 * balken, 5);

      // Pins
      for (const p of pins) {
        const dx = Math.cos(p.a) * p.len / 2;
        const dy = Math.sin(p.a) * p.len / 2;
        ctx.lineCap = "round";
        ctx.strokeStyle = p.farbe;
        ctx.lineWidth = p.r * 2;
        ctx.beginPath();
        ctx.moveTo(p.x - dx, p.y - dy);
        ctx.lineTo(p.x + dx, p.y + dy);
        ctx.stroke();
        ctx.strokeStyle = "rgba(255,255,255,.2)";
        ctx.lineWidth = Math.max(1.6, p.r * 0.3);
        ctx.beginPath();
        ctx.moveTo(p.x - dx * 0.7 - 2, p.y - dy * 0.7 - 3);
        ctx.lineTo(p.x + dx * 0.7 - 2, p.y + dy * 0.7 - 3);
        ctx.stroke();
      }


      // Bahnkurve oben rechts (Optik)
      ctx.strokeStyle = "rgba(211,168,98,.45)";
      ctx.lineWidth = 5;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(W - 24, 168);
      ctx.quadraticCurveTo(W - 34, 74, W * 0.64, 40);
      ctx.stroke();

      // Aussenbahnen
      for (const b of aussenbahnen) {
        ctx.strokeStyle = "rgba(211,168,98,.6)";
        ctx.lineWidth = 8;
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(b.x1, b.y1);
        ctx.lineTo(b.x2, b.y2);
        ctx.stroke();
      }

      // Flipper
      const flipperZeichnen = (px, py, len, radius, ruhe, aktiv, stellung) => {
        const winkel = ruhe + (aktiv - ruhe) * stellung;
        const x2 = px + Math.cos(winkel) * len;
        const y2 = py + Math.sin(winkel) * len;
        ctx.lineCap = "round";
        ctx.strokeStyle = ROT;
        ctx.lineWidth = radius * 2;
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        ctx.strokeStyle = "rgba(255,255,255,.32)";
        ctx.lineWidth = Math.max(1.5, radius * 0.3);
        ctx.beginPath();
        ctx.moveTo(px + 2, py - 2);
        ctx.lineTo(x2 + 2, y2 - 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(px, py, 4.6, 0, Math.PI * 2);
        ctx.fillStyle = GOLD;
        ctx.fill();
      };
      const flen = Math.min(W * 0.17, 122);
      flipperZeichnen(W * 0.335, H - 78, flen, 9.5, 0.34, -0.46, flipperL);
      flipperZeichnen(W * 0.665, H - 78, flen, 9.5, Math.PI - 0.34, Math.PI + 0.46, flipperR);

      // Spur
      for (const s of spur) {
        if (s.leben <= 0) continue;
        ctx.beginPath();
        ctx.arc(s.x, s.y, kugel.r * s.leben * 0.8, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(127,179,255,${0.15 * s.leben})`;
        ctx.fill();
      }

      // Kugel
      if (!kugel.imStart || true) {
        ctx.beginPath();
        ctx.arc(kugel.x, kugel.y, kugel.r, 0, Math.PI * 2);
        const kg = ctx.createRadialGradient(kugel.x - 2.4, kugel.y - 2.6, 0.6, kugel.x, kugel.y, kugel.r);
        kg.addColorStop(0, "#ffffff");
        kg.addColorStop(1, "#9fbde3");
        ctx.fillStyle = kg;
        ctx.shadowColor = "#8fbfff";
        ctx.shadowBlur = 12;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      for (const b of blitze) {
        ctx.beginPath();
        ctx.arc(b.x, b.y, (1 - b.leben) * 28 + 6, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255,212,121,${b.leben * 0.5})`;
        ctx.lineWidth = 2.2;
        ctx.stroke();
      }

      ctx.textAlign = "center";
      for (const p of popups) {
        if (!p.text) continue;
        ctx.fillStyle = `rgba(255,235,180,${Math.min(1, p.leben)})`;
        ctx.font = "700 15px system-ui, Segoe UI";
        ctx.fillText(p.text, p.x, p.y);
      }

      if (banner) {
        ctx.globalAlpha = Math.min(1, banner.leben);
        ctx.fillStyle = "rgba(0,0,0,.45)";
        ctx.fillRect(0, H * 0.42, W, 58);
        ctx.fillStyle = GOLD;
        ctx.font = "800 24px system-ui, Segoe UI";
        ctx.textAlign = "center";
        ctx.fillText(banner.text, W / 2, H * 0.42 + 37);
        ctx.globalAlpha = 1;
      }

      ctx.strokeStyle = "rgba(211,168,98,.8)";
      ctx.lineWidth = 3;
      ctx.strokeRect(4.5, 4.5, W - 9, H - 9);
      ctx.restore();
    };

    // ---------------- Schleife ----------------
    const frame = (zeit) => {
      if (!laeuft) return;
      const dt = letzterFrame ? Math.min(50, zeit - letzterFrame) / 1000 : SCHRITT;
      letzterFrame = zeit;

      if (spielLaeuft) {
        akkumulator += dt;
        let schritte = 0;
        while (akkumulator >= SCHRITT && schritte < 24) {
          bewege(SCHRITT);
          akkumulator -= SCHRITT;
          schritte += 1;
        }

        // Level geschafft?
        if (levelPunkte >= ziel) {
          stufe += 1;
          if (stufe >= KARTEN.length) {
            stufe = 0;
            punkte += 200;
            banner = { text: "Alle Level geschafft - Bonus 200", leben: 1.6 };
          }
          levelAufbau();
        }

        // Spur
        if (!kugel.imStart) {
          spur.push({ x: kugel.x, y: kugel.y, leben: 1 });
          if (spur.length > 14) spur.shift();
        }
        for (const s of spur) s.leben -= dt * 2.6;
        for (let i = popups.length - 1; i >= 0; i -= 1) {
          popups[i].leben -= dt * 1.1;
          popups[i].y -= dt * 42;
          if (popups[i].leben <= 0) popups.splice(i, 1);
        }
        for (let i = blitze.length - 1; i >= 0; i -= 1) {
          blitze[i].leben -= dt * 3;
          if (blitze[i].leben <= 0) blitze.splice(i, 1);
        }
        if (banner) {
          banner.leben -= dt * 0.8;
          if (banner.leben <= 0) banner = null;
        }
        schuetteln *= Math.max(0, 1 - dt * 8);
      }

      punkteAnzeige.textContent = String(punkte);
      zeichne();
      requestAnimationFrame(frame);
    };

    const aufTaste = (event) => {
      const taste = event.key.toLowerCase();
      const unten = event.type === "keydown";
      if (event.key === "Escape") { schliessen(); return; }
      if (taste === "arrowleft" || taste === "a") { linksGedrueckt = unten; event.preventDefault(); }
      if (taste === "arrowright" || taste === "d") { rechtsGedrueckt = unten; event.preventDefault(); }
      if (event.code === "Space") {
        event.preventDefault();
        if (unten) abschiessen();
      }
    };

    let geschlossen = false;
    function schliessen() {
      if (geschlossen) return;
      geschlossen = true;
      laeuft = false;
      window.removeEventListener("keydown", aufTaste);
      window.removeEventListener("keyup", aufTaste);
      host.remove();
      removeStyle("zh-pinball-style");
    }

    host.querySelector("#zh-pin-start").addEventListener("click", () => {
      intro.classList.add("zh-weg");
      spielLaeuft = true;
    });
    host.querySelector("#zh-pin-close").addEventListener("click", schliessen);
    window.addEventListener("keydown", aufTaste);
    window.addEventListener("keyup", aufTaste);

    const flocken = Array.from({ length: 44 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
      r: 0.8 + Math.random() * 1.9,
      v: 0.16 + Math.random() * 0.5,
      a: 0.18 + Math.random() * 0.35
    }));

    levelAufbau();
    requestAnimationFrame(frame);
  }

  function disablePinball() {
    document.getElementById("zh-pinball")?.remove();
    removeStyle("zh-pinball-style");
  }

  // Kugeln und Laempchen der Deko wirken ebenfalls antimagnetisch: Sie weichen
  // dem Zeiger aus und schwingen zurueck, sobald er weiterzieht.
  function startChristmasMagnet(overlay) {
    const sammeln = () =>
      Array.from(overlay.querySelectorAll(".zh-xmas-bauble, .zh-xmas-bulb-glow, .zh-xmas-tree-light"));

    let ziele = [];
    let rects = [];
    let frame = 0;
    let laeuft = true;
    const versatz = new Map();
    const maus = { x: -9999, y: -9999, aktiv: false, zeit: 0 };

    const messen = () => {
      ziele = sammeln();
      rects = ziele.map((el) => {
        const r = el.getBoundingClientRect();
        return { el, cx: r.left + r.width / 2, cy: r.top + r.height / 2 };
      });
    };

    const aufZeiger = (event) => {
      maus.x = event.clientX;
      maus.y = event.clientY;
      maus.aktiv = true;
      maus.zeit = performance.now();
    };

    const zeigerWeg = () => {
      maus.aktiv = false;
    };

    const radius = 130;

    const schleife = () => {
      if (!laeuft) return;
      const aktiv = maus.aktiv && performance.now() - maus.zeit < 1500;

      for (const ziel of rects) {
        let zielX = 0;
        let zielY = 0;

        if (aktiv) {
          const dx = ziel.cx - maus.x;
          const dy = ziel.cy - maus.y;
          const abstand = Math.sqrt(dx * dx + dy * dy) || 1;
          if (abstand < radius) {
            const kraft = (1 - abstand / radius) * 16;
            zielX = (dx / abstand) * kraft;
            zielY = (dy / abstand) * kraft;
          }
        }

        const alt = versatz.get(ziel.el) || { x: 0, y: 0 };
        const nx = alt.x + (zielX - alt.x) * 0.16;
        const ny = alt.y + (zielY - alt.y) * 0.16;
        versatz.set(ziel.el, { x: nx, y: ny });

        if (Math.abs(nx) < 0.05 && Math.abs(ny) < 0.05) {
          ziel.el.style.transform = "";
        } else {
          ziel.el.style.transform = `translate(${nx.toFixed(2)}px, ${ny.toFixed(2)}px)`;
        }
      }

      frame = window.requestAnimationFrame(schleife);
    };

    let messTimer = 0;
    const beiGroesse = () => {
      window.clearTimeout(messTimer);
      messTimer = window.setTimeout(messen, 220);
    };

    messen();
    window.addEventListener("pointermove", aufZeiger, { passive: true });
    window.addEventListener("pointerleave", zeigerWeg);
    window.addEventListener("resize", beiGroesse);
    frame = window.requestAnimationFrame(schleife);

    return () => {
      laeuft = false;
      window.cancelAnimationFrame(frame);
      window.clearTimeout(messTimer);
      window.removeEventListener("pointermove", aufZeiger);
      window.removeEventListener("pointerleave", zeigerWeg);
      window.removeEventListener("resize", beiGroesse);
      for (const el of ziele) el.style.transform = "";
    };
  }

  function enableChristmasMode() {
    if (window.top !== window.self) return;
    if (document.getElementById(CHRISTMAS_OVERLAY_ID)) return;

    if (!document.body) {
      document.addEventListener("DOMContentLoaded", enableChristmasMode, { once: true });
      return;
    }

    addChristmasStyles();

    // Zwei Ebenen: Die Deko liegt unter Znunys Dialogen, Schnee und
    // Schlitten duerfen obenauf liegen.
    const hintergrund = document.createElement("div");
    hintergrund.id = CHRISTMAS_BACK_ID;
    hintergrund.className = "zh-xmas-layer zh-xmas-layer--back";
    hintergrund.setAttribute("aria-hidden", "true");
    hintergrund.innerHTML = `
      ${CHRISTMAS_DEFS}
      ${CHRISTMAS_MISTLETOE}
      ${christmasTreeSvg()}
      ${CHRISTMAS_SPARKS}
    `;

    const overlay = document.createElement("div");
    overlay.id = CHRISTMAS_OVERLAY_ID;
    overlay.className = "zh-xmas-layer zh-xmas-layer--front";
    overlay.setAttribute("aria-hidden", "true");
    overlay.innerHTML = `
      <canvas class="zh-xmas-snow"></canvas>
      <div class="zh-xmas-glow"></div>
      <div class="zh-xmas-fly" hidden>${christmasSleighScene()}</div>
    `;

    document.body.appendChild(hintergrund);
    document.body.appendChild(overlay);
    renderChristmasGarland(hintergrund);

    // Dreimal auf den Baum klicken (innerhalb von 1,8 s) startet das Pinball-
    // Minigame. Ein eigener Zaehler verhindert, dass normale Klicks stoeren.
    const baum = hintergrund.querySelector(".zh-xmas-tree");
    let baumKlicks = 0;
    let baumTimer = 0;
    const baumAnim = document.createElement("style");
    baumAnim.dataset.zhPinballHint = "1";
    baumAnim.textContent =
      "#zh-christmas .zh-xmas-tree:active { transform: scale(.96); }";
    document.head.appendChild(baumAnim);

    const oeuml = document.createElement("div");
    const pinballAktiv = () => Boolean(document.getElementById("zh-pinball"));
    const baumAnklicken = () => {
      baumKlicks += 1;
      window.clearTimeout(baumTimer);
      baumTimer = window.setTimeout(() => { baumKlicks = 0; }, 1800);
      if (baumKlicks >= 3) {
        baumKlicks = 0;
        if (!pinballAktiv()) {
          try {
            startPinball();
          } catch (fehler) {
            window.__zhPinErr = String(fehler && fehler.stack ? fehler.stack : fehler);
          }
        }
      }
    };
    baum?.addEventListener("click", baumAnklicken);
    baum?.setAttribute("role", "button");
    baum?.setAttribute("aria-label", "Pinball (dreimal klicken)");

    // Die Girlande haengt an der Fensterbreite: bei Aenderung neu zeichnen.
    let garlandTimer = 0;
    const onGarlandResize = () => {
      window.clearTimeout(garlandTimer);
      garlandTimer = window.setTimeout(() => renderChristmasGarland(overlay), 200);
    };
    window.addEventListener("resize", onGarlandResize);

    // Baum und Zweig nur, wenn die Seite nicht scrollt: sonst liegen sie ueber
    // den Ticketzeilen. Nach dem Nachladen von Znuny nochmals pruefen.
    const pruefePlatz = () => {
      const knapp = document.documentElement.scrollHeight > window.innerHeight + 60;
      overlay.classList.toggle("zh-xmas-knapp", knapp);
      hintergrund.classList.toggle("zh-xmas-knapp", knapp);
    };
    pruefePlatz();
    window.setTimeout(pruefePlatz, 1200);
    window.setTimeout(pruefePlatz, 3000);

    christmasCleanupFns = [
      startChristmasSnow(overlay.querySelector("canvas.zh-xmas-snow")),
      startChristmasFlyover(overlay),
      startChristmasMagnet(overlay),
      () => {
        window.clearTimeout(garlandTimer);
        window.removeEventListener("resize", onGarlandResize);
      },
      () => {
        window.clearTimeout(baumTimer);
        baum?.removeEventListener("click", baumAnklicken);
        baumAnim?.remove();
        disablePinball();
      }
    ];
  }

  function disableChristmasMode() {
    christmasCleanupFns.forEach((aufraeumen) => {
      try {
        aufraeumen();
      } catch {
        /* Aufraeumen darf nie den Betrieb stoeren */
      }
    });
    christmasCleanupFns = [];

    document.getElementById(CHRISTMAS_OVERLAY_ID)?.remove();
    document.getElementById(CHRISTMAS_BACK_ID)?.remove();
    removeStyle("zh-christmas-style");
  }

  // ---- EASM-Bewertung ---------------------------------------------------
  // Die EASM-Tickets enthalten je Schwachstelle einen Block "Criticality" mit
  // Low/Medium/High/Critical. Der Artikeltext ist NICHT im Seiten-HTML; Znuny
  // laedt ihn als eigenes Dokument (GET, ohne JavaScript):
  //   Action=AgentTicketArticleContent;Subaction=HTMLView;TicketID=..;ArticleID=..
  // Daraus lesen wir die Stufen, nehmen die schwerste und zeigen sie als Badge.
  const EASM_LEVELS = ["low", "medium", "high", "critical"];
  const EASM_LABELS = { low: "Niedrig", medium: "Mittel", high: "Hoch", critical: "Kritisch" };
  const EASM_SHORT = { low: "LOW", medium: "MED", high: "HIGH", critical: "CRIT" };
  const EASM_BUTTON_ID = "zh-easm-button";
  const EASM_BADGE_ID = "zh-easm-badge";

  function parseEasmCriticalities(text) {
    const gefunden = [];
    // Zwischen "Criticality" und dem Wert koennen Labels oder Zellen stehen.
    const muster = /Criticality[^A-Za-z]{0,40}(Low|Medium|High|Critical)\b/gi;
    let treffer = muster.exec(String(text || ""));
    while (treffer !== null) {
      gefunden.push(treffer[1].toLowerCase());
      treffer = muster.exec(String(text || ""));
    }
    return gefunden;
  }

  function summarizeEasm(stufen) {
    if (!stufen || !stufen.length) return null;

    const zaehler = { low: 0, medium: 0, high: 0, critical: 0 };
    stufen.forEach((stufe) => {
      if (zaehler[stufe] !== undefined) zaehler[stufe] += 1;
    });

    let schwerste = "low";
    EASM_LEVELS.forEach((stufe) => {
      if (zaehler[stufe] > 0) schwerste = stufe;
    });

    return { schwerste, zaehler, anzahl: stufen.length };
  }

  function easmTicketId() {
    return location.href.match(/[?;&]TicketID=(\d+)/i)?.[1] || "";
  }

  async function ladeEasmArtikelIds(ticketId) {
    const antwort = await fetch(`/otrs/index.pl?Action=AgentTicketZoom;TicketID=${encodeURIComponent(ticketId)}`, {
      credentials: "same-origin"
    });
    if (!antwort.ok) throw new Error(`Ticketseite ${antwort.status}`);
    const html = await antwort.text();
    const doc = new DOMParser().parseFromString(html, "text/html");

    return [...doc.querySelectorAll("input.ArticleID")]
      .map((feld) => feld.value)
      .filter(Boolean)
      .map((id) => Number(id))
      .sort((links, rechts) => rechts - links);
  }

  async function ladeEasmArtikelText(ticketId, articleId) {
    const url =
      `/otrs/index.pl?Action=AgentTicketArticleContent;Subaction=HTMLView` +
      `;TicketID=${encodeURIComponent(ticketId)};ArticleID=${encodeURIComponent(articleId)};FileID=;`;
    const antwort = await fetch(url, { credentials: "same-origin" });
    if (!antwort.ok) throw new Error(`Artikel ${antwort.status}`);
    const html = await antwort.text();
    const doc = new DOMParser().parseFromString(html, "text/html");
    return (doc.body?.textContent || "").trim();
  }

  function zeigeEasmErgebnis(zusammenfassung, fehler, quelle) {
    let badge = document.getElementById(EASM_BADGE_ID);
    if (!badge) {
      badge = document.createElement("span");
      badge.id = EASM_BADGE_ID;
      badge.className = "zh-easm-badge";
      const knopf = document.getElementById(EASM_BUTTON_ID);
      (knopf?.parentElement || document.body).insertBefore(badge, knopf?.nextSibling || null);
    }

    if (fehler) {
      badge.className = "zh-easm-badge zh-easm-badge--none";
      badge.textContent = "EASM: Fehler";
      badge.title = fehler;
      return;
    }

    if (!zusammenfassung) {
      badge.className = "zh-easm-badge zh-easm-badge--none";
      badge.textContent = "EASM: keine Einstufung";
      badge.title = "Im neuesten Artikel wurde kein Block \"Criticality\" gefunden.";
      return;
    }

    const teile = EASM_LEVELS
      .slice()
      .reverse()
      .filter((stufe) => zusammenfassung.zaehler[stufe] > 0)
      .map((stufe) => `${zusammenfassung.zaehler[stufe]}\u00d7${EASM_SHORT[stufe]}`);

    badge.className = `zh-easm-badge zh-easm-badge--${zusammenfassung.schwerste}`;
    badge.textContent = `${EASM_SHORT[zusammenfassung.schwerste]} \u00b7 ${teile.join(" ")}`;
    badge.title =
      `EASM-Einstufung: ${EASM_LABELS[zusammenfassung.schwerste]}\n` +
      teile.join(", ") +
      `\n(${zusammenfassung.anzahl} Fund(e), schwerste Stufe gewinnt)` +
      (quelle ? `\naus Artikel ${quelle}` : "");
  }

  async function bewerteEasmTicket() {
    const knopf = document.getElementById(EASM_BUTTON_ID);
    const ticketId = easmTicketId();
    if (!ticketId) return;

    if (knopf) {
      knopf.disabled = true;
      knopf.textContent = "EASM: \u2026";
    }

    try {
      const ids = await ladeEasmArtikelIds(ticketId);
      if (!ids.length) {
        zeigeEasmErgebnis(null, "Keine Artikel gefunden.");
        return;
      }

      // Der neueste Artikel ist oft nur eine Notiz ("wird nicht bearbeitet").
      // Deshalb alle Artikel von neu nach alt lesen und den ersten mit einer
      // Einstufung nehmen.
      let zusammenfassung = null;
      let quelle = "";
      for (const id of ids) {
        const text = await ladeEasmArtikelText(ticketId, id);
        const stufen = parseEasmCriticalities(text);
        if (!stufen.length) continue;
        zusammenfassung = summarizeEasm(stufen);
        quelle = id;
        break;
      }

      zeigeEasmErgebnis(zusammenfassung, null, quelle);
    } catch (error) {
      zeigeEasmErgebnis(null, `Bewertung fehlgeschlagen: ${error.message}`);
    } finally {
      if (knopf) {
        knopf.disabled = false;
        knopf.textContent = "EASM bewerten";
      }
    }
  }

  function enableEasmRating() {
    if (window.top !== window.self) return;
    if (!/Action=AgentTicketZoom\b/i.test(location.href)) return;
    if (document.getElementById(EASM_BUTTON_ID)) return;

    const titel = document.querySelector("#Content h1, h1");
    if (!titel) return;

    // Nur bei EASM-Tickets: Betreff oder sichtbarer Titel muss "EASM" enthalten.
    const kopfText = `${titel.textContent || ""} ${document.title || ""}`;
    if (!/\bEASM\b|\[EASM\]|EASM\s*-/i.test(kopfText)) return;

    addEasmStyles();

    const knopf = document.createElement("button");
    knopf.type = "button";
    knopf.id = EASM_BUTTON_ID;
    knopf.className = "zh-easm-btn";
    knopf.textContent = "EASM bewerten";
    knopf.title = "Einstufung des neuesten Artikels auslesen (nur lesend)";
    knopf.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      bewerteEasmTicket();
    });

    titel.insertAdjacentElement("afterend", knopf);
  }

  function disableEasmRating() {
    document.getElementById(EASM_BUTTON_ID)?.remove();
    document.getElementById(EASM_BADGE_ID)?.remove();
  }

  function runEnabledFeatures() {
    suppressMutationScanUntil = Date.now() + 500;
    dispatchPageSettings();

    // Dekoration gilt auf allen Seiten - auch im Kundenportal, deshalb vor der
    // Abzweigung dorthin.
    if (settings.christmasMode) enableChristmasMode();
    else disableChristmasMode();

    if (isCustomerPortal()) {
      runCustomerPortalFeatures();
      return;
    }

    if (settings.attachmentPreview) enableAttachmentPreview();
    else disableAttachmentPreview();

    if (settings.ticketNumberSearch) fixTicketNumberSearch();
    else restoreTicketNumberSearch();

    if (settings.ticketArticleSearch) enableTicketArticleSearch();
    else disableTicketArticleSearch();

    if (settings.ticketNumberCopy) enableTicketNumberCopy();
    else disableTicketNumberCopy();

    if (settings.ebHelper) enableEbHelper();
    else disableEbHelper();

    if (settings.priorityTemplates) enablePriorityTemplates();
    else disablePriorityTemplates();

    if (settings.quickReply) enableQuickReply();
    else disableQuickReply();

    if (settings.ticketCategories) applyTicketCategories();
    else disableTicketCategories();

    // "Search results in a new tab" is handled entirely in page-bridge.js (MAIN
    // world), where window.open and the search form can be patched reliably. The
    // former second implementation in this isolated world was removed.

    if (settings.directArticleActions) enableDirectArticleActions();
    else disableDirectArticleActions();

    if (settings.easmRating) enableEasmRating();
    else disableEasmRating();

    if (settings.ticketListInfiniteScroll) enableTicketListInfiniteScroll();
    else disableTicketListInfiniteScroll();

    enableCloseTabAfterSubmit();
    enableActionPopupCancelFallback();

    if (settings.pendingDateButtons) enablePendingDateQuickButtons();
    else disablePendingDateQuickButtons();

    enableSubmitShortcut();
    expandArticleWidget();
    enableLogoPongEasterEgg();
  }

  function findAgentAvatarElement() {
    const candidates = [...document.querySelectorAll("div, span, a")].filter((element) => {
      if (element.children.length > 0) return false;

      const text = normalizeText(element.textContent || "");
      if (!/^[A-ZÄÖÜ]{2,3}$/.test(text)) return false;

      const rect = element.getBoundingClientRect();
      if (rect.width < 16 || rect.width > 80) return false;
      if (Math.abs(rect.width - rect.height) > 12) return false;
      if (rect.top > 120 || rect.bottom < 0) return false;

      const style = window.getComputedStyle(element);
      const radius = Number.parseFloat(style.borderRadius) || 0;
      if (radius < rect.width * 0.3) return false;

      return elementIsVisible(element);
    });

    return candidates[0] || null;
  }

  function enableLogoPongEasterEgg() {
    const avatar = findAgentAvatarElement();
    if (!avatar || avatar.dataset.zhPongBound) return;

    avatar.dataset.zhPongBound = "1";
    avatar.style.cursor = "pointer";

    let hoverTimer = null;
    avatar.addEventListener("mouseenter", () => {
      hoverTimer = window.setTimeout(openLogoPongModal, 3000);
    });
    avatar.addEventListener("mouseleave", () => {
      window.clearTimeout(hoverTimer);
    });
  }

  const LOGO_PONG_COLORS = { left: "#2c2569", right: "#3f6fd8", ball: "#1c1b29", line: "#e2dfee" };

  function addLogoPongStyles() {
    addStyle("zh-pong-style", `
      .zh-pong-backdrop { position: fixed; inset: 0; z-index: 100000; display: flex; align-items: center; justify-content: center; background: rgba(20, 20, 30, .55); color-scheme: light; }
      .zh-pong-modal { width: min(640px, calc(100vw - 48px)); background: #fff; color: #1c1b29; border-radius: 14px; box-shadow: 0 24px 64px rgba(0,0,0,.4); overflow: hidden; }
      .zh-pong-modal header { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; padding: 16px 20px; border-bottom: 1px solid #e7e5ef; }
      .zh-pong-modal h2 { margin: 0 0 4px; font-size: 17px; }
      .zh-pong-modal header p { margin: 0; font-size: 12.5px; color: #6b6880; }
      .zh-pong-close { border: none; background: #efedf5; color: #1c1b29; border-radius: 999px; padding: 7px 16px; font-size: 12.5px; font-weight: 600; cursor: pointer; }
      .zh-pong-close:hover { background: #e2dff0; }
      .zh-pong-legend { display: flex; gap: 20px; padding: 10px 20px; font-size: 12.5px; color: #4b4860; }
      .zh-pong-legend strong { color: #1c1b29; }
      .zh-pong-court { margin: 0 20px 20px; border: 1px solid #e7e5ef; border-radius: 12px; overflow: hidden; background: #fff; }
      .zh-pong-court canvas { display: block; width: 100%; height: 360px; touch-action: none; cursor: none; }
    `);
  }

  function drawLogoPongLeftPaddle(ctx, x, centerY, height, color) {
    const top = centerY - height / 2;
    const bottom = centerY + height / 2;
    const cornerY = top + height * 0.42;
    const reach = height * 0.34;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 10;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(x - reach, top);
    ctx.lineTo(x, cornerY);
    ctx.lineTo(x, bottom);
    ctx.stroke();
    ctx.restore();
  }

  function drawLogoPongRightPaddle(ctx, x, centerY, height, color) {
    const top = centerY - height / 2;
    const bottom = centerY + height / 2;
    const cornerY = top + height * 0.42;
    const reach = height * 0.34;

    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 10;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(x + reach, top);
    ctx.lineTo(x, cornerY);
    ctx.lineTo(x, bottom);
    ctx.stroke();
    ctx.restore();
  }

  function startLogoPongGame(canvas) {
    const ctx = canvas.getContext("2d");
    const width = canvas.width;
    const height = canvas.height;
    const paddleHeight = 70;
    const paddleMargin = 26;
    const ballRadius = 7;

    const state = {
      leftY: height / 2,
      rightY: height / 2,
      targetLeftY: height / 2,
      ballX: width / 2,
      ballY: height / 2,
      ballVX: 4.2,
      ballVY: 2.4,
      leftScore: 0,
      rightScore: 0,
      running: true,
      frame: 0
    };

    function resetBall(direction) {
      state.ballX = width / 2;
      state.ballY = height / 2;
      state.ballVX = 4.2 * direction;
      state.ballVY = Math.random() * 4 - 2;
    }

    function onPointerMove(event) {
      const rect = canvas.getBoundingClientRect();
      const scaleY = height / rect.height;
      state.targetLeftY = (event.clientY - rect.top) * scaleY;
    }

    canvas.addEventListener("pointermove", onPointerMove);

    function draw() {
      ctx.clearRect(0, 0, width, height);

      ctx.strokeStyle = LOGO_PONG_COLORS.line;
      ctx.setLineDash([6, 10]);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(width / 2, 0);
      ctx.lineTo(width / 2, height);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.textAlign = "center";
      ctx.font = "700 22px system-ui, sans-serif";
      ctx.fillStyle = LOGO_PONG_COLORS.left;
      ctx.fillText(String(state.leftScore), width / 2 - 60, 40);
      ctx.fillStyle = LOGO_PONG_COLORS.right;
      ctx.fillText(String(state.rightScore), width / 2 + 60, 40);

      drawLogoPongLeftPaddle(ctx, paddleMargin, state.leftY, paddleHeight, LOGO_PONG_COLORS.left);
      drawLogoPongRightPaddle(ctx, width - paddleMargin, state.rightY, paddleHeight, LOGO_PONG_COLORS.right);

      ctx.fillStyle = LOGO_PONG_COLORS.ball;
      ctx.beginPath();
      ctx.arc(state.ballX, state.ballY, ballRadius, 0, Math.PI * 2);
      ctx.fill();
    }

    function step() {
      if (!state.running) return;

      state.leftY += (state.targetLeftY - state.leftY) * 0.25;
      state.leftY = Math.min(height - paddleHeight / 2, Math.max(paddleHeight / 2, state.leftY));

      state.rightY += (state.ballY - state.rightY) * 0.08;
      state.rightY = Math.min(height - paddleHeight / 2, Math.max(paddleHeight / 2, state.rightY));

      state.ballX += state.ballVX;
      state.ballY += state.ballVY;

      if (state.ballY < ballRadius || state.ballY > height - ballRadius) {
        state.ballVY *= -1;
        state.ballY = Math.min(height - ballRadius, Math.max(ballRadius, state.ballY));
      }

      const leftPaddleX = paddleMargin;
      const rightPaddleX = width - paddleMargin;

      if (
        state.ballVX < 0 &&
        state.ballX - ballRadius <= leftPaddleX + 6 &&
        state.ballX - ballRadius >= leftPaddleX - 12 &&
        Math.abs(state.ballY - state.leftY) <= paddleHeight / 2 + ballRadius
      ) {
        state.ballVX = Math.abs(state.ballVX) * 1.03;
        state.ballVY += (state.ballY - state.leftY) * 0.05;
      }

      if (
        state.ballVX > 0 &&
        state.ballX + ballRadius >= rightPaddleX - 6 &&
        state.ballX + ballRadius <= rightPaddleX + 12 &&
        Math.abs(state.ballY - state.rightY) <= paddleHeight / 2 + ballRadius
      ) {
        state.ballVX = -Math.abs(state.ballVX) * 1.03;
        state.ballVY += (state.ballY - state.rightY) * 0.05;
      }

      if (state.ballX < 0) {
        state.rightScore += 1;
        resetBall(1);
      } else if (state.ballX > width) {
        state.leftScore += 1;
        resetBall(-1);
      }

      draw();
      state.frame = window.requestAnimationFrame(step);
    }

    draw();
    state.frame = window.requestAnimationFrame(step);

    return {
      stop() {
        state.running = false;
        if (state.frame) window.cancelAnimationFrame(state.frame);
        canvas.removeEventListener("pointermove", onPointerMove);
      }
    };
  }

  function openLogoPongModal() {
    if (document.querySelector(".zh-pong-backdrop")) return;

    addLogoPongStyles();

    const backdrop = document.createElement("div");
    backdrop.className = "zh-pong-backdrop";

    const modal = document.createElement("div");
    modal.className = "zh-pong-modal";

    const header = document.createElement("header");
    const heading = document.createElement("div");
    const title = document.createElement("h2");
    title.textContent = "Logo Pong";
    heading.appendChild(title);

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.className = "zh-pong-close";
    closeButton.textContent = "Schließen";

    header.appendChild(heading);
    header.appendChild(closeButton);

    const legend = document.createElement("div");
    legend.className = "zh-pong-legend";

    const leftLegend = document.createElement("span");
    const leftLabel = document.createElement("strong");
    leftLabel.textContent = "Links:";
    leftLegend.appendChild(leftLabel);
    leftLegend.appendChild(document.createTextNode(" HSRW Indigo"));

    const rightLegend = document.createElement("span");
    const rightLabel = document.createElement("strong");
    rightLabel.textContent = "Rechts:";
    rightLegend.appendChild(rightLabel);
    rightLegend.appendChild(document.createTextNode(" Campus Blau"));

    legend.appendChild(leftLegend);
    legend.appendChild(rightLegend);

    const court = document.createElement("div");
    court.className = "zh-pong-court";
    const canvas = document.createElement("canvas");
    canvas.width = 600;
    canvas.height = 360;
    court.appendChild(canvas);

    modal.appendChild(header);
    modal.appendChild(legend);
    modal.appendChild(court);
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);

    const game = startLogoPongGame(canvas);

    function close() {
      game.stop();
      backdrop.remove();
      document.removeEventListener("keydown", onKeydown);
    }

    function onKeydown(event) {
      if (event.key === "Escape") close();
    }

    closeButton.addEventListener("click", close);
    backdrop.addEventListener("click", (event) => {
      if (event.target === backdrop) close();
    });
    document.addEventListener("keydown", onKeydown);
  }

  // ---- Diagnose (Popup) -------------------------------------------------
  // Beantwortet die Frage "warum geht das bei mir nicht?" mit einem Bericht:
  // Build, erkannte Seite und Tabelle, aktive Einstellungen und die letzten
  // Meldungen. Nur lesend, keine Netzwerkzugriffe.

  function diagnoseSeitenart() {
    const url = window.location.href;
    if (/Action=AgentTicketZoom\b/i.test(url)) return "Ticketansicht";
    if (/Action=AgentTicketSearch\b/i.test(url)) return "Suche";
    if (/Action=AgentTicket(?:Queue|LockedView|OwnerView|ResponsibleView|WatchView|StatusView|EscalationView)\b/i.test(url)) {
      return "Ticketliste";
    }
    if (/customer\.pl/i.test(url)) return "Kundenportal";
    return "andere Seite";
  }

  function diagnoseTicketliste() {
    const table = findCategoryTable();
    if (!table) return { erkannt: false, zeilen: 0, spalten: [], ticketspalte: -1 };

    const spalten = [...table.querySelectorAll("th")]
      .map((th) => getElementText(th).replace(/\s+/g, " ").trim())
      .filter(Boolean);

    const indexes = getIndexes(table);
    return {
      erkannt: true,
      zeilen: table.querySelectorAll("tbody tr").length,
      spalten,
      ticketspalte: resolveTicketColumnIndex(table, indexes)
    };
  }

  function buildDiagnoseBericht() {
    return {
      version: api.runtime.getManifest?.().version || "?",
      zeit: new Date().toISOString(),
      seite: {
        art: diagnoseSeitenart(),
        url: window.location.href,
        titel: document.title
      },
      ticketliste: diagnoseTicketliste(),
      kategorien: Boolean(settings.ticketCategories),
      einstellungen: { ...settings },
      fehler: diagnoseFehler.slice()
    };
  }

  function installDiagnoseAntwort() {
    api.runtime.onMessage.addListener((nachricht, absender, antworten) => {
      if (!nachricht || nachricht.typ !== "zh-diagnose") return undefined;
      antworten({ ok: true, bericht: buildDiagnoseBericht() });
      return undefined;
    });
  }

  async function init() {
    installDiagnoseProtokoll();
    installDiagnoseAntwort();

    // Diagnostic aid: shows at a glance which build is running and whether the
    // current page is treated as a ticket list. Only visible with DevTools open.
    console.info(
      `Znuny Helper ${api.runtime.getManifest?.().version || "?"} aktiv`,
      { seite: window.location.href, ticketliste: isTicketListPage() }
    );

    const storedSettings = await syncGet("local", { [SETTINGS_KEY]: DEFAULT_SETTINGS });
    settings = { ...DEFAULT_SETTINGS, ...(storedSettings[SETTINGS_KEY] || {}) };

    // Must run before the flag is consumed below.
    markActionTabIfRequested();
    consumeAutoCloseFlag();

    const storedTicketState = await syncGet("local", { [TICKET_STATE_KEY]: ticketState });
    ticketState = {
      categories: {},
      notes: {},
      ...(storedTicketState[TICKET_STATE_KEY] || {})
    };

    const storedCategoryConfig = await syncGet("local", {
      [CATEGORY_CONFIG_KEY]: { groups: DEFAULT_GROUPS, keywords: DEFAULT_KEYWORDS }
    });
    categoryConfig = normalizeCategoryConfig(storedCategoryConfig[CATEGORY_CONFIG_KEY]);

    const storedPriorityTemplateConfig = await syncGet("local", {
      [PRIORITY_TEMPLATE_CONFIG_KEY]: {
        templates: DEFAULT_PRIORITY_TEMPLATES
      }
    });
    priorityTemplateConfig = normalizePriorityTemplateConfig(storedPriorityTemplateConfig[PRIORITY_TEMPLATE_CONFIG_KEY]);

    const storedTicketSoundConfig = await syncGet("local", { [TICKET_SOUND_CONFIG_KEY]: ticketSoundConfig });
    ticketSoundConfig = normalizeTicketSoundConfig(storedTicketSoundConfig[TICKET_SOUND_CONFIG_KEY]);

    const storedQuickReplyLayout = await syncGet("local", { [QUICK_REPLY_LAYOUT_KEY]: quickReplyLayout });
    quickReplyLayout = normalizeQuickReplyLayout(storedQuickReplyLayout[QUICK_REPLY_LAYOUT_KEY]);

    await loadSearchHistory();
    await loadQuickReplyDrafts();

    dispatchPageSettings();

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", runEnabledFeatures, { once: true });
    } else {
      runEnabledFeatures();
    }

    const observer = new MutationObserver(handleDocumentMutation);
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });

    api.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== "local") return;

      if (changes[SETTINGS_KEY]) {
        settings = { ...DEFAULT_SETTINGS, ...(changes[SETTINGS_KEY].newValue || {}) };
        runEnabledFeatures();
      }

      if (changes[SEARCH_HISTORY_KEY]) {
        handleSearchHistoryStorageChange(changes[SEARCH_HISTORY_KEY].newValue);
      }

      if (changes[TICKET_SOUND_CONFIG_KEY]) {
        ticketSoundConfig = normalizeTicketSoundConfig(changes[TICKET_SOUND_CONFIG_KEY].newValue);
      }

      if (changes[QUICK_REPLY_LAYOUT_KEY]) {
        quickReplyLayout = normalizeQuickReplyLayout(changes[QUICK_REPLY_LAYOUT_KEY].newValue);
      }
    });

    window.setTimeout(checkForAssignedTickets, 5000);
    window.setInterval(checkForAssignedTickets, TICKET_SOUND_CHECK_INTERVAL_MS);
  }

  init().catch((error) => {
    // Not just a warning: if initialisation fails, every feature stays inactive and
    // the console line (see the version marker in init) is the only clue.
    console.error("Znuny Helper failed to initialize:", error);
  });
})();
